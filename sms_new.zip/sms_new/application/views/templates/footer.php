</div> <!--/container-fluid-->


<!-- boostrap js -->
  <script type="text/javascript" src="<?php echo base_url(); ?>assets/bootstrap/js/bootstrap.min.js"></script>
  <!-- datatables js -->
  <script type="text/javascript" src="<?php echo base_url(); ?>assets/datatables/media/js/jquery.dataTables.min.js"></script>
  <!-- fileinput js -->
  <script type="text/javascript" src="<?php echo base_url(); ?>assets/fileinput/js/fileinput.min.js"></script>

  <!-- full calendar -->
  <script type="text/javascript" src="<?php echo base_url(); ?>assets/fullcalendar/moment.min.js"></script>  
  <script type="text/javascript" src="<?php echo base_url(); ?>assets/fullcalendar/fullcalendar.min.js"></script>  

  <!-- keith calendar -->
  <script type="text/javascript" src="<?php echo base_url(); ?>assets/keith-calendar/jquery.calendars.js"></script> 
  <script type="text/javascript" src="<?php echo base_url(); ?>assets/keith-calendar/jquery.calendars.plus.js"></script> 
  <script type="text/javascript" src="<?php echo base_url(); ?>assets/keith-calendar/jquery.plugin.js"></script> 
  <script type="text/javascript" src="<?php echo base_url(); ?>assets/keith-calendar/jquery.calendars.picker.js"></script>
  <script type="text/javascript" src="<?php echo base_url(); ?>assets/keith-calendar/jquery.calendars.picker.js"></script>

  


</body>
</html>