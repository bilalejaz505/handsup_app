<?php


    return array(
        'AppSid' => '9_kwDSfe_k3DOcyjO_R40Fke6ubIKB',
        'ApiURL' => 'http://api.unifonic.com/rest/',

    );
