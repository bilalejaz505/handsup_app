        
             <div class="content_row">
             
              <div class="light_shadow_bar"></div>
              
              <div class="black_bar_main">
              
              <div class="inner_left_wrap">
              <div class="inner_left_heading">Modern Pioneer</div>

<div class="inner_left_headingsmalll">Website</div>
</div>
              
              
              <div class="inner_mid_heading">Manage Websites</div>
              
               <div class="side_bar_wrap" style="border-left:1px solid #fff;"><span><img src="<?php echo base_url();?>assets/images/sidebar_icon.png" width="15" height="15" /></span>Sidebar</div>
              </div>
             
              <div class="black_shadow"></div>
             
             </div>  
             
             
             <!--gray_panel-->
             <div class="inner_gray_panel" >
             
               <!--side_right-->
               <div class="side_right">
               
                 <div class="seprator_horizontal"></div>
                 
                   <!--search_bar_panel-->
                   <div class="search_bar_panel">
                   
                   <div class="search_heading">Search</div>
                  
                  <div class="search_detail">Type your search keyword<br />

to filter the grid</div>


                     <div class="search_field_row">
                           
                       <div class="search_inputfiled">
                       <input name="" type="text" class="search_field"  placeholder="Keyword"/></div> 
                            
                        <div class="search_button"><img src="assets/images/search_button.png" width="36" height="32" /></div>
                            
                     </div>
                   
                   </div><!--search_bar_panel-->
              
               
               
               </div><!--side_right-->
 <!--middle_content_areainner-->
                       <div class="middle_content_areainner">
                       
                         <div class="admin_manage_panel">
                          
                        <!--website_listing_row-->
                        <div class="website_listing_row">
                        
                        
                            <!--list_box_wrap_inner-->
                            <div class="list_box_wrap_inner">
                            
                             <div class="list_logo_box"><img src="assets/images/logo.png" width="119" height="51" /></div>
                             
                              <div class="website_list_name">Place Company Name Here</div>
                            
                            
                            </div><!--list_box_wrap_inner-->
                            
                            
                            
                            
                            
                                 <!--list_box_wrap_inner-->
                            <div class="list_box_wrap_inner">
                            
                             <div class="list_logo_box"><img src="assets/images/logo.png" width="119" height="51" /></div>
                             
                              <div class="website_list_name">Place Company Name Here</div>
                            
                            
                            </div><!--list_box_wrap_inner-->
                            
                            
                            
                            
                            
                            
                               <!--list_box_wrap_inner-->
                            <div class="list_box_wrap_inner">
                            
                             <div class="list_logo_box"><img src="assets/images/logo.png" width="119" height="51" /></div>
                             
                              <div class="website_list_name">Place Company Name Here</div>
                            
                            
                            </div><!--list_box_wrap_inner-->
                            
                            
                            
                            
                            
                               <!--list_box_wrap_inner-->
                            <div class="list_box_wrap_inner">
                            
                             <div class="list_logo_box"><img src="assets/images/logo.png" width="119" height="51" /></div>
                             
                              <div class="website_list_name">Place Company Name Here</div>
                            
                            
                            </div><!--list_box_wrap_inner-->
                            
                            
                          
                            </div><!--website_listing_row-->
                            
                            
                            
                            <!--website_listing_row-->
                        <div class="website_listing_row">
                        
                        
                            <!--list_box_wrap_inner-->
                            <div class="list_box_wrap_inner">
                            
                             <div class="list_logo_box"><img src="assets/images/logo.png" width="119" height="51" /></div>
                             
                              <div class="website_list_name">Place Company Name Here</div>
                            
                            
                            </div><!--list_box_wrap_inner-->
                            
                            
                            
                            
                            
                                 <!--list_box_wrap_inner-->
                            <div class="list_box_wrap_inner">
                            
                             <div class="list_logo_box"><img src="assets/images/logo.png" width="119" height="51" /></div>
                             
                              <div class="website_list_name">Place Company Name Here</div>
                            
                            
                            </div><!--list_box_wrap_inner-->
                            
                            
                            
                            
                            
                            
                               <!--list_box_wrap_inner-->
                            <div class="list_box_wrap_inner">
                            
                             <div class="list_logo_box"><img src="assets/images/logo.png" width="119" height="51" /></div>
                             
                              <div class="website_list_name">Place Company Name Here</div>
                            
                            
                            </div><!--list_box_wrap_inner-->
                            
                            
                            
                            
                            
                               <!--list_box_wrap_inner-->
                            <div class="list_box_wrap_inner">
                            
                             <div class="list_logo_box"><img src="assets/images/logo.png" width="119" height="51" /></div>
                             
                              <div class="website_list_name">Place Company Name Here</div>
                            
                            
                            </div><!--list_box_wrap_inner-->
                            
                            
                          
                            </div><!--website_listing_row-->
                            
                            
                            
                            <!--website_listing_row-->
                        <div class="website_listing_row">
                        
                        
                            <!--list_box_wrap_inner-->
                            <div class="list_box_wrap_inner">
                            
                             <div class="list_logo_box"><img src="assets/images/logo.png" width="119" height="51" /></div>
                             
                              <div class="website_list_name">Place Company Name Here</div>
                            
                            
                            </div><!--list_box_wrap_inner-->
                            
                            
                            
                            
                            
                                 <!--list_box_wrap_inner-->
                            <div class="list_box_wrap_inner">
                            
                             <div class="list_logo_box"><img src="assets/images/logo.png" width="119" height="51" /></div>
                             
                              <div class="website_list_name">Place Company Name Here</div>
                            
                            
                            </div><!--list_box_wrap_inner-->
                            
                            
                            
                            
                            
                            
                               <!--list_box_wrap_inner-->
                            <div class="list_box_wrap_inner">
                            
                             <div class="list_logo_box"><img src="assets/images/logo.png" width="119" height="51" /></div>
                             
                              <div class="website_list_name">Place Company Name Here</div>
                            
                            
                            </div><!--list_box_wrap_inner-->
                            
                            
                            
                            
                            
                               <!--list_box_wrap_inner-->
                            <div class="list_box_wrap_inner">
                            
                             <div class="list_logo_box"><img src="assets/images/logo.png" width="119" height="51" /></div>
                             
                              <div class="website_list_name">Place Company Name Here</div>
                            
                            
                            </div><!--list_box_wrap_inner-->
                            
                            
                          
                            </div><!--website_listing_row-->
                            
                            
                           </div> 
                            
                 
                         
                       </div><!--middle_content_areainner-->
             
             
                           