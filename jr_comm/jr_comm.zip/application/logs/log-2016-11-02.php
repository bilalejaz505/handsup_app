<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-11-02 16:41:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 2936
ERROR - 2016-11-02 16:41:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\controllers\page.php 270
ERROR - 2016-11-02 16:41:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\controllers\page.php 278
ERROR - 2016-11-02 16:41:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\controllers\page.php 286
ERROR - 2016-11-02 16:41:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\header.php 13
ERROR - 2016-11-02 16:41:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\header.php 14
ERROR - 2016-11-02 16:41:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\header.php 15
ERROR - 2016-11-02 16:41:33 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 3422
ERROR - 2016-11-02 16:41:33 --> 404 Page Not Found --> assets
ERROR - 2016-11-02 16:41:33 --> 404 Page Not Found --> assets
ERROR - 2016-11-02 16:41:33 --> 404 Page Not Found --> assets
ERROR - 2016-11-02 16:41:33 --> 404 Page Not Found --> assets
ERROR - 2016-11-02 16:42:14 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin.php 68
ERROR - 2016-11-02 16:43:21 --> 404 Page Not Found --> dashboard/contents
ERROR - 2016-11-02 16:43:31 --> 404 Page Not Found --> ems/contents
ERROR - 2016-11-02 16:43:41 --> 404 Page Not Found --> ems/manage
ERROR - 2016-11-02 16:45:19 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin.php 68
ERROR - 2016-11-02 16:45:49 --> Severity: Notice  --> Undefined variable: message C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 280
ERROR - 2016-11-02 16:45:49 --> Severity: Notice  --> Undefined variable: clientList C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 287
ERROR - 2016-11-02 16:45:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 287
ERROR - 2016-11-02 16:45:49 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 308
ERROR - 2016-11-02 16:45:49 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 16:45:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 16:45:49 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1401
ERROR - 2016-11-02 16:45:49 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1407
ERROR - 2016-11-02 16:45:50 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1413
ERROR - 2016-11-02 16:45:50 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1441
ERROR - 2016-11-02 16:45:50 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1723
ERROR - 2016-11-02 16:45:50 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1797
ERROR - 2016-11-02 16:45:50 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1805
ERROR - 2016-11-02 16:45:50 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1827
ERROR - 2016-11-02 16:45:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1939
ERROR - 2016-11-02 16:45:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1939
ERROR - 2016-11-02 16:45:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1939
ERROR - 2016-11-02 16:45:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1939
ERROR - 2016-11-02 16:45:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1939
ERROR - 2016-11-02 16:45:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1939
ERROR - 2016-11-02 16:45:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1939
ERROR - 2016-11-02 16:45:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1939
ERROR - 2016-11-02 16:45:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1939
ERROR - 2016-11-02 16:45:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1939
ERROR - 2016-11-02 16:45:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1939
ERROR - 2016-11-02 16:45:50 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 2025
ERROR - 2016-11-02 16:45:50 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 2031
ERROR - 2016-11-02 16:45:50 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 2037
ERROR - 2016-11-02 16:45:51 --> 404 Page Not Found --> assets
ERROR - 2016-11-02 16:45:59 --> Severity: Notice  --> Undefined variable: message C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 280
ERROR - 2016-11-02 16:45:59 --> Severity: Notice  --> Undefined variable: clientList C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 287
ERROR - 2016-11-02 16:45:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 287
ERROR - 2016-11-02 16:45:59 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 308
ERROR - 2016-11-02 16:45:59 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 16:45:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 16:45:59 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1401
ERROR - 2016-11-02 16:45:59 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1407
ERROR - 2016-11-02 16:45:59 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1413
ERROR - 2016-11-02 16:45:59 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1441
ERROR - 2016-11-02 16:45:59 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1723
ERROR - 2016-11-02 16:45:59 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1797
ERROR - 2016-11-02 16:45:59 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1805
ERROR - 2016-11-02 16:45:59 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1827
ERROR - 2016-11-02 16:45:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1939
ERROR - 2016-11-02 16:45:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1939
ERROR - 2016-11-02 16:45:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1939
ERROR - 2016-11-02 16:45:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1939
ERROR - 2016-11-02 16:45:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1939
ERROR - 2016-11-02 16:45:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1939
ERROR - 2016-11-02 16:45:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1939
ERROR - 2016-11-02 16:45:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1939
ERROR - 2016-11-02 16:45:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1939
ERROR - 2016-11-02 16:45:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1939
ERROR - 2016-11-02 16:45:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1939
ERROR - 2016-11-02 16:45:59 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 2025
ERROR - 2016-11-02 16:45:59 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 2031
ERROR - 2016-11-02 16:45:59 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 2037
ERROR - 2016-11-02 16:52:33 --> Severity: Notice  --> Undefined variable: message C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 280
ERROR - 2016-11-02 16:52:33 --> Severity: Notice  --> Undefined variable: clientList C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 287
ERROR - 2016-11-02 16:52:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 287
ERROR - 2016-11-02 16:52:33 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 308
ERROR - 2016-11-02 16:52:33 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 16:52:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 16:52:33 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1401
ERROR - 2016-11-02 16:52:33 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1407
ERROR - 2016-11-02 16:52:33 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1413
ERROR - 2016-11-02 16:52:33 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1441
ERROR - 2016-11-02 16:52:33 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1723
ERROR - 2016-11-02 16:52:33 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1797
ERROR - 2016-11-02 16:52:33 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1805
ERROR - 2016-11-02 16:52:33 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1827
ERROR - 2016-11-02 16:52:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1939
ERROR - 2016-11-02 16:52:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1939
ERROR - 2016-11-02 16:52:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1939
ERROR - 2016-11-02 16:52:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1939
ERROR - 2016-11-02 16:52:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1939
ERROR - 2016-11-02 16:52:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1939
ERROR - 2016-11-02 16:52:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1939
ERROR - 2016-11-02 16:52:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1939
ERROR - 2016-11-02 16:52:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1939
ERROR - 2016-11-02 16:52:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1939
ERROR - 2016-11-02 16:52:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1939
ERROR - 2016-11-02 16:52:33 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 2025
ERROR - 2016-11-02 16:52:33 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 2031
ERROR - 2016-11-02 16:52:33 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 2037
ERROR - 2016-11-02 16:53:00 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\jr_comm\application\controllers\ems\content.php 93
ERROR - 2016-11-02 16:53:00 --> Severity: Notice  --> Undefined variable: res C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php 39
ERROR - 2016-11-02 16:53:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php 39
ERROR - 2016-11-02 16:53:00 --> Severity: Warning  --> Missing argument 6 for create_image(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 113 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 96
ERROR - 2016-11-02 16:53:00 --> Severity: Warning  --> Missing argument 6 for create_image(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 118 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 96
ERROR - 2016-11-02 16:53:00 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 124 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 7
ERROR - 2016-11-02 16:53:00 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 128 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 7
ERROR - 2016-11-02 16:53:00 --> Severity: Warning  --> Missing argument 6 for create_image(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 134 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 96
ERROR - 2016-11-02 16:53:00 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 139 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 16:53:00 --> Severity: Warning  --> Missing argument 5 for create_textfield_not_required(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 144 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 51
ERROR - 2016-11-02 16:53:00 --> Severity: Warning  --> Missing argument 5 for create_textfield_not_required(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 145 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 51
ERROR - 2016-11-02 16:53:00 --> Severity: Warning  --> Missing argument 5 for create_textfield_not_required(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 146 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 51
ERROR - 2016-11-02 16:53:00 --> Severity: Warning  --> Missing argument 5 for create_textfield_not_required(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 147 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 51
ERROR - 2016-11-02 16:53:00 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 148 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 16:53:00 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 149 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 16:53:00 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 150 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 16:53:00 --> Severity: Warning  --> Missing argument 5 for create_textfield_not_required(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 151 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 51
ERROR - 2016-11-02 16:53:00 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 160 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 16:53:00 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 165 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 16:53:00 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 169 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 16:53:00 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 175 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 16:53:00 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 181 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 16:53:00 --> Severity: Warning  --> Missing argument 5 for create_externallink(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 186 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 81
ERROR - 2016-11-02 16:53:00 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 237 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 16:53:00 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 240 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 16:53:00 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 243 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 7
ERROR - 2016-11-02 16:53:00 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 247 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 7
ERROR - 2016-11-02 16:53:00 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 16:53:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 16:53:00 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1401
ERROR - 2016-11-02 16:53:00 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1407
ERROR - 2016-11-02 16:53:00 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1413
ERROR - 2016-11-02 16:53:00 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1441
ERROR - 2016-11-02 16:53:00 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1723
ERROR - 2016-11-02 16:53:00 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1805
ERROR - 2016-11-02 16:53:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1939
ERROR - 2016-11-02 16:53:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1939
ERROR - 2016-11-02 16:53:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1939
ERROR - 2016-11-02 16:53:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1939
ERROR - 2016-11-02 16:53:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1939
ERROR - 2016-11-02 16:53:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1939
ERROR - 2016-11-02 16:53:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1939
ERROR - 2016-11-02 16:53:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1939
ERROR - 2016-11-02 16:53:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1939
ERROR - 2016-11-02 16:53:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1939
ERROR - 2016-11-02 16:53:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1939
ERROR - 2016-11-02 16:53:00 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 2025
ERROR - 2016-11-02 16:53:00 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 2031
ERROR - 2016-11-02 16:53:00 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 2037
ERROR - 2016-11-02 18:26:13 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\jr_comm\application\controllers\ems\content.php 93
ERROR - 2016-11-02 18:26:13 --> Severity: Notice  --> Undefined variable: res C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php 39
ERROR - 2016-11-02 18:26:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php 39
ERROR - 2016-11-02 18:26:13 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 114 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:26:13 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 115 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 7
ERROR - 2016-11-02 18:26:13 --> Severity: Warning  --> Missing argument 6 for create_image(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 116 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 96
ERROR - 2016-11-02 18:26:13 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 122 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:26:13 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 123 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 7
ERROR - 2016-11-02 18:26:13 --> Severity: Warning  --> Missing argument 6 for create_image(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 124 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 96
ERROR - 2016-11-02 18:26:13 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 130 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:26:13 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 136 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:26:13 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 142 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:26:13 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 143 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 7
ERROR - 2016-11-02 18:26:13 --> Severity: Warning  --> Missing argument 6 for create_image(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 149 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 96
ERROR - 2016-11-02 18:26:13 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 155 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 7
ERROR - 2016-11-02 18:26:13 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 159 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 7
ERROR - 2016-11-02 18:26:13 --> Severity: Warning  --> Missing argument 6 for create_image(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 165 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 96
ERROR - 2016-11-02 18:26:13 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 170 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:26:13 --> Severity: Warning  --> Missing argument 5 for create_textfield_not_required(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 175 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 51
ERROR - 2016-11-02 18:26:13 --> Severity: Warning  --> Missing argument 5 for create_textfield_not_required(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 176 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 51
ERROR - 2016-11-02 18:26:13 --> Severity: Warning  --> Missing argument 5 for create_textfield_not_required(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 177 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 51
ERROR - 2016-11-02 18:26:13 --> Severity: Warning  --> Missing argument 5 for create_textfield_not_required(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 178 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 51
ERROR - 2016-11-02 18:26:13 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 179 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:26:13 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 180 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:26:13 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 181 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:26:13 --> Severity: Warning  --> Missing argument 5 for create_textfield_not_required(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 182 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 51
ERROR - 2016-11-02 18:26:13 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 191 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:26:13 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 196 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:26:13 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 200 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:26:13 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 206 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:26:13 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 212 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:26:13 --> Severity: Warning  --> Missing argument 5 for create_externallink(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 217 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 81
ERROR - 2016-11-02 18:26:13 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 268 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:26:13 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 271 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:26:13 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 274 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 7
ERROR - 2016-11-02 18:26:13 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 278 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 7
ERROR - 2016-11-02 18:26:13 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 18:26:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 18:26:13 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-02 18:26:13 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-02 18:26:13 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-02 18:26:13 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-02 18:26:13 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-02 18:26:13 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-02 18:26:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:26:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:26:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:26:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:26:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:26:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:26:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:26:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:26:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:26:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:26:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:26:13 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-02 18:26:13 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-02 18:26:13 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-02 18:27:42 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\jr_comm\application\controllers\ems\content.php 93
ERROR - 2016-11-02 18:27:42 --> Severity: Notice  --> Undefined variable: res C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php 39
ERROR - 2016-11-02 18:27:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php 39
ERROR - 2016-11-02 18:27:42 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 114 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:27:42 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 115 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 7
ERROR - 2016-11-02 18:27:42 --> Severity: Warning  --> Missing argument 6 for create_image(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 116 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 96
ERROR - 2016-11-02 18:27:42 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 122 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:27:42 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 123 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 7
ERROR - 2016-11-02 18:27:42 --> Severity: Warning  --> Missing argument 6 for create_image(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 124 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 96
ERROR - 2016-11-02 18:27:42 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 130 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:27:42 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 136 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:27:42 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 142 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:27:42 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 143 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 7
ERROR - 2016-11-02 18:27:42 --> Severity: Warning  --> Missing argument 6 for create_image(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 149 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 96
ERROR - 2016-11-02 18:27:42 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 155 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 7
ERROR - 2016-11-02 18:27:42 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 159 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 7
ERROR - 2016-11-02 18:27:42 --> Severity: Warning  --> Missing argument 6 for create_image(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 165 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 96
ERROR - 2016-11-02 18:27:42 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 170 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:27:42 --> Severity: Warning  --> Missing argument 5 for create_textfield_not_required(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 175 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 51
ERROR - 2016-11-02 18:27:42 --> Severity: Warning  --> Missing argument 5 for create_textfield_not_required(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 176 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 51
ERROR - 2016-11-02 18:27:42 --> Severity: Warning  --> Missing argument 5 for create_textfield_not_required(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 177 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 51
ERROR - 2016-11-02 18:27:42 --> Severity: Warning  --> Missing argument 5 for create_textfield_not_required(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 178 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 51
ERROR - 2016-11-02 18:27:42 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 179 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:27:42 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 180 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:27:42 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 181 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:27:42 --> Severity: Warning  --> Missing argument 5 for create_textfield_not_required(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 182 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 51
ERROR - 2016-11-02 18:27:42 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 191 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:27:43 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 196 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:27:43 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 200 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:27:43 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 206 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:27:43 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 212 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:27:43 --> Severity: Warning  --> Missing argument 5 for create_externallink(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 217 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 81
ERROR - 2016-11-02 18:27:43 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 268 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:27:43 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 271 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:27:43 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 274 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 7
ERROR - 2016-11-02 18:27:43 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 278 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 7
ERROR - 2016-11-02 18:27:43 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 18:27:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 18:27:43 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-02 18:27:43 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-02 18:27:43 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-02 18:27:43 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-02 18:27:43 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-02 18:27:43 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-02 18:27:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:27:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:27:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:27:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:27:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:27:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:27:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:27:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:27:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:27:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:27:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:27:43 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-02 18:27:43 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-02 18:27:43 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-02 18:27:51 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin.php 68
ERROR - 2016-11-02 18:28:07 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin.php 68
ERROR - 2016-11-02 18:28:24 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 18:28:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 18:28:24 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-02 18:28:24 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-02 18:28:24 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-02 18:28:24 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-02 18:28:24 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-02 18:28:24 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1753
ERROR - 2016-11-02 18:28:24 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-02 18:28:24 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1783
ERROR - 2016-11-02 18:28:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1891
ERROR - 2016-11-02 18:28:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:28:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1891
ERROR - 2016-11-02 18:28:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:28:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1891
ERROR - 2016-11-02 18:28:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:28:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1891
ERROR - 2016-11-02 18:28:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:28:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1891
ERROR - 2016-11-02 18:28:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:28:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1891
ERROR - 2016-11-02 18:28:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:28:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1891
ERROR - 2016-11-02 18:28:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:28:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1891
ERROR - 2016-11-02 18:28:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:28:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1891
ERROR - 2016-11-02 18:28:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:28:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1891
ERROR - 2016-11-02 18:28:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:28:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1891
ERROR - 2016-11-02 18:28:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:28:24 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-02 18:28:24 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-02 18:28:24 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-02 18:29:02 --> Severity: Notice  --> Undefined variable: message C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 280
ERROR - 2016-11-02 18:29:02 --> Severity: Notice  --> Undefined variable: clientList C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 287
ERROR - 2016-11-02 18:29:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 287
ERROR - 2016-11-02 18:29:02 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 308
ERROR - 2016-11-02 18:29:02 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 18:29:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 18:29:02 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-02 18:29:02 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-02 18:29:02 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-02 18:29:02 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-02 18:29:02 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-02 18:29:02 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1753
ERROR - 2016-11-02 18:29:02 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-02 18:29:02 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1783
ERROR - 2016-11-02 18:29:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:29:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:29:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:29:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:29:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:29:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:29:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:29:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:29:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:29:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:29:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:29:02 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-02 18:29:02 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-02 18:29:02 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-02 18:29:22 --> Severity: Notice  --> Undefined variable: message C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 280
ERROR - 2016-11-02 18:29:22 --> Severity: Notice  --> Undefined variable: clientList C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 287
ERROR - 2016-11-02 18:29:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 287
ERROR - 2016-11-02 18:29:22 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 308
ERROR - 2016-11-02 18:29:22 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 18:29:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 18:29:22 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-02 18:29:22 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-02 18:29:22 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-02 18:29:22 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-02 18:29:22 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-02 18:29:22 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1753
ERROR - 2016-11-02 18:29:22 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-02 18:29:22 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1783
ERROR - 2016-11-02 18:29:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:29:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:29:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:29:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:29:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:29:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:29:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:29:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:29:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:29:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:29:23 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-02 18:29:23 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-02 18:29:23 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-02 18:29:30 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\jr_comm\application\controllers\ems\content.php 93
ERROR - 2016-11-02 18:29:30 --> Severity: Notice  --> Undefined variable: res C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php 39
ERROR - 2016-11-02 18:29:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php 39
ERROR - 2016-11-02 18:29:30 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 114 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:29:30 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 115 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 7
ERROR - 2016-11-02 18:29:30 --> Severity: Warning  --> Missing argument 6 for create_image(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 116 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 96
ERROR - 2016-11-02 18:29:30 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 122 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:29:30 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 123 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 7
ERROR - 2016-11-02 18:29:30 --> Severity: Warning  --> Missing argument 6 for create_image(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 124 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 96
ERROR - 2016-11-02 18:29:30 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 130 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:29:31 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 136 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:29:31 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 142 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:29:31 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 143 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 7
ERROR - 2016-11-02 18:29:31 --> Severity: Warning  --> Missing argument 6 for create_image(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 149 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 96
ERROR - 2016-11-02 18:29:31 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 155 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 7
ERROR - 2016-11-02 18:29:31 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 159 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 7
ERROR - 2016-11-02 18:29:31 --> Severity: Warning  --> Missing argument 6 for create_image(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 165 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 96
ERROR - 2016-11-02 18:29:31 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 170 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:29:31 --> Severity: Warning  --> Missing argument 5 for create_textfield_not_required(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 175 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 51
ERROR - 2016-11-02 18:29:31 --> Severity: Warning  --> Missing argument 5 for create_textfield_not_required(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 176 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 51
ERROR - 2016-11-02 18:29:31 --> Severity: Warning  --> Missing argument 5 for create_textfield_not_required(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 177 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 51
ERROR - 2016-11-02 18:29:31 --> Severity: Warning  --> Missing argument 5 for create_textfield_not_required(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 178 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 51
ERROR - 2016-11-02 18:29:31 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 179 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:29:31 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 180 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:29:31 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 181 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:29:31 --> Severity: Warning  --> Missing argument 5 for create_textfield_not_required(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 182 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 51
ERROR - 2016-11-02 18:29:31 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 191 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:29:31 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 196 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:29:31 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 200 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:29:31 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 206 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:29:31 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 212 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:29:31 --> Severity: Warning  --> Missing argument 5 for create_externallink(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 217 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 81
ERROR - 2016-11-02 18:29:31 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 268 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:29:31 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 271 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:29:31 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 274 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 7
ERROR - 2016-11-02 18:29:31 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 278 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 7
ERROR - 2016-11-02 18:29:31 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 18:29:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 18:29:31 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-02 18:29:31 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-02 18:29:31 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-02 18:29:31 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-02 18:29:31 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-02 18:29:31 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-02 18:29:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:29:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:29:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:29:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:29:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:29:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:29:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:29:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:29:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:29:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:29:31 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-02 18:29:31 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-02 18:29:31 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-02 18:43:07 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\jr_comm\application\controllers\ems\content.php 93
ERROR - 2016-11-02 18:43:07 --> Severity: Notice  --> Undefined variable: res C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php 39
ERROR - 2016-11-02 18:43:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php 39
ERROR - 2016-11-02 18:43:07 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 114 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:43:07 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 115 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 7
ERROR - 2016-11-02 18:43:07 --> Severity: Warning  --> Missing argument 6 for create_image(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 116 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 96
ERROR - 2016-11-02 18:43:07 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 122 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:43:07 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 123 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 7
ERROR - 2016-11-02 18:43:07 --> Severity: Warning  --> Missing argument 6 for create_image(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 124 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 96
ERROR - 2016-11-02 18:43:07 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 130 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:43:07 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 136 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:43:07 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 142 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:43:07 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 143 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 7
ERROR - 2016-11-02 18:43:07 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 18:43:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 18:43:07 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-02 18:43:07 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-02 18:43:07 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-02 18:43:07 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-02 18:43:07 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-02 18:43:07 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-02 18:43:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:43:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:43:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:43:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:43:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:43:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:43:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:43:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:43:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:43:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:43:07 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-02 18:43:07 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-02 18:43:07 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-02 18:46:17 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\jr_comm\application\controllers\ems\content.php 93
ERROR - 2016-11-02 18:46:17 --> Severity: Notice  --> Undefined variable: res C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php 39
ERROR - 2016-11-02 18:46:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php 39
ERROR - 2016-11-02 18:46:17 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 115 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:46:17 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 116 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 7
ERROR - 2016-11-02 18:46:17 --> Severity: Warning  --> Missing argument 6 for create_image(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 117 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 96
ERROR - 2016-11-02 18:46:17 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 123 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:46:17 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 124 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 7
ERROR - 2016-11-02 18:46:17 --> Severity: Warning  --> Missing argument 6 for create_image(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 125 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 96
ERROR - 2016-11-02 18:46:17 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 131 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:46:17 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 137 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:46:17 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 143 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:46:17 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 144 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 7
ERROR - 2016-11-02 18:46:17 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 18:46:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 18:46:17 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-02 18:46:17 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-02 18:46:17 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-02 18:46:17 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-02 18:46:17 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-02 18:46:17 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-02 18:46:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:46:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:46:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:46:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:46:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:46:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:46:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:46:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:46:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:46:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:46:18 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-02 18:46:18 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-02 18:46:18 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-02 18:54:53 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\jr_comm\application\controllers\ems\content.php 93
ERROR - 2016-11-02 18:54:53 --> Severity: Notice  --> Undefined variable: res C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php 39
ERROR - 2016-11-02 18:54:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php 39
ERROR - 2016-11-02 18:54:53 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 115 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:54:53 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 116 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 7
ERROR - 2016-11-02 18:54:53 --> Severity: Warning  --> Missing argument 6 for create_image(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 117 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 96
ERROR - 2016-11-02 18:54:53 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 123 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:54:53 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 124 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 7
ERROR - 2016-11-02 18:54:53 --> Severity: Warning  --> Missing argument 6 for create_image(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 125 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 96
ERROR - 2016-11-02 18:54:53 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 131 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:54:53 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 137 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:54:53 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 143 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:54:53 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 144 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 7
ERROR - 2016-11-02 18:54:53 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 18:54:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 18:54:53 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-02 18:54:53 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-02 18:54:53 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-02 18:54:53 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-02 18:54:53 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-02 18:54:53 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-02 18:54:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:54:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:54:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:54:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:54:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:54:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:54:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:54:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:54:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:54:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:54:53 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-02 18:54:53 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-02 18:54:53 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-02 18:56:30 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\jr_comm\application\controllers\ems\content.php 93
ERROR - 2016-11-02 18:56:30 --> Severity: Notice  --> Undefined variable: res C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php 39
ERROR - 2016-11-02 18:56:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php 39
ERROR - 2016-11-02 18:56:30 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 115 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:56:31 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 116 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 7
ERROR - 2016-11-02 18:56:31 --> Severity: Warning  --> Missing argument 6 for create_image(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 117 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 96
ERROR - 2016-11-02 18:56:31 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 123 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:56:31 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 124 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 7
ERROR - 2016-11-02 18:56:31 --> Severity: Warning  --> Missing argument 6 for create_image(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 125 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 96
ERROR - 2016-11-02 18:56:31 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 131 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:56:31 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 137 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:56:31 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 143 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 18:56:31 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 144 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 7
ERROR - 2016-11-02 18:56:31 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 18:56:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 18:56:31 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-02 18:56:31 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-02 18:56:31 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-02 18:56:31 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-02 18:56:31 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-02 18:56:31 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-02 18:56:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:56:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:56:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:56:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:56:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:56:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:56:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:56:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:56:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:56:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 18:56:31 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-02 18:56:31 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-02 18:56:31 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-02 19:03:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 2936
ERROR - 2016-11-02 19:03:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\controllers\page.php 173
ERROR - 2016-11-02 19:03:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\controllers\page.php 179
ERROR - 2016-11-02 19:03:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\controllers\page.php 185
ERROR - 2016-11-02 19:04:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 2936
ERROR - 2016-11-02 19:04:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\controllers\page.php 173
ERROR - 2016-11-02 19:04:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\controllers\page.php 179
ERROR - 2016-11-02 19:04:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\controllers\page.php 185
ERROR - 2016-11-02 19:04:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 2936
ERROR - 2016-11-02 19:04:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\controllers\page.php 173
ERROR - 2016-11-02 19:04:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\controllers\page.php 179
ERROR - 2016-11-02 19:04:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\controllers\page.php 185
ERROR - 2016-11-02 19:04:33 --> 404 Page Not Found --> home
ERROR - 2016-11-02 19:04:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 2936
ERROR - 2016-11-02 19:04:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\controllers\page.php 173
ERROR - 2016-11-02 19:04:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\controllers\page.php 179
ERROR - 2016-11-02 19:04:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\controllers\page.php 185
ERROR - 2016-11-02 19:04:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 2936
ERROR - 2016-11-02 19:04:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\controllers\page.php 173
ERROR - 2016-11-02 19:04:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\controllers\page.php 179
ERROR - 2016-11-02 19:04:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\controllers\page.php 185
ERROR - 2016-11-02 19:05:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 2936
ERROR - 2016-11-02 19:05:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\controllers\page.php 173
ERROR - 2016-11-02 19:05:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\controllers\page.php 179
ERROR - 2016-11-02 19:05:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\controllers\page.php 185
ERROR - 2016-11-02 19:05:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 2936
ERROR - 2016-11-02 19:05:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\controllers\page.php 173
ERROR - 2016-11-02 19:05:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\controllers\page.php 179
ERROR - 2016-11-02 19:05:39 --> Severity: Warning  --> Creating default object from empty value C:\xampp\htdocs\jr_comm\application\controllers\page.php 184
ERROR - 2016-11-02 19:05:39 --> 404 Page Not Found --> vendor
ERROR - 2016-11-02 19:05:39 --> 404 Page Not Found --> vendor
ERROR - 2016-11-02 19:05:39 --> 404 Page Not Found --> vendor
ERROR - 2016-11-02 19:05:39 --> 404 Page Not Found --> vendor
ERROR - 2016-11-02 19:05:39 --> 404 Page Not Found --> css
ERROR - 2016-11-02 19:05:40 --> 404 Page Not Found --> vendor
ERROR - 2016-11-02 19:05:40 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:05:40 --> 404 Page Not Found --> vendor
ERROR - 2016-11-02 19:05:41 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:05:41 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:05:41 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:05:41 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:05:41 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:05:41 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:05:41 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:05:41 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:05:41 --> 404 Page Not Found --> js
ERROR - 2016-11-02 19:05:41 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:05:41 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:05:41 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:05:41 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:05:41 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:05:41 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:05:41 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:05:41 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:05:41 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:05:42 --> 404 Page Not Found --> js
ERROR - 2016-11-02 19:07:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 2936
ERROR - 2016-11-02 19:07:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\controllers\page.php 173
ERROR - 2016-11-02 19:07:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\controllers\page.php 179
ERROR - 2016-11-02 19:07:14 --> Severity: Warning  --> Creating default object from empty value C:\xampp\htdocs\jr_comm\application\controllers\page.php 184
ERROR - 2016-11-02 19:07:14 --> 404 Page Not Found --> vendor
ERROR - 2016-11-02 19:07:14 --> 404 Page Not Found --> css
ERROR - 2016-11-02 19:07:14 --> 404 Page Not Found --> vendor
ERROR - 2016-11-02 19:07:14 --> 404 Page Not Found --> vendor
ERROR - 2016-11-02 19:07:14 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:07:14 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:07:14 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:07:14 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:07:14 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:07:14 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:07:14 --> 404 Page Not Found --> vendor
ERROR - 2016-11-02 19:07:14 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:07:14 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:07:14 --> 404 Page Not Found --> js
ERROR - 2016-11-02 19:07:15 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:07:15 --> 404 Page Not Found --> vendor
ERROR - 2016-11-02 19:07:15 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:07:15 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:07:15 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:07:15 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:07:15 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:07:15 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:07:15 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:07:15 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:07:15 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:07:15 --> 404 Page Not Found --> vendor
ERROR - 2016-11-02 19:07:15 --> 404 Page Not Found --> vendor
ERROR - 2016-11-02 19:07:15 --> 404 Page Not Found --> js
ERROR - 2016-11-02 19:13:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 2936
ERROR - 2016-11-02 19:13:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\controllers\page.php 173
ERROR - 2016-11-02 19:13:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\controllers\page.php 179
ERROR - 2016-11-02 19:13:03 --> Severity: Warning  --> Creating default object from empty value C:\xampp\htdocs\jr_comm\application\controllers\page.php 184
ERROR - 2016-11-02 19:13:03 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:13:03 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:13:04 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:16:56 --> Severity: Notice  --> Undefined variable: site_id C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1908
ERROR - 2016-11-02 19:16:56 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1888
ERROR - 2016-11-02 19:16:56 --> Severity: Notice  --> Undefined index: template C:\xampp\htdocs\jr_comm\application\controllers\ems\content.php 68
ERROR - 2016-11-02 19:17:07 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: HTTP request failed! HTTP/1.0 400 Bad Request
 C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2113
ERROR - 2016-11-02 19:17:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2117
ERROR - 2016-11-02 19:17:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2133
ERROR - 2016-11-02 19:17:07 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-02 19:17:08 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-02 19:17:08 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-02 19:17:08 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-02 19:17:08 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-02 19:17:08 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-02 19:17:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:17:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:17:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:17:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:17:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:17:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:17:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:17:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:17:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:17:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:17:08 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-02 19:17:08 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-02 19:17:08 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-02 19:17:29 --> Severity: Notice  --> Undefined variable: message C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 280
ERROR - 2016-11-02 19:17:29 --> Severity: Notice  --> Undefined variable: clientList C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 287
ERROR - 2016-11-02 19:17:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 287
ERROR - 2016-11-02 19:17:29 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 19:17:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 19:17:29 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-02 19:17:29 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-02 19:17:29 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-02 19:17:29 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-02 19:17:29 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-02 19:17:29 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1753
ERROR - 2016-11-02 19:17:29 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-02 19:17:29 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1783
ERROR - 2016-11-02 19:17:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:17:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:17:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:17:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:17:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:17:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:17:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:17:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:17:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:17:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:17:29 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-02 19:17:29 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-02 19:17:29 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-02 19:17:30 --> 404 Page Not Found --> assets
ERROR - 2016-11-02 19:17:34 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\jr_comm\application\controllers\ems\content.php 93
ERROR - 2016-11-02 19:17:34 --> Severity: Notice  --> Undefined variable: res C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php 39
ERROR - 2016-11-02 19:17:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php 39
ERROR - 2016-11-02 19:17:34 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 115 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 19:17:34 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 116 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 7
ERROR - 2016-11-02 19:17:34 --> Severity: Warning  --> Missing argument 6 for create_image(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 117 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 96
ERROR - 2016-11-02 19:17:34 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 123 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 19:17:34 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 124 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 7
ERROR - 2016-11-02 19:17:34 --> Severity: Warning  --> Missing argument 6 for create_image(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 125 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 96
ERROR - 2016-11-02 19:17:34 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 131 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 19:17:34 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 137 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 19:17:34 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 143 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 37
ERROR - 2016-11-02 19:17:34 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 144 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 7
ERROR - 2016-11-02 19:17:34 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 19:17:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 19:17:34 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-02 19:17:34 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-02 19:17:34 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-02 19:17:34 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-02 19:17:34 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-02 19:17:34 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-02 19:17:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:17:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:17:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:17:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:17:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:17:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:17:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:17:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:17:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:17:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:17:34 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-02 19:17:34 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-02 19:17:34 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-02 19:19:44 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\jr_comm\application\controllers\ems\content.php 93
ERROR - 2016-11-02 19:19:44 --> Severity: Notice  --> Undefined variable: res C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php 39
ERROR - 2016-11-02 19:19:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php 39
ERROR - 2016-11-02 19:19:44 --> Severity: Warning  --> Missing argument 5 for create_textfield_not_required(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 115 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 51
ERROR - 2016-11-02 19:19:44 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 116 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 7
ERROR - 2016-11-02 19:19:44 --> Severity: Warning  --> Missing argument 6 for create_image(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 117 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 96
ERROR - 2016-11-02 19:19:44 --> Severity: Warning  --> Missing argument 5 for create_textfield_not_required(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 123 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 51
ERROR - 2016-11-02 19:19:45 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 124 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 7
ERROR - 2016-11-02 19:19:45 --> Severity: Warning  --> Missing argument 6 for create_image(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 125 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 96
ERROR - 2016-11-02 19:19:45 --> Severity: Warning  --> Missing argument 5 for create_textfield_not_required(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 131 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 51
ERROR - 2016-11-02 19:19:45 --> Severity: Warning  --> Missing argument 5 for create_textfield_not_required(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 137 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 51
ERROR - 2016-11-02 19:19:45 --> Severity: Warning  --> Missing argument 5 for create_textfield_not_required(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 143 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 51
ERROR - 2016-11-02 19:19:45 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 144 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 7
ERROR - 2016-11-02 19:19:45 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 19:19:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 19:19:45 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-02 19:19:45 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-02 19:19:45 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-02 19:19:45 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-02 19:19:45 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-02 19:19:45 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-02 19:19:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:19:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:19:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:19:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:19:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:19:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:19:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:19:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:19:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:19:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:19:45 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-02 19:19:45 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-02 19:19:45 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-02 19:20:19 --> Severity: Notice  --> Undefined variable: site_id C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1908
ERROR - 2016-11-02 19:20:19 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1888
ERROR - 2016-11-02 19:20:19 --> Severity: Notice  --> Undefined index: template C:\xampp\htdocs\jr_comm\application\controllers\ems\content.php 68
ERROR - 2016-11-02 19:20:20 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: HTTP request failed! HTTP/1.0 400 Bad Request
 C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2113
ERROR - 2016-11-02 19:20:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2117
ERROR - 2016-11-02 19:20:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2133
ERROR - 2016-11-02 19:20:20 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-02 19:20:20 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-02 19:20:20 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-02 19:20:20 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-02 19:20:20 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-02 19:20:20 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-02 19:20:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:20:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:20:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:20:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:20:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:20:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:20:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:20:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:20:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:20:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:20:20 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-02 19:20:20 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-02 19:20:20 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-02 19:20:28 --> Severity: Notice  --> Undefined variable: message C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 280
ERROR - 2016-11-02 19:20:28 --> Severity: Notice  --> Undefined variable: clientList C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 287
ERROR - 2016-11-02 19:20:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 287
ERROR - 2016-11-02 19:20:28 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 19:20:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 19:20:29 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-02 19:20:29 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-02 19:20:29 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-02 19:20:29 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-02 19:20:29 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-02 19:20:29 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1753
ERROR - 2016-11-02 19:20:29 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-02 19:20:29 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1783
ERROR - 2016-11-02 19:20:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:20:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:20:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:20:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:20:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:20:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:20:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:20:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:20:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:20:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:20:29 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-02 19:20:29 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-02 19:20:29 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-02 19:20:32 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\jr_comm\application\controllers\ems\content.php 93
ERROR - 2016-11-02 19:20:32 --> Severity: Notice  --> Undefined variable: res C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php 39
ERROR - 2016-11-02 19:20:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php 39
ERROR - 2016-11-02 19:20:32 --> Severity: Warning  --> Missing argument 5 for create_textfield_not_required(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 115 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 51
ERROR - 2016-11-02 19:20:32 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 116 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 7
ERROR - 2016-11-02 19:20:32 --> Severity: Warning  --> Missing argument 6 for create_image(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 117 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 96
ERROR - 2016-11-02 19:20:32 --> Severity: Warning  --> Missing argument 5 for create_textfield_not_required(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 123 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 51
ERROR - 2016-11-02 19:20:32 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 124 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 7
ERROR - 2016-11-02 19:20:32 --> Severity: Warning  --> Missing argument 6 for create_image(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 125 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 96
ERROR - 2016-11-02 19:20:32 --> Severity: Warning  --> Missing argument 5 for create_textfield_not_required(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 131 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 51
ERROR - 2016-11-02 19:20:32 --> Severity: Warning  --> Missing argument 5 for create_textfield_not_required(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 137 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 51
ERROR - 2016-11-02 19:20:32 --> Severity: Warning  --> Missing argument 5 for create_textfield_not_required(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 143 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 51
ERROR - 2016-11-02 19:20:32 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 144 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 7
ERROR - 2016-11-02 19:20:32 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 19:20:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 19:20:32 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-02 19:20:32 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-02 19:20:33 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-02 19:20:33 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-02 19:20:33 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-02 19:20:33 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-02 19:20:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:20:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:20:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:20:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:20:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:20:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:20:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:20:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:20:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:20:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:20:33 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-02 19:20:33 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-02 19:20:33 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-02 19:20:53 --> Severity: Notice  --> Undefined variable: site_id C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1908
ERROR - 2016-11-02 19:20:53 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1888
ERROR - 2016-11-02 19:20:53 --> Severity: Notice  --> Undefined index: template C:\xampp\htdocs\jr_comm\application\controllers\ems\content.php 68
ERROR - 2016-11-02 19:20:55 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: HTTP request failed! HTTP/1.0 400 Bad Request
 C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2113
ERROR - 2016-11-02 19:20:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2117
ERROR - 2016-11-02 19:20:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2133
ERROR - 2016-11-02 19:20:55 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-02 19:20:55 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-02 19:20:55 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-02 19:20:55 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-02 19:20:55 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-02 19:20:55 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-02 19:20:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:20:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:20:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:20:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:20:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:20:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:20:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:20:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:20:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:20:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:20:55 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-02 19:20:55 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-02 19:20:55 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-02 19:21:01 --> Severity: Notice  --> Undefined variable: message C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 280
ERROR - 2016-11-02 19:21:01 --> Severity: Notice  --> Undefined variable: clientList C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 287
ERROR - 2016-11-02 19:21:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 287
ERROR - 2016-11-02 19:21:01 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 19:21:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 19:21:01 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-02 19:21:01 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-02 19:21:01 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-02 19:21:01 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-02 19:21:01 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-02 19:21:01 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1753
ERROR - 2016-11-02 19:21:01 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-02 19:21:01 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1783
ERROR - 2016-11-02 19:21:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:01 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-02 19:21:01 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-02 19:21:01 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-02 19:21:04 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\jr_comm\application\controllers\ems\content.php 93
ERROR - 2016-11-02 19:21:04 --> Severity: Notice  --> Undefined variable: res C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php 39
ERROR - 2016-11-02 19:21:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php 39
ERROR - 2016-11-02 19:21:04 --> Severity: Warning  --> Missing argument 5 for create_textfield_not_required(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 115 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 51
ERROR - 2016-11-02 19:21:04 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 116 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 7
ERROR - 2016-11-02 19:21:04 --> Severity: Warning  --> Missing argument 6 for create_image(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 117 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 96
ERROR - 2016-11-02 19:21:04 --> Severity: Warning  --> Missing argument 5 for create_textfield_not_required(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 123 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 51
ERROR - 2016-11-02 19:21:04 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 124 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 7
ERROR - 2016-11-02 19:21:04 --> Severity: Warning  --> Missing argument 6 for create_image(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 125 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 96
ERROR - 2016-11-02 19:21:04 --> Severity: Warning  --> Missing argument 5 for create_textfield_not_required(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 131 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 51
ERROR - 2016-11-02 19:21:04 --> Severity: Warning  --> Missing argument 5 for create_textfield_not_required(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 137 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 51
ERROR - 2016-11-02 19:21:04 --> Severity: Warning  --> Missing argument 5 for create_textfield_not_required(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 143 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 51
ERROR - 2016-11-02 19:21:04 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 144 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 7
ERROR - 2016-11-02 19:21:04 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 19:21:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 19:21:04 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-02 19:21:04 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-02 19:21:04 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-02 19:21:04 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-02 19:21:04 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-02 19:21:04 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-02 19:21:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:04 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-02 19:21:04 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-02 19:21:04 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-02 19:21:25 --> Severity: Notice  --> Undefined variable: site_id C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1908
ERROR - 2016-11-02 19:21:25 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1888
ERROR - 2016-11-02 19:21:25 --> Severity: Notice  --> Undefined index: template C:\xampp\htdocs\jr_comm\application\controllers\ems\content.php 68
ERROR - 2016-11-02 19:21:29 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: HTTP request failed! HTTP/1.0 400 Bad Request
 C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2113
ERROR - 2016-11-02 19:21:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2117
ERROR - 2016-11-02 19:21:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2133
ERROR - 2016-11-02 19:21:29 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-02 19:21:29 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-02 19:21:29 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-02 19:21:29 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-02 19:21:29 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-02 19:21:29 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-02 19:21:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:29 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-02 19:21:29 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-02 19:21:29 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-02 19:21:31 --> Severity: Notice  --> Undefined variable: message C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 280
ERROR - 2016-11-02 19:21:31 --> Severity: Notice  --> Undefined variable: clientList C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 287
ERROR - 2016-11-02 19:21:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 287
ERROR - 2016-11-02 19:21:31 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 19:21:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 19:21:31 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-02 19:21:31 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-02 19:21:31 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-02 19:21:31 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-02 19:21:31 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-02 19:21:31 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1753
ERROR - 2016-11-02 19:21:31 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-02 19:21:31 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1783
ERROR - 2016-11-02 19:21:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:31 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-02 19:21:31 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-02 19:21:31 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-02 19:21:34 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\jr_comm\application\controllers\ems\content.php 93
ERROR - 2016-11-02 19:21:34 --> Severity: Notice  --> Undefined variable: res C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php 39
ERROR - 2016-11-02 19:21:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php 39
ERROR - 2016-11-02 19:21:34 --> Severity: Warning  --> Missing argument 5 for create_textfield_not_required(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 115 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 51
ERROR - 2016-11-02 19:21:34 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 116 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 7
ERROR - 2016-11-02 19:21:34 --> Severity: Warning  --> Missing argument 6 for create_image(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 117 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 96
ERROR - 2016-11-02 19:21:34 --> Severity: Warning  --> Missing argument 5 for create_textfield_not_required(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 123 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 51
ERROR - 2016-11-02 19:21:34 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 124 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 7
ERROR - 2016-11-02 19:21:34 --> Severity: Warning  --> Missing argument 6 for create_image(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 125 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 96
ERROR - 2016-11-02 19:21:34 --> Severity: Warning  --> Missing argument 5 for create_textfield_not_required(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 131 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 51
ERROR - 2016-11-02 19:21:34 --> Severity: Warning  --> Missing argument 5 for create_textfield_not_required(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 137 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 51
ERROR - 2016-11-02 19:21:34 --> Severity: Warning  --> Missing argument 5 for create_textfield_not_required(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 143 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 51
ERROR - 2016-11-02 19:21:34 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 144 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 7
ERROR - 2016-11-02 19:21:34 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 19:21:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 19:21:34 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-02 19:21:34 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-02 19:21:34 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-02 19:21:34 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-02 19:21:34 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-02 19:21:34 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-02 19:21:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:35 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-02 19:21:35 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-02 19:21:35 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-02 19:21:52 --> Severity: Notice  --> Undefined variable: site_id C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1908
ERROR - 2016-11-02 19:21:52 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1888
ERROR - 2016-11-02 19:21:52 --> Severity: Notice  --> Undefined index: template C:\xampp\htdocs\jr_comm\application\controllers\ems\content.php 68
ERROR - 2016-11-02 19:21:54 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: HTTP request failed! HTTP/1.0 400 Bad Request
 C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2113
ERROR - 2016-11-02 19:21:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2117
ERROR - 2016-11-02 19:21:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2133
ERROR - 2016-11-02 19:21:54 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-02 19:21:54 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-02 19:21:54 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-02 19:21:54 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-02 19:21:54 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-02 19:21:54 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-02 19:21:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:55 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-02 19:21:55 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-02 19:21:55 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-02 19:21:57 --> Severity: Notice  --> Undefined variable: message C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 280
ERROR - 2016-11-02 19:21:57 --> Severity: Notice  --> Undefined variable: clientList C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 287
ERROR - 2016-11-02 19:21:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 287
ERROR - 2016-11-02 19:21:57 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 19:21:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 19:21:57 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-02 19:21:57 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-02 19:21:57 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-02 19:21:57 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-02 19:21:57 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-02 19:21:57 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1753
ERROR - 2016-11-02 19:21:57 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-02 19:21:57 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1783
ERROR - 2016-11-02 19:21:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:21:57 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-02 19:21:57 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-02 19:21:57 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-02 19:22:00 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\jr_comm\application\controllers\ems\content.php 93
ERROR - 2016-11-02 19:22:00 --> Severity: Notice  --> Undefined variable: res C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php 39
ERROR - 2016-11-02 19:22:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php 39
ERROR - 2016-11-02 19:22:00 --> Severity: Warning  --> Missing argument 5 for create_textfield_not_required(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 115 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 51
ERROR - 2016-11-02 19:22:00 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 116 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 7
ERROR - 2016-11-02 19:22:00 --> Severity: Warning  --> Missing argument 6 for create_image(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 117 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 96
ERROR - 2016-11-02 19:22:00 --> Severity: Warning  --> Missing argument 5 for create_textfield_not_required(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 123 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 51
ERROR - 2016-11-02 19:22:00 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 124 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 7
ERROR - 2016-11-02 19:22:00 --> Severity: Warning  --> Missing argument 6 for create_image(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 125 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 96
ERROR - 2016-11-02 19:22:00 --> Severity: Warning  --> Missing argument 5 for create_textfield_not_required(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 131 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 51
ERROR - 2016-11-02 19:22:00 --> Severity: Warning  --> Missing argument 5 for create_textfield_not_required(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 137 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 51
ERROR - 2016-11-02 19:22:00 --> Severity: Warning  --> Missing argument 5 for create_textfield_not_required(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 143 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 51
ERROR - 2016-11-02 19:22:00 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 144 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 7
ERROR - 2016-11-02 19:22:00 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 19:22:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 19:22:00 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-02 19:22:00 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-02 19:22:00 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-02 19:22:00 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-02 19:22:00 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-02 19:22:00 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-02 19:22:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:22:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:22:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:22:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:22:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:22:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:22:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:22:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:22:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:22:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:22:00 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-02 19:22:00 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-02 19:22:00 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-02 19:22:16 --> Severity: Notice  --> Undefined variable: site_id C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1908
ERROR - 2016-11-02 19:22:16 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1888
ERROR - 2016-11-02 19:22:16 --> Severity: Notice  --> Undefined index: template C:\xampp\htdocs\jr_comm\application\controllers\ems\content.php 68
ERROR - 2016-11-02 19:22:17 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: HTTP request failed! HTTP/1.0 400 Bad Request
 C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2113
ERROR - 2016-11-02 19:22:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2117
ERROR - 2016-11-02 19:22:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2133
ERROR - 2016-11-02 19:22:17 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-02 19:22:17 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-02 19:22:17 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-02 19:22:17 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-02 19:22:17 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-02 19:22:17 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-02 19:22:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:22:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:22:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:22:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:22:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:22:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:22:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:22:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:22:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:22:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:22:17 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-02 19:22:17 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-02 19:22:17 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-02 19:22:27 --> Severity: Notice  --> Undefined variable: message C:\xampp\htdocs\jr_comm\application\views\ems\menu\manage.php 271
ERROR - 2016-11-02 19:22:27 --> Severity: Notice  --> Undefined variable: clientList C:\xampp\htdocs\jr_comm\application\views\ems\menu\manage.php 278
ERROR - 2016-11-02 19:22:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\menu\manage.php 278
ERROR - 2016-11-02 19:22:27 --> Severity: Notice  --> Undefined variable: htm C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 2840
ERROR - 2016-11-02 19:22:27 --> Severity: Notice  --> Undefined variable: htm C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 2840
ERROR - 2016-11-02 19:22:27 --> Severity: Notice  --> Undefined variable: htm C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 2840
ERROR - 2016-11-02 19:22:27 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 19:22:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 19:22:27 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-02 19:22:27 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-02 19:22:27 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-02 19:22:27 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-02 19:22:27 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-02 19:22:27 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1753
ERROR - 2016-11-02 19:22:27 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-02 19:22:27 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1783
ERROR - 2016-11-02 19:22:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:22:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:22:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:22:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:22:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:22:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:22:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:22:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:22:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:22:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:22:27 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-02 19:22:27 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-02 19:22:27 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-02 19:23:34 --> Severity: Notice  --> Undefined variable: message C:\xampp\htdocs\jr_comm\application\views\ems\menu\manage.php 271
ERROR - 2016-11-02 19:23:34 --> Severity: Notice  --> Undefined variable: clientList C:\xampp\htdocs\jr_comm\application\views\ems\menu\manage.php 278
ERROR - 2016-11-02 19:23:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\menu\manage.php 278
ERROR - 2016-11-02 19:23:34 --> Severity: Notice  --> Undefined variable: htm C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 2840
ERROR - 2016-11-02 19:23:34 --> Severity: Notice  --> Undefined variable: htm C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 2840
ERROR - 2016-11-02 19:23:34 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 19:23:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 19:23:34 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-02 19:23:34 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-02 19:23:34 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-02 19:23:34 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-02 19:23:34 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-02 19:23:34 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1753
ERROR - 2016-11-02 19:23:34 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-02 19:23:34 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1783
ERROR - 2016-11-02 19:23:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:23:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:23:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:23:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:23:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:23:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:23:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:23:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:23:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:23:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:23:35 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-02 19:23:35 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-02 19:23:35 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-02 19:23:43 --> Severity: Notice  --> Undefined variable: message C:\xampp\htdocs\jr_comm\application\views\ems\menu\manage.php 271
ERROR - 2016-11-02 19:23:43 --> Severity: Notice  --> Undefined variable: clientList C:\xampp\htdocs\jr_comm\application\views\ems\menu\manage.php 278
ERROR - 2016-11-02 19:23:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\menu\manage.php 278
ERROR - 2016-11-02 19:23:43 --> Severity: Notice  --> Undefined variable: htm C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 2840
ERROR - 2016-11-02 19:23:43 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 19:23:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 19:23:43 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-02 19:23:43 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-02 19:23:43 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-02 19:23:43 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-02 19:23:43 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-02 19:23:43 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1753
ERROR - 2016-11-02 19:23:43 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-02 19:23:43 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1783
ERROR - 2016-11-02 19:23:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:23:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:23:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:23:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:23:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:23:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:23:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:23:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:23:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:23:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:23:44 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-02 19:23:44 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-02 19:23:44 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-02 19:23:47 --> Severity: Notice  --> Undefined variable: res C:\xampp\htdocs\jr_comm\application\views\ems\menu\addMenuPages.php 54
ERROR - 2016-11-02 19:23:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\menu\addMenuPages.php 54
ERROR - 2016-11-02 19:23:47 --> Severity: Notice  --> Undefined offset: 2 C:\xampp\htdocs\jr_comm\application\views\ems\menu\addMenuPages.php 127
ERROR - 2016-11-02 19:23:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\menu\addMenuPages.php 127
ERROR - 2016-11-02 19:23:47 --> Severity: Notice  --> Undefined offset: 2 C:\xampp\htdocs\jr_comm\application\views\ems\menu\addMenuPages.php 128
ERROR - 2016-11-02 19:23:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\menu\addMenuPages.php 128
ERROR - 2016-11-02 19:23:47 --> Severity: Notice  --> Undefined offset: 3 C:\xampp\htdocs\jr_comm\application\views\ems\menu\addMenuPages.php 127
ERROR - 2016-11-02 19:23:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\menu\addMenuPages.php 127
ERROR - 2016-11-02 19:23:47 --> Severity: Notice  --> Undefined offset: 3 C:\xampp\htdocs\jr_comm\application\views\ems\menu\addMenuPages.php 128
ERROR - 2016-11-02 19:23:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\menu\addMenuPages.php 128
ERROR - 2016-11-02 19:23:47 --> Severity: Notice  --> Undefined offset: 4 C:\xampp\htdocs\jr_comm\application\views\ems\menu\addMenuPages.php 127
ERROR - 2016-11-02 19:23:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\menu\addMenuPages.php 127
ERROR - 2016-11-02 19:23:47 --> Severity: Notice  --> Undefined offset: 4 C:\xampp\htdocs\jr_comm\application\views\ems\menu\addMenuPages.php 128
ERROR - 2016-11-02 19:23:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\menu\addMenuPages.php 128
ERROR - 2016-11-02 19:23:47 --> Severity: Notice  --> Undefined offset: 5 C:\xampp\htdocs\jr_comm\application\views\ems\menu\addMenuPages.php 127
ERROR - 2016-11-02 19:23:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\menu\addMenuPages.php 127
ERROR - 2016-11-02 19:23:47 --> Severity: Notice  --> Undefined offset: 5 C:\xampp\htdocs\jr_comm\application\views\ems\menu\addMenuPages.php 128
ERROR - 2016-11-02 19:23:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\menu\addMenuPages.php 128
ERROR - 2016-11-02 19:23:47 --> Severity: Notice  --> Undefined property: stdClass::$tpl C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 19:23:47 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-02 19:23:47 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-02 19:23:47 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-02 19:23:47 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-02 19:23:47 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-02 19:23:47 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1753
ERROR - 2016-11-02 19:23:47 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-02 19:23:47 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1783
ERROR - 2016-11-02 19:23:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:23:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:23:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:23:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:23:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:23:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:23:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:23:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:23:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:23:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:23:47 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-02 19:23:47 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-02 19:23:47 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-02 19:23:58 --> Severity: Notice  --> Undefined variable: message C:\xampp\htdocs\jr_comm\application\views\ems\menu\manage.php 271
ERROR - 2016-11-02 19:23:58 --> Severity: Notice  --> Undefined variable: clientList C:\xampp\htdocs\jr_comm\application\views\ems\menu\manage.php 278
ERROR - 2016-11-02 19:23:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\menu\manage.php 278
ERROR - 2016-11-02 19:23:58 --> Severity: Notice  --> Undefined variable: htm C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 2840
ERROR - 2016-11-02 19:23:58 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 19:23:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 19:23:58 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-02 19:23:58 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-02 19:23:58 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-02 19:23:58 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-02 19:23:58 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-02 19:23:58 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1753
ERROR - 2016-11-02 19:23:58 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-02 19:23:58 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1783
ERROR - 2016-11-02 19:23:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:23:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:23:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:23:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:23:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:23:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:23:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:23:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:23:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:23:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:23:59 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-02 19:23:59 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-02 19:23:59 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-02 19:24:14 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 19:24:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 19:24:14 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-02 19:24:14 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-02 19:24:14 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-02 19:24:14 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-02 19:24:14 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-02 19:24:14 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1753
ERROR - 2016-11-02 19:24:14 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-02 19:24:14 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1783
ERROR - 2016-11-02 19:24:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:24:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:24:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:24:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:24:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:24:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:24:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:24:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:24:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:24:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:24:14 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-02 19:24:14 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-02 19:24:14 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-02 19:24:53 --> Severity: Notice  --> Undefined variable: message C:\xampp\htdocs\jr_comm\application\views\ems\menu\manage.php 271
ERROR - 2016-11-02 19:24:53 --> Severity: Notice  --> Undefined variable: clientList C:\xampp\htdocs\jr_comm\application\views\ems\menu\manage.php 278
ERROR - 2016-11-02 19:24:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\menu\manage.php 278
ERROR - 2016-11-02 19:24:53 --> Severity: Notice  --> Undefined variable: htm C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 2840
ERROR - 2016-11-02 19:24:53 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 19:24:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 19:24:53 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-02 19:24:53 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-02 19:24:53 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-02 19:24:53 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-02 19:24:53 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-02 19:24:53 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1753
ERROR - 2016-11-02 19:24:53 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-02 19:24:53 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1783
ERROR - 2016-11-02 19:24:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:24:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:24:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:24:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:24:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:24:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:24:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:24:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:24:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:24:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:24:53 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-02 19:24:53 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-02 19:24:53 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-02 19:24:57 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\jr_comm\application\controllers\ems\menu.php 91
ERROR - 2016-11-02 19:24:57 --> Severity: Notice  --> Undefined variable: res C:\xampp\htdocs\jr_comm\application\views\ems\menu\addMenuPages.php 54
ERROR - 2016-11-02 19:24:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\menu\addMenuPages.php 54
ERROR - 2016-11-02 19:24:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\menu\addMenuPages.php 127
ERROR - 2016-11-02 19:24:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\menu\addMenuPages.php 128
ERROR - 2016-11-02 19:24:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\menu\addMenuPages.php 127
ERROR - 2016-11-02 19:24:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\menu\addMenuPages.php 128
ERROR - 2016-11-02 19:24:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\menu\addMenuPages.php 127
ERROR - 2016-11-02 19:24:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\menu\addMenuPages.php 128
ERROR - 2016-11-02 19:24:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\menu\addMenuPages.php 127
ERROR - 2016-11-02 19:24:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\menu\addMenuPages.php 128
ERROR - 2016-11-02 19:24:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\menu\addMenuPages.php 127
ERROR - 2016-11-02 19:24:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\menu\addMenuPages.php 128
ERROR - 2016-11-02 19:24:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\menu\addMenuPages.php 127
ERROR - 2016-11-02 19:24:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\menu\addMenuPages.php 128
ERROR - 2016-11-02 19:24:57 --> Severity: Notice  --> Undefined property: stdClass::$tpl C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 19:24:57 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-02 19:24:57 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-02 19:24:57 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-02 19:24:57 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-02 19:24:57 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-02 19:24:57 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1753
ERROR - 2016-11-02 19:24:57 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-02 19:24:57 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1783
ERROR - 2016-11-02 19:24:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:24:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:24:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:24:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:24:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:24:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:24:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:24:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:24:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:24:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:24:58 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-02 19:24:58 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-02 19:24:58 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-02 19:25:05 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\jr_comm\application\controllers\ems\menu.php 109
ERROR - 2016-11-02 19:25:06 --> Severity: Notice  --> Undefined variable: message C:\xampp\htdocs\jr_comm\application\views\ems\menu\manage.php 271
ERROR - 2016-11-02 19:25:06 --> Severity: Notice  --> Undefined variable: clientList C:\xampp\htdocs\jr_comm\application\views\ems\menu\manage.php 278
ERROR - 2016-11-02 19:25:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\menu\manage.php 278
ERROR - 2016-11-02 19:25:06 --> Severity: Notice  --> Undefined variable: htm C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 2840
ERROR - 2016-11-02 19:25:06 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 19:25:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 19:25:06 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-02 19:25:06 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-02 19:25:06 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-02 19:25:06 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-02 19:25:06 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-02 19:25:06 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1753
ERROR - 2016-11-02 19:25:06 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-02 19:25:06 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1783
ERROR - 2016-11-02 19:25:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:25:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:25:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:25:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:25:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:25:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:25:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:25:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:25:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:25:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:25:06 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-02 19:25:06 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-02 19:25:06 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-02 19:25:09 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 19:25:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 19:25:09 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-02 19:25:09 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-02 19:25:09 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-02 19:25:09 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-02 19:25:09 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-02 19:25:09 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1753
ERROR - 2016-11-02 19:25:09 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-02 19:25:09 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1783
ERROR - 2016-11-02 19:25:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:25:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:25:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:25:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:25:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:25:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:25:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:25:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:25:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:25:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:25:10 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-02 19:25:10 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-02 19:25:10 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-02 19:33:09 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:33:09 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:33:09 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:35:17 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:35:17 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:35:18 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:37:21 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:37:21 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:37:21 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:40:19 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:40:19 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:40:19 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:40:33 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:40:35 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:40:35 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:40:35 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:41:06 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:41:08 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:41:09 --> 404 Page Not Found --> assets
ERROR - 2016-11-02 19:42:47 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:42:48 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:42:48 --> 404 Page Not Found --> assets
ERROR - 2016-11-02 19:42:48 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:46:46 --> Severity: Notice  --> Undefined variable: message C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 280
ERROR - 2016-11-02 19:46:46 --> Severity: Notice  --> Undefined variable: clientList C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 287
ERROR - 2016-11-02 19:46:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 287
ERROR - 2016-11-02 19:46:46 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 19:46:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 19:46:46 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-02 19:46:46 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-02 19:46:46 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-02 19:46:46 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-02 19:46:46 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-02 19:46:46 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1753
ERROR - 2016-11-02 19:46:46 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-02 19:46:46 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1783
ERROR - 2016-11-02 19:46:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:46:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:46:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:46:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:46:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:46:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:46:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:46:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:46:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:46:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:46:46 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-02 19:46:46 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-02 19:46:46 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-02 19:46:50 --> Severity: Notice  --> Undefined index: template C:\xampp\htdocs\jr_comm\application\controllers\ems\content.php 68
ERROR - 2016-11-02 19:46:50 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2113
ERROR - 2016-11-02 19:46:50 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2113
ERROR - 2016-11-02 19:46:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2117
ERROR - 2016-11-02 19:46:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2133
ERROR - 2016-11-02 19:46:50 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-02 19:46:50 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-02 19:46:50 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-02 19:46:50 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-02 19:46:50 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-02 19:46:50 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-02 19:46:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:46:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:46:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:46:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:46:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:46:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:46:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:46:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:46:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:46:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:46:51 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-02 19:46:51 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-02 19:46:51 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-02 19:46:53 --> Severity: Warning  --> Missing argument 1 for top_navigation(), called in C:\xampp\htdocs\jr_comm\application\views\ems\list_content\manage.php on line 278 and defined C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1546
ERROR - 2016-11-02 19:46:53 --> Severity: Notice  --> Undefined variable: menu C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1716
ERROR - 2016-11-02 19:46:53 --> Severity: Notice  --> Undefined variable: menu C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1716
ERROR - 2016-11-02 19:46:53 --> Severity: Notice  --> Undefined variable: htm2 C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1740
ERROR - 2016-11-02 19:46:53 --> Severity: Notice  --> Undefined variable: menu C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1778
ERROR - 2016-11-02 19:46:53 --> Severity: Notice  --> Undefined variable: menu C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1810
ERROR - 2016-11-02 19:46:53 --> Severity: Notice  --> Undefined variable: message C:\xampp\htdocs\jr_comm\application\views\ems\list_content\manage.php 292
ERROR - 2016-11-02 19:46:53 --> Severity: Notice  --> Undefined variable: sliderList C:\xampp\htdocs\jr_comm\application\views\ems\list_content\manage.php 300
ERROR - 2016-11-02 19:46:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\list_content\manage.php 300
ERROR - 2016-11-02 19:46:53 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\jr_comm\application\views\ems\list_content\manage.php 322
ERROR - 2016-11-02 19:46:53 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 19:46:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 19:46:53 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-02 19:46:53 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-02 19:46:53 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-02 19:46:53 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-02 19:46:53 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-02 19:46:53 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1753
ERROR - 2016-11-02 19:46:53 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-02 19:46:53 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1783
ERROR - 2016-11-02 19:46:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:46:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:46:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:46:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:46:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:46:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:46:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:46:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:46:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:46:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:46:54 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-02 19:46:54 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-02 19:46:54 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-02 19:46:56 --> Severity: Notice  --> Undefined variable: res C:\xampp\htdocs\jr_comm\application\views\ems\list_content\add.php 57
ERROR - 2016-11-02 19:46:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\list_content\add.php 57
ERROR - 2016-11-02 19:46:56 --> Severity: Warning  --> Missing argument 6 for create_image(), called in C:\xampp\htdocs\jr_comm\application\views\ems\list_content\add.php on line 127 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 96
ERROR - 2016-11-02 19:46:56 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\jr_comm\application\views\ems\list_content\add.php on line 128 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 7
ERROR - 2016-11-02 19:46:56 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 19:46:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 19:46:56 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-02 19:46:56 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-02 19:46:56 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-02 19:46:56 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-02 19:46:57 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-02 19:46:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:46:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:46:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:46:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:46:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:46:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:46:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:46:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:46:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:46:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:46:57 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-02 19:46:57 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-02 19:46:57 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-02 19:48:03 --> Severity: Notice  --> Undefined variable: site_id C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1908
ERROR - 2016-11-02 19:48:03 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1888
ERROR - 2016-11-02 19:48:03 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2113
ERROR - 2016-11-02 19:48:03 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2113
ERROR - 2016-11-02 19:48:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2117
ERROR - 2016-11-02 19:48:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2133
ERROR - 2016-11-02 19:48:03 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-02 19:48:03 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-02 19:48:03 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-02 19:48:03 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-02 19:48:03 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-02 19:48:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:48:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:48:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:48:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:48:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:48:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:48:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:48:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:48:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:48:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:48:03 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-02 19:48:03 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-02 19:48:03 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-02 19:51:10 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:51:10 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:51:10 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:51:19 --> 404 Page Not Found --> assets
ERROR - 2016-11-02 19:52:03 --> 404 Page Not Found --> assets
ERROR - 2016-11-02 19:52:06 --> 404 Page Not Found --> assets
ERROR - 2016-11-02 19:53:21 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:53:21 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:53:21 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:56:17 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:56:17 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:56:17 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:56:48 --> Severity: Notice  --> Undefined variable: message C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 280
ERROR - 2016-11-02 19:56:48 --> Severity: Notice  --> Undefined variable: clientList C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 287
ERROR - 2016-11-02 19:56:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 287
ERROR - 2016-11-02 19:56:48 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 19:56:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 19:56:48 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-02 19:56:48 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-02 19:56:48 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-02 19:56:48 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-02 19:56:48 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-02 19:56:48 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1753
ERROR - 2016-11-02 19:56:48 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-02 19:56:48 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1783
ERROR - 2016-11-02 19:56:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:56:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:56:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:56:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:56:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:56:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:56:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:56:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:56:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:56:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:56:48 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-02 19:56:48 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-02 19:56:48 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-02 19:56:50 --> 404 Page Not Found --> assets
ERROR - 2016-11-02 19:56:54 --> Severity: Notice  --> Undefined index: template C:\xampp\htdocs\jr_comm\application\controllers\ems\content.php 68
ERROR - 2016-11-02 19:56:54 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2113
ERROR - 2016-11-02 19:56:54 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2113
ERROR - 2016-11-02 19:56:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2117
ERROR - 2016-11-02 19:56:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2133
ERROR - 2016-11-02 19:56:54 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-02 19:56:54 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-02 19:56:54 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-02 19:56:54 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-02 19:56:54 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-02 19:56:55 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-02 19:56:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:56:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:56:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:56:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:56:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:56:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:56:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:56:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:56:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:56:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:56:55 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-02 19:56:55 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-02 19:56:55 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-02 19:57:32 --> Severity: Notice  --> Undefined variable: site_id C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1908
ERROR - 2016-11-02 19:57:32 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1888
ERROR - 2016-11-02 19:57:33 --> Severity: Notice  --> Undefined index: template C:\xampp\htdocs\jr_comm\application\controllers\ems\content.php 68
ERROR - 2016-11-02 19:57:33 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2113
ERROR - 2016-11-02 19:57:33 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2113
ERROR - 2016-11-02 19:57:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2117
ERROR - 2016-11-02 19:57:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2133
ERROR - 2016-11-02 19:57:33 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-02 19:57:33 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-02 19:57:33 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-02 19:57:33 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-02 19:57:33 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-02 19:57:33 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-02 19:57:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:57:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:57:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:57:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:57:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:57:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:57:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:57:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:57:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:57:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 19:57:33 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-02 19:57:33 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-02 19:57:33 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-02 19:57:39 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:57:39 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:57:40 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:57:52 --> 404 Page Not Found --> assets
ERROR - 2016-11-02 19:59:47 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:59:47 --> 404 Page Not Found --> assets
ERROR - 2016-11-02 19:59:47 --> 404 Page Not Found --> img
ERROR - 2016-11-02 19:59:48 --> 404 Page Not Found --> img
ERROR - 2016-11-02 20:01:48 --> 404 Page Not Found --> img
ERROR - 2016-11-02 20:01:48 --> 404 Page Not Found --> img
ERROR - 2016-11-02 20:01:48 --> 404 Page Not Found --> img
ERROR - 2016-11-02 20:02:49 --> 404 Page Not Found --> img
ERROR - 2016-11-02 20:02:49 --> 404 Page Not Found --> img
ERROR - 2016-11-02 20:02:49 --> 404 Page Not Found --> img
ERROR - 2016-11-02 20:03:06 --> Severity: Notice  --> Undefined variable: site_id C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1908
ERROR - 2016-11-02 20:03:06 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1888
ERROR - 2016-11-02 20:03:06 --> Severity: Notice  --> Undefined index: template C:\xampp\htdocs\jr_comm\application\controllers\ems\content.php 68
ERROR - 2016-11-02 20:03:06 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2113
ERROR - 2016-11-02 20:03:06 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2113
ERROR - 2016-11-02 20:03:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2117
ERROR - 2016-11-02 20:03:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2133
ERROR - 2016-11-02 20:03:06 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-02 20:03:06 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-02 20:03:06 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-02 20:03:06 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-02 20:03:06 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-02 20:03:06 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-02 20:03:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:03:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:03:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:03:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:03:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:03:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:03:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:03:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:03:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:03:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:03:06 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-02 20:03:06 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-02 20:03:06 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-02 20:03:09 --> 404 Page Not Found --> img
ERROR - 2016-11-02 20:03:09 --> 404 Page Not Found --> img
ERROR - 2016-11-02 20:03:09 --> 404 Page Not Found --> img
ERROR - 2016-11-02 20:03:48 --> 404 Page Not Found --> img
ERROR - 2016-11-02 20:03:48 --> 404 Page Not Found --> img
ERROR - 2016-11-02 20:03:48 --> 404 Page Not Found --> img
ERROR - 2016-11-02 20:04:05 --> 404 Page Not Found --> img
ERROR - 2016-11-02 20:04:05 --> 404 Page Not Found --> img
ERROR - 2016-11-02 20:04:05 --> 404 Page Not Found --> img
ERROR - 2016-11-02 20:07:04 --> Severity: Notice  --> Undefined variable: message C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 280
ERROR - 2016-11-02 20:07:04 --> Severity: Notice  --> Undefined variable: clientList C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 287
ERROR - 2016-11-02 20:07:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 287
ERROR - 2016-11-02 20:07:04 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 20:07:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 20:07:04 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-02 20:07:04 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-02 20:07:04 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-02 20:07:04 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-02 20:07:04 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-02 20:07:04 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1753
ERROR - 2016-11-02 20:07:04 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-02 20:07:04 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1783
ERROR - 2016-11-02 20:07:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:07:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:07:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:07:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:07:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:07:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:07:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:07:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:07:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:07:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:07:04 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-02 20:07:04 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-02 20:07:04 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-02 20:07:05 --> 404 Page Not Found --> assets
ERROR - 2016-11-02 20:07:09 --> Severity: Notice  --> Undefined index: template C:\xampp\htdocs\jr_comm\application\controllers\ems\content.php 68
ERROR - 2016-11-02 20:07:09 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2113
ERROR - 2016-11-02 20:07:09 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2113
ERROR - 2016-11-02 20:07:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2117
ERROR - 2016-11-02 20:07:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2133
ERROR - 2016-11-02 20:07:09 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-02 20:07:09 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-02 20:07:09 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-02 20:07:09 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-02 20:07:09 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-02 20:07:09 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-02 20:07:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:07:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:07:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:07:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:07:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:07:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:07:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:07:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:07:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:07:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:07:10 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-02 20:07:10 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-02 20:07:10 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-02 20:07:27 --> Severity: Notice  --> Undefined variable: message C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 280
ERROR - 2016-11-02 20:07:27 --> Severity: Notice  --> Undefined variable: clientList C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 287
ERROR - 2016-11-02 20:07:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 287
ERROR - 2016-11-02 20:07:27 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 20:07:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 20:07:28 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-02 20:07:28 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-02 20:07:28 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-02 20:07:28 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-02 20:07:28 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-02 20:07:28 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1753
ERROR - 2016-11-02 20:07:28 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-02 20:07:28 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1783
ERROR - 2016-11-02 20:07:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:07:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:07:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:07:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:07:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:07:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:07:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:07:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:07:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:07:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:07:28 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-02 20:07:28 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-02 20:07:28 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-02 20:07:32 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\jr_comm\application\controllers\ems\content.php 93
ERROR - 2016-11-02 20:07:32 --> Severity: Notice  --> Undefined variable: res C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php 39
ERROR - 2016-11-02 20:07:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php 39
ERROR - 2016-11-02 20:07:32 --> Severity: Warning  --> Missing argument 5 for create_textfield_not_required(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 115 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 51
ERROR - 2016-11-02 20:07:32 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 116 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 7
ERROR - 2016-11-02 20:07:32 --> Severity: Warning  --> Missing argument 6 for create_image(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 117 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 96
ERROR - 2016-11-02 20:07:32 --> Severity: Warning  --> Missing argument 5 for create_textfield_not_required(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 123 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 51
ERROR - 2016-11-02 20:07:32 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 124 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 7
ERROR - 2016-11-02 20:07:32 --> Severity: Warning  --> Missing argument 6 for create_image(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 125 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 96
ERROR - 2016-11-02 20:07:32 --> Severity: Warning  --> Missing argument 5 for create_textfield_not_required(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 131 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 51
ERROR - 2016-11-02 20:07:32 --> Severity: Warning  --> Missing argument 5 for create_textfield_not_required(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 137 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 51
ERROR - 2016-11-02 20:07:32 --> Severity: Warning  --> Missing argument 5 for create_textfield_not_required(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 143 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 51
ERROR - 2016-11-02 20:07:32 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 144 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 7
ERROR - 2016-11-02 20:07:32 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 20:07:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 20:07:32 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-02 20:07:32 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-02 20:07:32 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-02 20:07:32 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-02 20:07:32 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-02 20:07:32 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-02 20:07:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:07:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:07:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:07:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:07:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:07:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:07:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:07:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:07:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:07:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:07:32 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-02 20:07:32 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-02 20:07:32 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-02 20:09:01 --> Severity: Notice  --> Undefined variable: site_id C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1908
ERROR - 2016-11-02 20:09:01 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1888
ERROR - 2016-11-02 20:09:01 --> Severity: Notice  --> Undefined index: template C:\xampp\htdocs\jr_comm\application\controllers\ems\content.php 68
ERROR - 2016-11-02 20:09:01 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2113
ERROR - 2016-11-02 20:09:01 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2113
ERROR - 2016-11-02 20:09:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2117
ERROR - 2016-11-02 20:09:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2133
ERROR - 2016-11-02 20:09:01 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-02 20:09:01 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-02 20:09:01 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-02 20:09:01 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-02 20:09:01 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-02 20:09:01 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-02 20:09:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:09:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:09:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:09:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:09:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:09:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:09:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:09:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:09:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:09:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:09:01 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-02 20:09:01 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-02 20:09:01 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-02 20:09:03 --> 404 Page Not Found --> img
ERROR - 2016-11-02 20:09:03 --> 404 Page Not Found --> img
ERROR - 2016-11-02 20:09:04 --> 404 Page Not Found --> img
ERROR - 2016-11-02 20:10:12 --> Severity: Notice  --> Undefined index: template C:\xampp\htdocs\jr_comm\application\controllers\ems\content.php 68
ERROR - 2016-11-02 20:10:12 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2113
ERROR - 2016-11-02 20:10:12 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2113
ERROR - 2016-11-02 20:10:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2117
ERROR - 2016-11-02 20:10:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2133
ERROR - 2016-11-02 20:10:12 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-02 20:10:12 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-02 20:10:12 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-02 20:10:12 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-02 20:10:12 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-02 20:10:12 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-02 20:10:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:10:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:10:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:10:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:10:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:10:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:10:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:10:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:10:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:10:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:10:12 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-02 20:10:12 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-02 20:10:12 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-02 20:10:15 --> 404 Page Not Found --> img
ERROR - 2016-11-02 20:10:15 --> 404 Page Not Found --> img
ERROR - 2016-11-02 20:10:15 --> 404 Page Not Found --> img
ERROR - 2016-11-02 20:10:25 --> 404 Page Not Found --> img
ERROR - 2016-11-02 20:10:25 --> 404 Page Not Found --> img
ERROR - 2016-11-02 20:10:25 --> 404 Page Not Found --> img
ERROR - 2016-11-02 20:10:40 --> Severity: Notice  --> Undefined variable: site_id C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1908
ERROR - 2016-11-02 20:10:40 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1888
ERROR - 2016-11-02 20:10:41 --> Severity: Notice  --> Undefined index: template C:\xampp\htdocs\jr_comm\application\controllers\ems\content.php 68
ERROR - 2016-11-02 20:10:41 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2113
ERROR - 2016-11-02 20:10:41 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2113
ERROR - 2016-11-02 20:10:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2117
ERROR - 2016-11-02 20:10:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2133
ERROR - 2016-11-02 20:10:41 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-02 20:10:41 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-02 20:10:41 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-02 20:10:41 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-02 20:10:41 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-02 20:10:41 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-02 20:10:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:10:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:10:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:10:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:10:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:10:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:10:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:10:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:10:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:10:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:10:41 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-02 20:10:41 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-02 20:10:41 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-02 20:10:54 --> 404 Page Not Found --> img
ERROR - 2016-11-02 20:10:54 --> 404 Page Not Found --> img
ERROR - 2016-11-02 20:10:54 --> 404 Page Not Found --> img
ERROR - 2016-11-02 20:11:49 --> 404 Page Not Found --> img
ERROR - 2016-11-02 20:11:49 --> 404 Page Not Found --> img
ERROR - 2016-11-02 20:11:49 --> 404 Page Not Found --> img
ERROR - 2016-11-02 20:12:09 --> Severity: Notice  --> Undefined index: template C:\xampp\htdocs\jr_comm\application\controllers\ems\content.php 68
ERROR - 2016-11-02 20:12:09 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2113
ERROR - 2016-11-02 20:12:09 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2113
ERROR - 2016-11-02 20:12:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2117
ERROR - 2016-11-02 20:12:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2133
ERROR - 2016-11-02 20:12:09 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-02 20:12:09 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-02 20:12:09 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-02 20:12:09 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-02 20:12:09 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-02 20:12:09 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-02 20:12:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:12:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:12:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:12:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:12:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:12:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:12:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:12:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:12:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:12:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:12:09 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-02 20:12:09 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-02 20:12:09 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-02 20:12:11 --> 404 Page Not Found --> img
ERROR - 2016-11-02 20:12:11 --> 404 Page Not Found --> img
ERROR - 2016-11-02 20:12:11 --> 404 Page Not Found --> img
ERROR - 2016-11-02 20:17:07 --> 404 Page Not Found --> assets
ERROR - 2016-11-02 20:17:33 --> Severity: Notice  --> Undefined variable: message C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 280
ERROR - 2016-11-02 20:17:33 --> Severity: Notice  --> Undefined variable: clientList C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 287
ERROR - 2016-11-02 20:17:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 287
ERROR - 2016-11-02 20:17:33 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 20:17:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 20:17:33 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-02 20:17:33 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-02 20:17:33 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-02 20:17:33 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-02 20:17:33 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-02 20:17:33 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1753
ERROR - 2016-11-02 20:17:33 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-02 20:17:33 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1783
ERROR - 2016-11-02 20:17:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:17:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:17:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:17:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:17:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:17:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:17:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:17:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:17:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:17:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:17:33 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-02 20:17:33 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-02 20:17:33 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-02 20:17:34 --> 404 Page Not Found --> assets
ERROR - 2016-11-02 20:17:51 --> Severity: Notice  --> Undefined index: template C:\xampp\htdocs\jr_comm\application\controllers\ems\content.php 68
ERROR - 2016-11-02 20:17:51 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2113
ERROR - 2016-11-02 20:17:51 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2113
ERROR - 2016-11-02 20:17:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2117
ERROR - 2016-11-02 20:17:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2133
ERROR - 2016-11-02 20:17:51 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-02 20:17:51 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-02 20:17:51 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-02 20:17:51 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-02 20:17:51 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-02 20:17:51 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-02 20:17:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:17:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:17:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:17:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:17:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:17:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:17:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:17:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:17:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:17:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:17:51 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-02 20:17:51 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-02 20:17:51 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-02 20:17:58 --> Severity: Notice  --> Undefined variable: site_id C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1908
ERROR - 2016-11-02 20:17:58 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1888
ERROR - 2016-11-02 20:17:59 --> Severity: Notice  --> Undefined index: template C:\xampp\htdocs\jr_comm\application\controllers\ems\content.php 68
ERROR - 2016-11-02 20:17:59 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2113
ERROR - 2016-11-02 20:17:59 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2113
ERROR - 2016-11-02 20:17:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2117
ERROR - 2016-11-02 20:17:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2133
ERROR - 2016-11-02 20:17:59 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-02 20:17:59 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-02 20:17:59 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-02 20:17:59 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-02 20:17:59 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-02 20:17:59 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-02 20:17:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:17:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:17:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:17:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:17:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:17:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:17:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:17:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:17:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:17:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:17:59 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-02 20:17:59 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-02 20:17:59 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-02 20:18:02 --> 404 Page Not Found --> img
ERROR - 2016-11-02 20:18:02 --> 404 Page Not Found --> img
ERROR - 2016-11-02 20:18:02 --> 404 Page Not Found --> assets
ERROR - 2016-11-02 20:18:03 --> 404 Page Not Found --> img
ERROR - 2016-11-02 20:18:39 --> 404 Page Not Found --> img
ERROR - 2016-11-02 20:18:39 --> 404 Page Not Found --> assets
ERROR - 2016-11-02 20:18:39 --> 404 Page Not Found --> img
ERROR - 2016-11-02 20:18:39 --> 404 Page Not Found --> img
ERROR - 2016-11-02 20:18:47 --> Severity: Warning  --> Missing argument 1 for top_navigation(), called in C:\xampp\htdocs\jr_comm\application\views\ems\list_content\manage.php on line 278 and defined C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1546
ERROR - 2016-11-02 20:18:47 --> Severity: Notice  --> Undefined variable: menu C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1716
ERROR - 2016-11-02 20:18:47 --> Severity: Notice  --> Undefined variable: menu C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1716
ERROR - 2016-11-02 20:18:47 --> Severity: Notice  --> Undefined variable: htm2 C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1740
ERROR - 2016-11-02 20:18:47 --> Severity: Notice  --> Undefined variable: menu C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1778
ERROR - 2016-11-02 20:18:47 --> Severity: Notice  --> Undefined variable: menu C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1810
ERROR - 2016-11-02 20:18:47 --> Severity: Notice  --> Undefined variable: message C:\xampp\htdocs\jr_comm\application\views\ems\list_content\manage.php 292
ERROR - 2016-11-02 20:18:47 --> Severity: Notice  --> Undefined variable: sliderList C:\xampp\htdocs\jr_comm\application\views\ems\list_content\manage.php 300
ERROR - 2016-11-02 20:18:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\list_content\manage.php 300
ERROR - 2016-11-02 20:18:47 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\jr_comm\application\views\ems\list_content\manage.php 322
ERROR - 2016-11-02 20:18:47 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 20:18:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 20:18:47 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-02 20:18:47 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-02 20:18:47 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-02 20:18:47 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-02 20:18:47 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-02 20:18:47 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1753
ERROR - 2016-11-02 20:18:47 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-02 20:18:47 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1783
ERROR - 2016-11-02 20:18:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:18:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:18:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:18:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:18:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:18:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:18:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:18:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:18:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:18:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:18:47 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-02 20:18:47 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-02 20:18:47 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-02 20:19:09 --> Severity: Notice  --> Undefined variable: res C:\xampp\htdocs\jr_comm\application\views\ems\list_content\add.php 57
ERROR - 2016-11-02 20:19:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\list_content\add.php 57
ERROR - 2016-11-02 20:19:09 --> Severity: Warning  --> Missing argument 6 for create_image(), called in C:\xampp\htdocs\jr_comm\application\views\ems\list_content\add.php on line 132 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 96
ERROR - 2016-11-02 20:19:09 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\jr_comm\application\views\ems\list_content\add.php on line 133 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 7
ERROR - 2016-11-02 20:19:09 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 20:19:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 20:19:09 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-02 20:19:09 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-02 20:19:09 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-02 20:19:09 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-02 20:19:09 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-02 20:19:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:19:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:19:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:19:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:19:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:19:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:19:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:19:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:19:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:19:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:19:10 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-02 20:19:10 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-02 20:19:10 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-02 20:20:04 --> Severity: Notice  --> Undefined variable: site_id C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1908
ERROR - 2016-11-02 20:20:04 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1888
ERROR - 2016-11-02 20:20:04 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2113
ERROR - 2016-11-02 20:20:04 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2113
ERROR - 2016-11-02 20:20:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2117
ERROR - 2016-11-02 20:20:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2133
ERROR - 2016-11-02 20:20:04 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-02 20:20:04 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-02 20:20:04 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-02 20:20:04 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-02 20:20:04 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-02 20:20:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:20:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:20:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:20:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:20:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:20:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:20:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:20:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:20:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:20:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:20:04 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-02 20:20:04 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-02 20:20:05 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-02 20:20:11 --> Severity: Warning  --> Missing argument 1 for top_navigation(), called in C:\xampp\htdocs\jr_comm\application\views\ems\list_content\manage.php on line 278 and defined C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1546
ERROR - 2016-11-02 20:20:11 --> Severity: Notice  --> Undefined variable: menu C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1716
ERROR - 2016-11-02 20:20:11 --> Severity: Notice  --> Undefined variable: menu C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1716
ERROR - 2016-11-02 20:20:11 --> Severity: Notice  --> Undefined variable: htm2 C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1740
ERROR - 2016-11-02 20:20:11 --> Severity: Notice  --> Undefined variable: menu C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1778
ERROR - 2016-11-02 20:20:11 --> Severity: Notice  --> Undefined variable: menu C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1810
ERROR - 2016-11-02 20:20:11 --> Severity: Notice  --> Undefined variable: message C:\xampp\htdocs\jr_comm\application\views\ems\list_content\manage.php 292
ERROR - 2016-11-02 20:20:11 --> Severity: Notice  --> Undefined variable: sliderList C:\xampp\htdocs\jr_comm\application\views\ems\list_content\manage.php 300
ERROR - 2016-11-02 20:20:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\list_content\manage.php 300
ERROR - 2016-11-02 20:20:12 --> Severity: Notice  --> Undefined variable: htm C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 2840
ERROR - 2016-11-02 20:20:12 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 20:20:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 20:20:12 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-02 20:20:12 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-02 20:20:12 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-02 20:20:12 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-02 20:20:12 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-02 20:20:12 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1753
ERROR - 2016-11-02 20:20:12 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-02 20:20:12 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1783
ERROR - 2016-11-02 20:20:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:20:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:20:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:20:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:20:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:20:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:20:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:20:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:20:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:20:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:20:12 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-02 20:20:12 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-02 20:20:12 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-02 20:20:13 --> 404 Page Not Found --> assets
ERROR - 2016-11-02 20:24:02 --> 404 Page Not Found --> img
ERROR - 2016-11-02 20:24:02 --> 404 Page Not Found --> assets
ERROR - 2016-11-02 20:24:02 --> 404 Page Not Found --> img
ERROR - 2016-11-02 20:24:02 --> 404 Page Not Found --> img
ERROR - 2016-11-02 20:24:31 --> 404 Page Not Found --> img
ERROR - 2016-11-02 20:24:31 --> 404 Page Not Found --> img
ERROR - 2016-11-02 20:24:31 --> 404 Page Not Found --> img
ERROR - 2016-11-02 20:25:13 --> Severity: Notice  --> Undefined variable: message C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 280
ERROR - 2016-11-02 20:25:13 --> Severity: Notice  --> Undefined variable: clientList C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 287
ERROR - 2016-11-02 20:25:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 287
ERROR - 2016-11-02 20:25:13 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 20:25:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 20:25:13 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-02 20:25:13 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-02 20:25:13 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-02 20:25:13 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-02 20:25:13 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-02 20:25:13 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1753
ERROR - 2016-11-02 20:25:13 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-02 20:25:13 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1783
ERROR - 2016-11-02 20:25:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:25:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:25:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:25:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:25:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:25:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:25:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:25:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:25:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:25:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:25:13 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-02 20:25:13 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-02 20:25:13 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-02 20:25:26 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 20:25:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 20:25:26 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-02 20:25:26 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-02 20:25:26 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-02 20:25:26 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-02 20:25:26 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-02 20:25:26 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1753
ERROR - 2016-11-02 20:25:26 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-02 20:25:26 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1783
ERROR - 2016-11-02 20:25:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:25:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:25:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:25:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:25:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:25:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:25:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:25:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:25:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:25:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:25:26 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-02 20:25:26 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-02 20:25:26 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-02 20:25:43 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 20:25:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-02 20:25:43 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-02 20:25:43 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-02 20:25:43 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-02 20:25:43 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-02 20:25:43 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-02 20:25:43 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1753
ERROR - 2016-11-02 20:25:43 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-02 20:25:43 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1783
ERROR - 2016-11-02 20:25:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:25:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:25:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:25:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:25:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:25:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:25:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:25:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:25:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:25:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-02 20:25:43 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-02 20:25:43 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-02 20:25:43 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
