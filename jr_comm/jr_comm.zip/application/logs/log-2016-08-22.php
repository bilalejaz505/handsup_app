<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-08-22 14:04:54 --> Severity: Notice  --> Undefined variable: checked_new C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 101
ERROR - 2016-08-22 14:04:54 --> Severity: Notice  --> Undefined variable: checked_commercial C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 105
ERROR - 2016-08-22 14:04:54 --> Severity: Notice  --> Undefined variable: checked_installment C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 115
