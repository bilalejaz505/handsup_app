<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-11-03 17:51:30 --> 404 Page Not Found --> img
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-11-03 17:51:30 --> 404 Page Not Found --> img
ERROR - 2016-11-03 17:51:30 --> 404 Page Not Found --> img
ERROR - 2016-11-03 17:59:06 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin.php 68
ERROR - 2016-11-03 17:59:54 --> Severity: Notice  --> Undefined variable: message C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 280
ERROR - 2016-11-03 17:59:54 --> Severity: Notice  --> Undefined variable: clientList C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 287
ERROR - 2016-11-03 17:59:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 287
ERROR - 2016-11-03 17:59:54 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-03 17:59:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-03 17:59:54 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-03 17:59:54 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-03 17:59:54 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-03 17:59:54 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-03 17:59:54 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-03 17:59:54 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1753
ERROR - 2016-11-03 17:59:54 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-03 17:59:54 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1783
ERROR - 2016-11-03 17:59:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 17:59:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 17:59:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 17:59:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 17:59:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 17:59:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 17:59:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 17:59:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 17:59:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 17:59:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 17:59:55 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-03 17:59:55 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-03 17:59:55 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-03 18:00:05 --> 404 Page Not Found --> assets
ERROR - 2016-11-03 18:00:11 --> Severity: Notice  --> Undefined index: template C:\xampp\htdocs\jr_comm\application\controllers\ems\content.php 68
ERROR - 2016-11-03 18:00:23 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2113
ERROR - 2016-11-03 18:00:23 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2113
ERROR - 2016-11-03 18:00:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2117
ERROR - 2016-11-03 18:00:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2133
ERROR - 2016-11-03 18:00:23 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-03 18:00:23 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-03 18:00:23 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-03 18:00:23 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-03 18:00:23 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-03 18:00:23 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-03 18:00:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:00:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:00:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:00:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:00:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:00:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:00:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:00:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:00:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:00:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:00:24 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-03 18:00:24 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-03 18:00:24 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-03 18:00:58 --> Severity: Notice  --> Undefined variable: site_id C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1908
ERROR - 2016-11-03 18:00:58 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1888
ERROR - 2016-11-03 18:00:58 --> Severity: Notice  --> Undefined index: template C:\xampp\htdocs\jr_comm\application\controllers\ems\content.php 68
ERROR - 2016-11-03 18:01:10 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2113
ERROR - 2016-11-03 18:01:10 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2113
ERROR - 2016-11-03 18:01:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2117
ERROR - 2016-11-03 18:01:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2133
ERROR - 2016-11-03 18:01:11 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-03 18:01:11 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-03 18:01:11 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-03 18:01:11 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-03 18:01:11 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-03 18:01:11 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-03 18:01:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:01:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:01:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:01:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:01:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:01:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:01:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:01:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:01:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:01:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:01:11 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-03 18:01:11 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-03 18:01:11 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-03 18:01:15 --> 404 Page Not Found --> img
ERROR - 2016-11-03 18:01:15 --> 404 Page Not Found --> img
ERROR - 2016-11-03 18:01:16 --> 404 Page Not Found --> img
ERROR - 2016-11-03 18:02:41 --> Severity: Warning  --> Missing argument 1 for top_navigation(), called in C:\xampp\htdocs\jr_comm\application\views\ems\list_content\manage.php on line 278 and defined C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1546
ERROR - 2016-11-03 18:02:41 --> Severity: Notice  --> Undefined variable: menu C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1716
ERROR - 2016-11-03 18:02:41 --> Severity: Notice  --> Undefined variable: menu C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1716
ERROR - 2016-11-03 18:02:41 --> Severity: Notice  --> Undefined variable: htm2 C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1740
ERROR - 2016-11-03 18:02:41 --> Severity: Notice  --> Undefined variable: menu C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1778
ERROR - 2016-11-03 18:02:41 --> Severity: Notice  --> Undefined variable: menu C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1810
ERROR - 2016-11-03 18:02:41 --> Severity: Notice  --> Undefined variable: message C:\xampp\htdocs\jr_comm\application\views\ems\list_content\manage.php 292
ERROR - 2016-11-03 18:02:41 --> Severity: Notice  --> Undefined variable: sliderList C:\xampp\htdocs\jr_comm\application\views\ems\list_content\manage.php 300
ERROR - 2016-11-03 18:02:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\list_content\manage.php 300
ERROR - 2016-11-03 18:02:41 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\jr_comm\application\views\ems\list_content\manage.php 322
ERROR - 2016-11-03 18:02:41 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-03 18:02:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-03 18:02:41 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-03 18:02:41 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-03 18:02:41 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-03 18:02:41 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-03 18:02:41 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-03 18:02:41 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1753
ERROR - 2016-11-03 18:02:41 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-03 18:02:41 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1783
ERROR - 2016-11-03 18:02:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:02:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:02:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:02:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:02:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:02:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:02:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:02:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:02:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:02:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:02:41 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-03 18:02:41 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-03 18:02:41 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-03 18:02:52 --> Severity: Notice  --> Undefined variable: res C:\xampp\htdocs\jr_comm\application\views\ems\list_content\add.php 57
ERROR - 2016-11-03 18:02:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\list_content\add.php 57
ERROR - 2016-11-03 18:02:52 --> Severity: Warning  --> Missing argument 6 for create_image(), called in C:\xampp\htdocs\jr_comm\application\views\ems\list_content\add.php on line 137 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 96
ERROR - 2016-11-03 18:02:52 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\jr_comm\application\views\ems\list_content\add.php on line 138 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 7
ERROR - 2016-11-03 18:02:52 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-03 18:02:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-03 18:02:52 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-03 18:02:52 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-03 18:02:52 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-03 18:02:52 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-03 18:02:52 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-03 18:02:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:02:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:02:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:02:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:02:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:02:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:02:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:02:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:02:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:02:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:02:52 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-03 18:02:52 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-03 18:02:52 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-03 18:04:06 --> Severity: Notice  --> Undefined variable: site_id C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1908
ERROR - 2016-11-03 18:04:06 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1888
ERROR - 2016-11-03 18:04:06 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2113
ERROR - 2016-11-03 18:04:06 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2113
ERROR - 2016-11-03 18:04:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2117
ERROR - 2016-11-03 18:04:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2133
ERROR - 2016-11-03 18:04:06 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-03 18:04:06 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-03 18:04:06 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-03 18:04:06 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-03 18:04:06 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-03 18:04:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:04:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:04:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:04:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:04:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:04:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:04:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:04:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:04:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:04:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:04:07 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-03 18:04:07 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-03 18:04:07 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-03 18:14:28 --> 404 Page Not Found --> img
ERROR - 2016-11-03 18:14:28 --> 404 Page Not Found --> img
ERROR - 2016-11-03 18:14:29 --> 404 Page Not Found --> img
ERROR - 2016-11-03 18:15:00 --> 404 Page Not Found --> img
ERROR - 2016-11-03 18:15:00 --> 404 Page Not Found --> img
ERROR - 2016-11-03 18:15:01 --> 404 Page Not Found --> img
ERROR - 2016-11-03 18:15:06 --> 404 Page Not Found --> assets
ERROR - 2016-11-03 18:16:21 --> 404 Page Not Found --> img
ERROR - 2016-11-03 18:16:21 --> 404 Page Not Found --> img
ERROR - 2016-11-03 18:16:21 --> 404 Page Not Found --> assets
ERROR - 2016-11-03 18:16:22 --> 404 Page Not Found --> img
ERROR - 2016-11-03 18:17:02 --> 404 Page Not Found --> img
ERROR - 2016-11-03 18:17:02 --> 404 Page Not Found --> img
ERROR - 2016-11-03 18:17:02 --> 404 Page Not Found --> img
ERROR - 2016-11-03 18:17:20 --> Severity: Notice  --> Undefined variable: message C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 280
ERROR - 2016-11-03 18:17:20 --> Severity: Notice  --> Undefined variable: clientList C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 287
ERROR - 2016-11-03 18:17:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 287
ERROR - 2016-11-03 18:17:20 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-03 18:17:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-03 18:17:20 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-03 18:17:20 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-03 18:17:20 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-03 18:17:20 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-03 18:17:21 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-03 18:17:21 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1753
ERROR - 2016-11-03 18:17:21 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-03 18:17:21 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1783
ERROR - 2016-11-03 18:17:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:17:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:17:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:17:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:17:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:17:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:17:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:17:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:17:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:17:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:17:21 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-03 18:17:21 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-03 18:17:21 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-03 18:17:21 --> 404 Page Not Found --> assets
ERROR - 2016-11-03 18:17:26 --> Severity: Notice  --> Undefined index: template C:\xampp\htdocs\jr_comm\application\controllers\ems\content.php 68
ERROR - 2016-11-03 18:17:26 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2113
ERROR - 2016-11-03 18:17:26 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2113
ERROR - 2016-11-03 18:17:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2117
ERROR - 2016-11-03 18:17:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2133
ERROR - 2016-11-03 18:17:26 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-03 18:17:26 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-03 18:17:26 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-03 18:17:26 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-03 18:17:26 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-03 18:17:26 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-03 18:17:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:17:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:17:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:17:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:17:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:17:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:17:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:17:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:17:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:17:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:17:27 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-03 18:17:27 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-03 18:17:27 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-03 18:17:41 --> Severity: Notice  --> Undefined variable: site_id C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1908
ERROR - 2016-11-03 18:17:41 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1888
ERROR - 2016-11-03 18:17:41 --> Severity: Notice  --> Undefined index: template C:\xampp\htdocs\jr_comm\application\controllers\ems\content.php 68
ERROR - 2016-11-03 18:17:41 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2113
ERROR - 2016-11-03 18:17:41 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2113
ERROR - 2016-11-03 18:17:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2117
ERROR - 2016-11-03 18:17:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2133
ERROR - 2016-11-03 18:17:41 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-03 18:17:41 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-03 18:17:41 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-03 18:17:41 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-03 18:17:41 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-03 18:17:41 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-03 18:17:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:17:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:17:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:17:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:17:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:17:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:17:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:17:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:17:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:17:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:17:41 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-03 18:17:41 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-03 18:17:41 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-03 18:19:23 --> Severity: Notice  --> Undefined variable: site_id C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1908
ERROR - 2016-11-03 18:19:24 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1888
ERROR - 2016-11-03 18:19:24 --> Severity: Notice  --> Undefined index: template C:\xampp\htdocs\jr_comm\application\controllers\ems\content.php 68
ERROR - 2016-11-03 18:19:24 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2113
ERROR - 2016-11-03 18:19:24 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2113
ERROR - 2016-11-03 18:19:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2117
ERROR - 2016-11-03 18:19:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2133
ERROR - 2016-11-03 18:19:24 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-03 18:19:24 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-03 18:19:24 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-03 18:19:24 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-03 18:19:24 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-03 18:19:24 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-03 18:19:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:19:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:19:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:19:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:19:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:19:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:19:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:19:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:19:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:19:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:19:24 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-03 18:19:24 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-03 18:19:24 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-03 18:21:12 --> 404 Page Not Found --> img
ERROR - 2016-11-03 18:21:12 --> 404 Page Not Found --> img
ERROR - 2016-11-03 18:21:13 --> 404 Page Not Found --> img
ERROR - 2016-11-03 18:21:36 --> Severity: Warning  --> Missing argument 1 for top_navigation(), called in C:\xampp\htdocs\jr_comm\application\views\ems\list_content\manage.php on line 278 and defined C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1546
ERROR - 2016-11-03 18:21:36 --> Severity: Notice  --> Undefined variable: menu C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1716
ERROR - 2016-11-03 18:21:36 --> Severity: Notice  --> Undefined variable: menu C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1716
ERROR - 2016-11-03 18:21:36 --> Severity: Notice  --> Undefined variable: htm2 C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1740
ERROR - 2016-11-03 18:21:36 --> Severity: Notice  --> Undefined variable: menu C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1778
ERROR - 2016-11-03 18:21:36 --> Severity: Notice  --> Undefined variable: menu C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1810
ERROR - 2016-11-03 18:21:36 --> Severity: Notice  --> Undefined variable: message C:\xampp\htdocs\jr_comm\application\views\ems\list_content\manage.php 292
ERROR - 2016-11-03 18:21:36 --> Severity: Notice  --> Undefined variable: sliderList C:\xampp\htdocs\jr_comm\application\views\ems\list_content\manage.php 300
ERROR - 2016-11-03 18:21:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\list_content\manage.php 300
ERROR - 2016-11-03 18:21:36 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\jr_comm\application\views\ems\list_content\manage.php 322
ERROR - 2016-11-03 18:21:36 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-03 18:21:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-03 18:21:36 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-03 18:21:36 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-03 18:21:36 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-03 18:21:36 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-03 18:21:36 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1679
ERROR - 2016-11-03 18:21:36 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1753
ERROR - 2016-11-03 18:21:36 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-03 18:21:36 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1783
ERROR - 2016-11-03 18:21:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:21:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:21:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:21:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:21:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:21:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:21:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:21:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:21:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:21:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:21:36 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-03 18:21:36 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-03 18:21:36 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-03 18:21:39 --> Severity: Notice  --> Undefined variable: res C:\xampp\htdocs\jr_comm\application\views\ems\list_content\add.php 57
ERROR - 2016-11-03 18:21:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\list_content\add.php 57
ERROR - 2016-11-03 18:21:39 --> Severity: Warning  --> Missing argument 6 for create_image(), called in C:\xampp\htdocs\jr_comm\application\views\ems\list_content\add.php on line 142 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 96
ERROR - 2016-11-03 18:21:39 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\jr_comm\application\views\ems\list_content\add.php on line 143 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 7
ERROR - 2016-11-03 18:21:39 --> Severity: Warning  --> Missing argument 5 for create_datepicker(), called in C:\xampp\htdocs\jr_comm\application\views\ems\list_content\add.php on line 144 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 22
ERROR - 2016-11-03 18:21:39 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-03 18:21:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-03 18:21:39 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-03 18:21:39 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-03 18:21:39 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-03 18:21:39 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-03 18:21:39 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-03 18:21:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:21:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:21:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:21:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:21:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:21:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:21:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:21:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:21:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:21:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:21:39 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-03 18:21:39 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-03 18:21:39 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-03 18:21:40 --> 404 Page Not Found --> assets
ERROR - 2016-11-03 18:22:26 --> 404 Page Not Found --> assets
ERROR - 2016-11-03 18:22:26 --> 404 Page Not Found --> assets
ERROR - 2016-11-03 18:22:26 --> 404 Page Not Found --> assets
ERROR - 2016-11-03 18:22:39 --> Severity: Notice  --> Undefined variable: site_id C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1908
ERROR - 2016-11-03 18:22:39 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1888
ERROR - 2016-11-03 18:22:40 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2113
ERROR - 2016-11-03 18:22:40 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2113
ERROR - 2016-11-03 18:22:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2117
ERROR - 2016-11-03 18:22:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2133
ERROR - 2016-11-03 18:22:40 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1357
ERROR - 2016-11-03 18:22:40 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1363
ERROR - 2016-11-03 18:22:40 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1369
ERROR - 2016-11-03 18:22:40 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1397
ERROR - 2016-11-03 18:22:40 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-03 18:22:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:22:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:22:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:22:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:22:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:22:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:22:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:22:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:22:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:22:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1895
ERROR - 2016-11-03 18:22:40 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1981
ERROR - 2016-11-03 18:22:40 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1987
ERROR - 2016-11-03 18:22:40 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1993
ERROR - 2016-11-03 18:22:41 --> 404 Page Not Found --> assets
ERROR - 2016-11-03 18:24:19 --> 404 Page Not Found --> img
ERROR - 2016-11-03 18:24:19 --> 404 Page Not Found --> img
ERROR - 2016-11-03 18:24:19 --> 404 Page Not Found --> img
ERROR - 2016-11-03 18:28:17 --> Severity: Notice  --> Undefined property: stdClass::$eng_pro_date C:\xampp\htdocs\jr_comm\application\views\home.php 468
ERROR - 2016-11-03 18:28:17 --> 404 Page Not Found --> img
ERROR - 2016-11-03 18:28:17 --> 404 Page Not Found --> img
ERROR - 2016-11-03 18:28:17 --> 404 Page Not Found --> img
ERROR - 2016-11-03 18:28:53 --> 404 Page Not Found --> img
ERROR - 2016-11-03 18:28:53 --> 404 Page Not Found --> img
ERROR - 2016-11-03 18:28:54 --> 404 Page Not Found --> img
ERROR - 2016-11-03 18:28:54 --> 404 Page Not Found --> img
ERROR - 2016-11-03 18:28:54 --> 404 Page Not Found --> img
ERROR - 2016-11-03 18:28:54 --> 404 Page Not Found --> img
ERROR - 2016-11-03 18:29:17 --> Severity: Notice  --> Undefined property: stdClass::$eng_pro_date C:\xampp\htdocs\jr_comm\application\views\home.php 468
ERROR - 2016-11-03 18:29:17 --> 404 Page Not Found --> img
ERROR - 2016-11-03 18:30:38 --> 404 Page Not Found --> assets
ERROR - 2016-11-03 18:31:59 --> 404 Page Not Found --> img
ERROR - 2016-11-03 18:35:10 --> 404 Page Not Found --> img
ERROR - 2016-11-03 18:42:53 --> Severity: Notice  --> A non well formed numeric value encountered C:\xampp\htdocs\jr_comm\application\views\home.php 468
ERROR - 2016-11-03 18:42:53 --> 404 Page Not Found --> img
ERROR - 2016-11-03 18:43:15 --> Severity: Notice  --> A non well formed numeric value encountered C:\xampp\htdocs\jr_comm\application\views\home.php 468
ERROR - 2016-11-03 18:43:16 --> 404 Page Not Found --> img
ERROR - 2016-11-03 18:44:40 --> Severity: Notice  --> A non well formed numeric value encountered C:\xampp\htdocs\jr_comm\application\views\home.php 468
ERROR - 2016-11-03 18:44:40 --> 404 Page Not Found --> img
ERROR - 2016-11-03 18:46:25 --> 404 Page Not Found --> assets
ERROR - 2016-11-03 18:51:56 --> Severity: Notice  --> Undefined variable: message C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 280
ERROR - 2016-11-03 18:51:56 --> Severity: Notice  --> Undefined variable: clientList C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 287
ERROR - 2016-11-03 18:51:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 287
ERROR - 2016-11-03 18:51:56 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-03 18:51:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-03 18:51:56 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1365
ERROR - 2016-11-03 18:51:56 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1371
ERROR - 2016-11-03 18:51:56 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1377
ERROR - 2016-11-03 18:51:56 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1405
ERROR - 2016-11-03 18:51:56 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1687
ERROR - 2016-11-03 18:51:56 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-03 18:51:56 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1769
ERROR - 2016-11-03 18:51:56 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1791
ERROR - 2016-11-03 18:51:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 18:51:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 18:51:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 18:51:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 18:51:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 18:51:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 18:51:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 18:51:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 18:51:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 18:51:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 18:51:56 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1989
ERROR - 2016-11-03 18:51:56 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1995
ERROR - 2016-11-03 18:51:56 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 2001
ERROR - 2016-11-03 18:51:57 --> 404 Page Not Found --> assets
ERROR - 2016-11-03 18:52:08 --> Severity: Notice  --> Undefined variable: htm2 C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 3088
ERROR - 2016-11-03 18:52:08 --> Severity: Notice  --> Undefined property: stdClass::$slider_transaction C:\xampp\htdocs\jr_comm\application\views\ems\configuration\edit.php 199
ERROR - 2016-11-03 18:52:08 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-03 18:52:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-03 18:52:08 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1365
ERROR - 2016-11-03 18:52:08 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1371
ERROR - 2016-11-03 18:52:08 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1377
ERROR - 2016-11-03 18:52:08 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1405
ERROR - 2016-11-03 18:52:08 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1687
ERROR - 2016-11-03 18:52:08 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-03 18:52:08 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1769
ERROR - 2016-11-03 18:52:08 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1791
ERROR - 2016-11-03 18:52:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 18:52:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 18:52:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 18:52:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 18:52:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 18:52:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 18:52:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 18:52:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 18:52:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 18:52:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 18:52:08 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1989
ERROR - 2016-11-03 18:52:08 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1995
ERROR - 2016-11-03 18:52:08 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 2001
ERROR - 2016-11-03 18:52:27 --> Severity: Notice  --> Undefined variable: site_id C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1908
ERROR - 2016-11-03 18:52:27 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1888
ERROR - 2016-11-03 18:52:27 --> Severity: Notice  --> Undefined variable: htm2 C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 3088
ERROR - 2016-11-03 18:52:27 --> Severity: Notice  --> Undefined property: stdClass::$slider_transaction C:\xampp\htdocs\jr_comm\application\views\ems\configuration\edit.php 199
ERROR - 2016-11-03 18:52:27 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-03 18:52:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-03 18:52:27 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1365
ERROR - 2016-11-03 18:52:27 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1371
ERROR - 2016-11-03 18:52:27 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1377
ERROR - 2016-11-03 18:52:27 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1405
ERROR - 2016-11-03 18:52:27 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1687
ERROR - 2016-11-03 18:52:27 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-03 18:52:27 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1769
ERROR - 2016-11-03 18:52:27 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1791
ERROR - 2016-11-03 18:52:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 18:52:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 18:52:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 18:52:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 18:52:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 18:52:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 18:52:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 18:52:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 18:52:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 18:52:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 18:52:27 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1989
ERROR - 2016-11-03 18:52:27 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1995
ERROR - 2016-11-03 18:52:27 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 2001
ERROR - 2016-11-03 18:52:35 --> Severity: Notice  --> Undefined variable: message C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 280
ERROR - 2016-11-03 18:52:35 --> Severity: Notice  --> Undefined variable: clientList C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 287
ERROR - 2016-11-03 18:52:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 287
ERROR - 2016-11-03 18:52:35 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-03 18:52:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-03 18:52:35 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1365
ERROR - 2016-11-03 18:52:35 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1371
ERROR - 2016-11-03 18:52:35 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1377
ERROR - 2016-11-03 18:52:35 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1405
ERROR - 2016-11-03 18:52:35 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1687
ERROR - 2016-11-03 18:52:35 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-03 18:52:35 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1769
ERROR - 2016-11-03 18:52:35 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1791
ERROR - 2016-11-03 18:52:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 18:52:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 18:52:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 18:52:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 18:52:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 18:52:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 18:52:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 18:52:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 18:52:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 18:52:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 18:52:35 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1989
ERROR - 2016-11-03 18:52:35 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1995
ERROR - 2016-11-03 18:52:35 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 2001
ERROR - 2016-11-03 18:52:48 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\jr_comm\application\controllers\ems\content.php 93
ERROR - 2016-11-03 18:52:48 --> Severity: Notice  --> Undefined variable: res C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php 39
ERROR - 2016-11-03 18:52:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php 39
ERROR - 2016-11-03 18:52:48 --> Severity: Warning  --> Missing argument 5 for create_textfield_not_required(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 116 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 51
ERROR - 2016-11-03 18:52:48 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 117 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 7
ERROR - 2016-11-03 18:52:48 --> Severity: Warning  --> Missing argument 6 for create_image(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 118 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 96
ERROR - 2016-11-03 18:52:48 --> Severity: Warning  --> Missing argument 5 for create_textfield_not_required(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 124 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 51
ERROR - 2016-11-03 18:52:48 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 125 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 7
ERROR - 2016-11-03 18:52:48 --> Severity: Warning  --> Missing argument 6 for create_image(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 126 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 96
ERROR - 2016-11-03 18:52:48 --> Severity: Warning  --> Missing argument 5 for create_textfield_not_required(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 132 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 51
ERROR - 2016-11-03 18:52:48 --> Severity: Warning  --> Missing argument 5 for create_textfield_not_required(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 138 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 51
ERROR - 2016-11-03 18:52:48 --> Severity: Warning  --> Missing argument 5 for create_textfield_not_required(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 144 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 51
ERROR - 2016-11-03 18:52:48 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 145 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 7
ERROR - 2016-11-03 18:52:48 --> Severity: Warning  --> Missing argument 5 for create_textfield_not_required(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 151 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 51
ERROR - 2016-11-03 18:52:48 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 152 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 7
ERROR - 2016-11-03 18:52:48 --> Severity: Warning  --> Missing argument 6 for create_image(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 153 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 96
ERROR - 2016-11-03 18:52:48 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 159 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 7
ERROR - 2016-11-03 18:52:48 --> Severity: Warning  --> Missing argument 6 for create_image(), called in C:\xampp\htdocs\jr_comm\application\views\ems\contents\add.php on line 160 and defined C:\xampp\htdocs\jr_comm\application\helpers\cms_helper.php 96
ERROR - 2016-11-03 18:52:48 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-03 18:52:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-03 18:52:48 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1365
ERROR - 2016-11-03 18:52:48 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1371
ERROR - 2016-11-03 18:52:48 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1377
ERROR - 2016-11-03 18:52:48 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1405
ERROR - 2016-11-03 18:52:48 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1687
ERROR - 2016-11-03 18:52:48 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1769
ERROR - 2016-11-03 18:52:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 18:52:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 18:52:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 18:52:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 18:52:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 18:52:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 18:52:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 18:52:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 18:52:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 18:52:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 18:52:48 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1989
ERROR - 2016-11-03 18:52:48 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1995
ERROR - 2016-11-03 18:52:48 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 2001
ERROR - 2016-11-03 18:54:49 --> Severity: Notice  --> Undefined variable: site_id C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1908
ERROR - 2016-11-03 18:54:49 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1888
ERROR - 2016-11-03 18:54:49 --> Severity: Notice  --> Undefined index: template C:\xampp\htdocs\jr_comm\application\controllers\ems\content.php 68
ERROR - 2016-11-03 18:54:49 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2113
ERROR - 2016-11-03 18:54:49 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2113
ERROR - 2016-11-03 18:54:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2117
ERROR - 2016-11-03 18:54:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2133
ERROR - 2016-11-03 18:54:49 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1365
ERROR - 2016-11-03 18:54:50 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1371
ERROR - 2016-11-03 18:54:50 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1377
ERROR - 2016-11-03 18:54:50 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1405
ERROR - 2016-11-03 18:54:50 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1687
ERROR - 2016-11-03 18:54:50 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1769
ERROR - 2016-11-03 18:54:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 18:54:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 18:54:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 18:54:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 18:54:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 18:54:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 18:54:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 18:54:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 18:54:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 18:54:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 18:54:50 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1989
ERROR - 2016-11-03 18:54:50 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1995
ERROR - 2016-11-03 18:54:50 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 2001
ERROR - 2016-11-03 19:02:29 --> Severity: Notice  --> Undefined variable: message C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 280
ERROR - 2016-11-03 19:02:29 --> Severity: Notice  --> Undefined variable: clientList C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 287
ERROR - 2016-11-03 19:02:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 287
ERROR - 2016-11-03 19:02:29 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-03 19:02:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-03 19:02:29 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1365
ERROR - 2016-11-03 19:02:29 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1371
ERROR - 2016-11-03 19:02:29 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1377
ERROR - 2016-11-03 19:02:29 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1405
ERROR - 2016-11-03 19:02:29 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1687
ERROR - 2016-11-03 19:02:29 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-03 19:02:29 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1769
ERROR - 2016-11-03 19:02:29 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1791
ERROR - 2016-11-03 19:02:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:02:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:02:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:02:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:02:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:02:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:02:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:02:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:02:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:02:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:02:29 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1989
ERROR - 2016-11-03 19:02:29 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1995
ERROR - 2016-11-03 19:02:29 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 2001
ERROR - 2016-11-03 19:02:30 --> 404 Page Not Found --> assets
ERROR - 2016-11-03 19:02:33 --> Severity: Notice  --> Undefined index: template C:\xampp\htdocs\jr_comm\application\controllers\ems\content.php 68
ERROR - 2016-11-03 19:02:33 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2113
ERROR - 2016-11-03 19:02:33 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2113
ERROR - 2016-11-03 19:02:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2117
ERROR - 2016-11-03 19:02:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2133
ERROR - 2016-11-03 19:02:33 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1365
ERROR - 2016-11-03 19:02:33 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1371
ERROR - 2016-11-03 19:02:33 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1377
ERROR - 2016-11-03 19:02:33 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1405
ERROR - 2016-11-03 19:02:33 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1687
ERROR - 2016-11-03 19:02:33 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1769
ERROR - 2016-11-03 19:02:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:02:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:02:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:02:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:02:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:02:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:02:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:02:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:02:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:02:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:02:33 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1989
ERROR - 2016-11-03 19:02:33 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1995
ERROR - 2016-11-03 19:02:33 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 2001
ERROR - 2016-11-03 19:03:06 --> Severity: Notice  --> Undefined variable: site_id C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1908
ERROR - 2016-11-03 19:03:06 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1888
ERROR - 2016-11-03 19:03:06 --> Severity: Notice  --> Undefined index: template C:\xampp\htdocs\jr_comm\application\controllers\ems\content.php 68
ERROR - 2016-11-03 19:03:06 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2113
ERROR - 2016-11-03 19:03:06 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2113
ERROR - 2016-11-03 19:03:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2117
ERROR - 2016-11-03 19:03:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2133
ERROR - 2016-11-03 19:03:06 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1365
ERROR - 2016-11-03 19:03:06 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1371
ERROR - 2016-11-03 19:03:06 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1377
ERROR - 2016-11-03 19:03:06 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1405
ERROR - 2016-11-03 19:03:06 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1687
ERROR - 2016-11-03 19:03:06 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1769
ERROR - 2016-11-03 19:03:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:03:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:03:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:03:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:03:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:03:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:03:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:03:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:03:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:03:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:03:07 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1989
ERROR - 2016-11-03 19:03:07 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1995
ERROR - 2016-11-03 19:03:07 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 2001
ERROR - 2016-11-03 19:03:11 --> Severity: Notice  --> A non well formed numeric value encountered C:\xampp\htdocs\jr_comm\application\views\home.php 468
ERROR - 2016-11-03 19:03:12 --> 404 Page Not Found --> assets
ERROR - 2016-11-03 19:03:12 --> 404 Page Not Found --> img
ERROR - 2016-11-03 19:10:37 --> Severity: Notice  --> A non well formed numeric value encountered C:\xampp\htdocs\jr_comm\application\views\home.php 468
ERROR - 2016-11-03 19:10:38 --> 404 Page Not Found --> img
ERROR - 2016-11-03 19:11:14 --> Severity: Notice  --> A non well formed numeric value encountered C:\xampp\htdocs\jr_comm\application\views\home.php 468
ERROR - 2016-11-03 19:11:15 --> 404 Page Not Found --> img
ERROR - 2016-11-03 19:17:48 --> Severity: Notice  --> A non well formed numeric value encountered C:\xampp\htdocs\jr_comm\application\views\home.php 468
ERROR - 2016-11-03 19:17:48 --> 404 Page Not Found --> img
ERROR - 2016-11-03 19:18:13 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\xampp\htdocs\jr_comm\system\libraries\Email.php 1553
ERROR - 2016-11-03 19:18:28 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\jr_comm\application\views\ems\inquries\manage.php 321
ERROR - 2016-11-03 19:18:28 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-03 19:18:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-03 19:18:28 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1365
ERROR - 2016-11-03 19:18:28 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1371
ERROR - 2016-11-03 19:18:28 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1377
ERROR - 2016-11-03 19:18:28 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1405
ERROR - 2016-11-03 19:18:28 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1687
ERROR - 2016-11-03 19:18:28 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-03 19:18:28 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1769
ERROR - 2016-11-03 19:18:28 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1791
ERROR - 2016-11-03 19:18:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:18:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:18:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:18:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:18:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:18:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:18:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:18:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:18:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:18:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:18:28 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1989
ERROR - 2016-11-03 19:18:28 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1995
ERROR - 2016-11-03 19:18:28 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 2001
ERROR - 2016-11-03 19:18:29 --> 404 Page Not Found --> assets
ERROR - 2016-11-03 19:22:46 --> Severity: Notice  --> A non well formed numeric value encountered C:\xampp\htdocs\jr_comm\application\views\home.php 470
ERROR - 2016-11-03 19:22:46 --> 404 Page Not Found --> img
ERROR - 2016-11-03 19:23:38 --> Severity: Notice  --> A non well formed numeric value encountered C:\xampp\htdocs\jr_comm\application\views\home.php 470
ERROR - 2016-11-03 19:23:39 --> 404 Page Not Found --> img
ERROR - 2016-11-03 19:23:52 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\xampp\htdocs\jr_comm\system\libraries\Email.php 1553
ERROR - 2016-11-03 19:24:07 --> Severity: Notice  --> Undefined index: max(inq_updated_at) C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 3556
ERROR - 2016-11-03 19:24:07 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-03 19:24:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-03 19:24:08 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1365
ERROR - 2016-11-03 19:24:08 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1371
ERROR - 2016-11-03 19:24:08 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1377
ERROR - 2016-11-03 19:24:08 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1405
ERROR - 2016-11-03 19:24:08 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1687
ERROR - 2016-11-03 19:24:08 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-03 19:24:08 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1769
ERROR - 2016-11-03 19:24:08 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1791
ERROR - 2016-11-03 19:24:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:24:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:24:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:24:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:24:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:24:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:24:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:24:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:24:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:24:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:24:08 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1989
ERROR - 2016-11-03 19:24:08 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1995
ERROR - 2016-11-03 19:24:08 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 2001
ERROR - 2016-11-03 19:24:39 --> Severity: Notice  --> Undefined property: stdClass::$office_title C:\xampp\htdocs\jr_comm\application\views\ems\inquries\view.php 128
ERROR - 2016-11-03 19:24:39 --> Severity: Notice  --> Undefined property: stdClass::$subject_title C:\xampp\htdocs\jr_comm\application\views\ems\inquries\view.php 157
ERROR - 2016-11-03 19:24:39 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-03 19:24:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-03 19:24:39 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1365
ERROR - 2016-11-03 19:24:39 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1371
ERROR - 2016-11-03 19:24:39 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1377
ERROR - 2016-11-03 19:24:40 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1405
ERROR - 2016-11-03 19:24:40 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1687
ERROR - 2016-11-03 19:24:40 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-03 19:24:40 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1769
ERROR - 2016-11-03 19:24:40 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1791
ERROR - 2016-11-03 19:24:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:24:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:24:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:24:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:24:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:24:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:24:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:24:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:24:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:24:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:24:40 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1989
ERROR - 2016-11-03 19:24:40 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1995
ERROR - 2016-11-03 19:24:40 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 2001
ERROR - 2016-11-03 19:25:22 --> Severity: Notice  --> Undefined property: stdClass::$office_title C:\xampp\htdocs\jr_comm\application\views\ems\inquries\view.php 128
ERROR - 2016-11-03 19:25:22 --> Severity: Notice  --> Undefined property: stdClass::$subject_title C:\xampp\htdocs\jr_comm\application\views\ems\inquries\view.php 152
ERROR - 2016-11-03 19:25:22 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-03 19:25:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-03 19:25:22 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1365
ERROR - 2016-11-03 19:25:22 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1371
ERROR - 2016-11-03 19:25:22 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1377
ERROR - 2016-11-03 19:25:22 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1405
ERROR - 2016-11-03 19:25:22 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1687
ERROR - 2016-11-03 19:25:22 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-03 19:25:22 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1769
ERROR - 2016-11-03 19:25:22 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1791
ERROR - 2016-11-03 19:25:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:25:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:25:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:25:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:25:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:25:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:25:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:25:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:25:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:25:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:25:23 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1989
ERROR - 2016-11-03 19:25:23 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1995
ERROR - 2016-11-03 19:25:23 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 2001
ERROR - 2016-11-03 19:26:06 --> Severity: Notice  --> A non well formed numeric value encountered C:\xampp\htdocs\jr_comm\application\views\home.php 470
ERROR - 2016-11-03 19:26:07 --> 404 Page Not Found --> img
ERROR - 2016-11-03 19:27:59 --> Severity: Notice  --> A non well formed numeric value encountered C:\xampp\htdocs\jr_comm\application\views\home.php 470
ERROR - 2016-11-03 19:27:59 --> 404 Page Not Found --> img
ERROR - 2016-11-03 19:28:40 --> Severity: Notice  --> A non well formed numeric value encountered C:\xampp\htdocs\jr_comm\application\views\home.php 470
ERROR - 2016-11-03 19:28:40 --> 404 Page Not Found --> img
ERROR - 2016-11-03 19:30:50 --> Severity: Notice  --> A non well formed numeric value encountered C:\xampp\htdocs\jr_comm\application\views\home.php 470
ERROR - 2016-11-03 19:30:51 --> 404 Page Not Found --> img
ERROR - 2016-11-03 19:33:15 --> Severity: Notice  --> A non well formed numeric value encountered C:\xampp\htdocs\jr_comm\application\views\home.php 470
ERROR - 2016-11-03 19:33:16 --> 404 Page Not Found --> img
ERROR - 2016-11-03 19:34:00 --> Severity: Notice  --> A non well formed numeric value encountered C:\xampp\htdocs\jr_comm\application\views\home.php 449
ERROR - 2016-11-03 19:34:00 --> 404 Page Not Found --> img
ERROR - 2016-11-03 19:35:27 --> Severity: Warning  --> Missing argument 1 for top_navigation(), called in C:\xampp\htdocs\jr_comm\application\views\ems\cmsInUsers\manage.php on line 270 and defined C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1546
ERROR - 2016-11-03 19:35:27 --> Severity: Notice  --> Undefined variable: menu C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1716
ERROR - 2016-11-03 19:35:27 --> Severity: Notice  --> Undefined variable: menu C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1716
ERROR - 2016-11-03 19:35:27 --> Severity: Notice  --> Undefined variable: htm2 C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1740
ERROR - 2016-11-03 19:35:27 --> Severity: Notice  --> Undefined variable: menu C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1778
ERROR - 2016-11-03 19:35:27 --> Severity: Notice  --> Undefined variable: menu C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1810
ERROR - 2016-11-03 19:35:27 --> Severity: Notice  --> Undefined variable: message C:\xampp\htdocs\jr_comm\application\views\ems\cmsInUsers\manage.php 281
ERROR - 2016-11-03 19:35:27 --> Severity: Notice  --> Undefined variable: res C:\xampp\htdocs\jr_comm\application\views\ems\cmsInUsers\manage.php 287
ERROR - 2016-11-03 19:35:27 --> Severity: Notice  --> Undefined variable: htm C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 2840
ERROR - 2016-11-03 19:35:27 --> Severity: Notice  --> Undefined variable: htm C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 2840
ERROR - 2016-11-03 19:35:27 --> Severity: Notice  --> Undefined variable: htm C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 2840
ERROR - 2016-11-03 19:35:27 --> Severity: Notice  --> Undefined variable: htm C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 2840
ERROR - 2016-11-03 19:35:27 --> Severity: Notice  --> Undefined variable: htm C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 2840
ERROR - 2016-11-03 19:35:27 --> Severity: Notice  --> Undefined variable: htm C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 2840
ERROR - 2016-11-03 19:35:28 --> Severity: Notice  --> Undefined variable: htm C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 2840
ERROR - 2016-11-03 19:35:28 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-03 19:35:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-03 19:35:28 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1365
ERROR - 2016-11-03 19:35:28 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1371
ERROR - 2016-11-03 19:35:28 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1377
ERROR - 2016-11-03 19:35:28 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1405
ERROR - 2016-11-03 19:35:28 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1687
ERROR - 2016-11-03 19:35:28 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-03 19:35:28 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1769
ERROR - 2016-11-03 19:35:28 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1791
ERROR - 2016-11-03 19:35:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:35:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:35:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:35:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:35:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:35:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:35:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:35:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:35:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:35:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:35:28 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1989
ERROR - 2016-11-03 19:35:28 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1995
ERROR - 2016-11-03 19:35:28 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 2001
ERROR - 2016-11-03 19:35:31 --> Severity: Warning  --> Missing argument 1 for top_navigation(), called in C:\xampp\htdocs\jr_comm\application\views\ems\cmsInnGroups\manage.php on line 471 and defined C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1546
ERROR - 2016-11-03 19:35:31 --> Severity: Notice  --> Undefined variable: menu C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1716
ERROR - 2016-11-03 19:35:31 --> Severity: Notice  --> Undefined variable: menu C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1716
ERROR - 2016-11-03 19:35:31 --> Severity: Notice  --> Undefined variable: htm2 C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1740
ERROR - 2016-11-03 19:35:31 --> Severity: Notice  --> Undefined variable: menu C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1778
ERROR - 2016-11-03 19:35:31 --> Severity: Notice  --> Undefined variable: menu C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1810
ERROR - 2016-11-03 19:35:31 --> Severity: Notice  --> Undefined variable: message C:\xampp\htdocs\jr_comm\application\views\ems\cmsInnGroups\manage.php 493
ERROR - 2016-11-03 19:35:31 --> Severity: Notice  --> Undefined variable: res C:\xampp\htdocs\jr_comm\application\views\ems\cmsInnGroups\manage.php 505
ERROR - 2016-11-03 19:35:31 --> Severity: Notice  --> Undefined variable: htm C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 2840
ERROR - 2016-11-03 19:35:31 --> Severity: Notice  --> Undefined variable: htm C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 2840
ERROR - 2016-11-03 19:35:31 --> Severity: Notice  --> Undefined variable: htm C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 2840
ERROR - 2016-11-03 19:35:31 --> Severity: Notice  --> Undefined variable: htm C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 2840
ERROR - 2016-11-03 19:35:31 --> Severity: Notice  --> Undefined variable: htm C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 2840
ERROR - 2016-11-03 19:35:31 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-03 19:35:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-03 19:35:31 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1365
ERROR - 2016-11-03 19:35:31 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1371
ERROR - 2016-11-03 19:35:31 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1377
ERROR - 2016-11-03 19:35:31 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1405
ERROR - 2016-11-03 19:35:31 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1687
ERROR - 2016-11-03 19:35:31 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-03 19:35:31 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1769
ERROR - 2016-11-03 19:35:31 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1791
ERROR - 2016-11-03 19:35:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:35:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:35:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:35:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:35:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:35:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:35:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:35:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:35:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:35:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:35:31 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1989
ERROR - 2016-11-03 19:35:31 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1995
ERROR - 2016-11-03 19:35:31 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 2001
ERROR - 2016-11-03 19:37:58 --> Severity: Warning  --> Missing argument 1 for top_navigation(), called in C:\xampp\htdocs\jr_comm\application\views\ems\cmsInnGroups\manage.php on line 471 and defined C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1546
ERROR - 2016-11-03 19:37:58 --> Severity: Notice  --> Undefined variable: menu C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1716
ERROR - 2016-11-03 19:37:58 --> Severity: Notice  --> Undefined variable: menu C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1716
ERROR - 2016-11-03 19:37:58 --> Severity: Notice  --> Undefined variable: htm2 C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1740
ERROR - 2016-11-03 19:37:58 --> Severity: Notice  --> Undefined variable: menu C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1778
ERROR - 2016-11-03 19:37:58 --> Severity: Notice  --> Undefined variable: menu C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1810
ERROR - 2016-11-03 19:37:58 --> Severity: Notice  --> Undefined variable: message C:\xampp\htdocs\jr_comm\application\views\ems\cmsInnGroups\manage.php 493
ERROR - 2016-11-03 19:37:58 --> Severity: Notice  --> Undefined variable: res C:\xampp\htdocs\jr_comm\application\views\ems\cmsInnGroups\manage.php 505
ERROR - 2016-11-03 19:37:58 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\jr_comm\application\views\ems\cmsInnGroups\manage.php 549
ERROR - 2016-11-03 19:37:58 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-03 19:37:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-03 19:37:58 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1365
ERROR - 2016-11-03 19:37:58 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1371
ERROR - 2016-11-03 19:37:58 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1377
ERROR - 2016-11-03 19:37:58 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1405
ERROR - 2016-11-03 19:37:58 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1687
ERROR - 2016-11-03 19:37:58 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-03 19:37:58 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1769
ERROR - 2016-11-03 19:37:58 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1791
ERROR - 2016-11-03 19:37:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:37:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:37:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:37:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:37:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:37:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:37:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:37:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:37:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:37:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:37:58 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1989
ERROR - 2016-11-03 19:37:59 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1995
ERROR - 2016-11-03 19:37:59 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 2001
ERROR - 2016-11-03 19:38:04 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin.php 68
ERROR - 2016-11-03 19:38:35 --> Severity: Notice  --> Undefined variable: message C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 280
ERROR - 2016-11-03 19:38:35 --> Severity: Notice  --> Undefined variable: clientList C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 287
ERROR - 2016-11-03 19:38:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 287
ERROR - 2016-11-03 19:38:36 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-03 19:38:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-03 19:38:36 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1365
ERROR - 2016-11-03 19:38:36 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1371
ERROR - 2016-11-03 19:38:36 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1377
ERROR - 2016-11-03 19:38:36 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1405
ERROR - 2016-11-03 19:38:36 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1687
ERROR - 2016-11-03 19:38:36 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-03 19:38:36 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1769
ERROR - 2016-11-03 19:38:36 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1791
ERROR - 2016-11-03 19:38:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:38:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:38:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:38:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:38:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:38:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:38:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:38:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:38:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:38:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:38:36 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1989
ERROR - 2016-11-03 19:38:36 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1995
ERROR - 2016-11-03 19:38:36 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 2001
ERROR - 2016-11-03 19:38:45 --> Severity: Notice  --> Undefined variable: message C:\xampp\htdocs\jr_comm\application\views\ems\menu\manage.php 271
ERROR - 2016-11-03 19:38:45 --> Severity: Notice  --> Undefined variable: clientList C:\xampp\htdocs\jr_comm\application\views\ems\menu\manage.php 278
ERROR - 2016-11-03 19:38:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\menu\manage.php 278
ERROR - 2016-11-03 19:38:45 --> Severity: Notice  --> Undefined variable: htm C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 2840
ERROR - 2016-11-03 19:38:45 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-03 19:38:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-03 19:38:45 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1365
ERROR - 2016-11-03 19:38:45 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1371
ERROR - 2016-11-03 19:38:45 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1377
ERROR - 2016-11-03 19:38:45 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1405
ERROR - 2016-11-03 19:38:45 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1687
ERROR - 2016-11-03 19:38:45 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-03 19:38:45 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1769
ERROR - 2016-11-03 19:38:45 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1791
ERROR - 2016-11-03 19:38:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:38:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:38:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:38:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:38:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:38:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:38:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:38:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:38:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:38:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:38:45 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1989
ERROR - 2016-11-03 19:38:45 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1995
ERROR - 2016-11-03 19:38:45 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 2001
ERROR - 2016-11-03 19:38:48 --> Severity: Warning  --> Missing argument 1 for top_navigation(), called in C:\xampp\htdocs\jr_comm\application\views\ems\cmsInUsers\manage.php on line 270 and defined C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1546
ERROR - 2016-11-03 19:38:48 --> Severity: Notice  --> Undefined variable: menu C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1716
ERROR - 2016-11-03 19:38:48 --> Severity: Notice  --> Undefined variable: menu C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1716
ERROR - 2016-11-03 19:38:48 --> Severity: Notice  --> Undefined variable: htm2 C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1740
ERROR - 2016-11-03 19:38:48 --> Severity: Notice  --> Undefined variable: menu C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1778
ERROR - 2016-11-03 19:38:48 --> Severity: Notice  --> Undefined variable: menu C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1810
ERROR - 2016-11-03 19:38:48 --> Severity: Notice  --> Undefined variable: message C:\xampp\htdocs\jr_comm\application\views\ems\cmsInUsers\manage.php 281
ERROR - 2016-11-03 19:38:48 --> Severity: Notice  --> Undefined variable: res C:\xampp\htdocs\jr_comm\application\views\ems\cmsInUsers\manage.php 287
ERROR - 2016-11-03 19:38:48 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\jr_comm\application\views\ems\cmsInUsers\manage.php 309
ERROR - 2016-11-03 19:38:48 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-03 19:38:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-03 19:38:48 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1365
ERROR - 2016-11-03 19:38:48 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1371
ERROR - 2016-11-03 19:38:48 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1377
ERROR - 2016-11-03 19:38:48 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1405
ERROR - 2016-11-03 19:38:49 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1687
ERROR - 2016-11-03 19:38:49 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-03 19:38:49 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1769
ERROR - 2016-11-03 19:38:49 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1791
ERROR - 2016-11-03 19:38:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:38:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:38:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:38:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:38:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:38:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:38:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:38:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:38:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:38:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:38:49 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1989
ERROR - 2016-11-03 19:38:49 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1995
ERROR - 2016-11-03 19:38:49 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 2001
ERROR - 2016-11-03 19:38:54 --> Severity: Warning  --> Missing argument 1 for top_navigation(), called in C:\xampp\htdocs\jr_comm\application\views\ems\cmsInnGroups\manage.php on line 471 and defined C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1546
ERROR - 2016-11-03 19:38:54 --> Severity: Notice  --> Undefined variable: menu C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1716
ERROR - 2016-11-03 19:38:54 --> Severity: Notice  --> Undefined variable: menu C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1716
ERROR - 2016-11-03 19:38:54 --> Severity: Notice  --> Undefined variable: htm2 C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1740
ERROR - 2016-11-03 19:38:54 --> Severity: Notice  --> Undefined variable: menu C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1778
ERROR - 2016-11-03 19:38:54 --> Severity: Notice  --> Undefined variable: menu C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 1810
ERROR - 2016-11-03 19:38:54 --> Severity: Notice  --> Undefined variable: message C:\xampp\htdocs\jr_comm\application\views\ems\cmsInnGroups\manage.php 493
ERROR - 2016-11-03 19:38:54 --> Severity: Notice  --> Undefined variable: res C:\xampp\htdocs\jr_comm\application\views\ems\cmsInnGroups\manage.php 505
ERROR - 2016-11-03 19:38:54 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\jr_comm\application\views\ems\cmsInnGroups\manage.php 549
ERROR - 2016-11-03 19:38:54 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-03 19:38:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-03 19:38:54 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1365
ERROR - 2016-11-03 19:38:54 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1371
ERROR - 2016-11-03 19:38:54 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1377
ERROR - 2016-11-03 19:38:54 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1405
ERROR - 2016-11-03 19:38:54 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1687
ERROR - 2016-11-03 19:38:54 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-03 19:38:54 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1769
ERROR - 2016-11-03 19:38:54 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1791
ERROR - 2016-11-03 19:38:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:38:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:38:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:38:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:38:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:38:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:38:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:38:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:38:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:38:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:38:54 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1989
ERROR - 2016-11-03 19:38:54 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1995
ERROR - 2016-11-03 19:38:54 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 2001
ERROR - 2016-11-03 19:38:58 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-03 19:38:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-03 19:38:58 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1365
ERROR - 2016-11-03 19:38:58 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1371
ERROR - 2016-11-03 19:38:58 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1377
ERROR - 2016-11-03 19:38:58 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1405
ERROR - 2016-11-03 19:38:58 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1687
ERROR - 2016-11-03 19:38:58 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-03 19:38:58 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1769
ERROR - 2016-11-03 19:38:58 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1791
ERROR - 2016-11-03 19:38:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:38:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:38:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:38:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:38:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:38:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:38:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:38:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:38:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:38:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:38:58 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1989
ERROR - 2016-11-03 19:38:58 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1995
ERROR - 2016-11-03 19:38:58 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 2001
ERROR - 2016-11-03 19:39:01 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-03 19:39:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-03 19:39:01 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1365
ERROR - 2016-11-03 19:39:01 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1371
ERROR - 2016-11-03 19:39:01 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1377
ERROR - 2016-11-03 19:39:01 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1405
ERROR - 2016-11-03 19:39:01 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1687
ERROR - 2016-11-03 19:39:01 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-03 19:39:01 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1769
ERROR - 2016-11-03 19:39:01 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1791
ERROR - 2016-11-03 19:39:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:39:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:39:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:39:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:39:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:39:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:39:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:39:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:39:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:39:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:39:02 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1989
ERROR - 2016-11-03 19:39:02 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1995
ERROR - 2016-11-03 19:39:02 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 2001
ERROR - 2016-11-03 19:39:04 --> Severity: Notice  --> Undefined variable: htm2 C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 3088
ERROR - 2016-11-03 19:39:04 --> Severity: Notice  --> Undefined property: stdClass::$smtp_host C:\xampp\htdocs\jr_comm\application\views\ems\social\edit.php 177
ERROR - 2016-11-03 19:39:04 --> Severity: Notice  --> Undefined property: stdClass::$smtp_email C:\xampp\htdocs\jr_comm\application\views\ems\social\edit.php 185
ERROR - 2016-11-03 19:39:04 --> Severity: Notice  --> Undefined property: stdClass::$smtp_password C:\xampp\htdocs\jr_comm\application\views\ems\social\edit.php 194
ERROR - 2016-11-03 19:39:04 --> Severity: Notice  --> Undefined property: stdClass::$smtp_port C:\xampp\htdocs\jr_comm\application\views\ems\social\edit.php 203
ERROR - 2016-11-03 19:39:04 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-03 19:39:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-03 19:39:04 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1365
ERROR - 2016-11-03 19:39:04 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1371
ERROR - 2016-11-03 19:39:04 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1377
ERROR - 2016-11-03 19:39:04 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1405
ERROR - 2016-11-03 19:39:04 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1687
ERROR - 2016-11-03 19:39:04 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-03 19:39:04 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1769
ERROR - 2016-11-03 19:39:04 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1791
ERROR - 2016-11-03 19:39:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:39:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:39:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:39:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:39:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:39:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:39:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:39:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:39:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:39:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:39:04 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1989
ERROR - 2016-11-03 19:39:04 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1995
ERROR - 2016-11-03 19:39:04 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 2001
ERROR - 2016-11-03 19:39:07 --> Severity: Notice  --> Undefined index: max(inq_updated_at) C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 3556
ERROR - 2016-11-03 19:39:07 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-03 19:39:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-03 19:39:07 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1365
ERROR - 2016-11-03 19:39:07 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1371
ERROR - 2016-11-03 19:39:07 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1377
ERROR - 2016-11-03 19:39:07 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1405
ERROR - 2016-11-03 19:39:07 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1687
ERROR - 2016-11-03 19:39:07 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-03 19:39:07 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1769
ERROR - 2016-11-03 19:39:07 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1791
ERROR - 2016-11-03 19:39:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:39:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:39:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:39:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:39:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:39:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:39:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:39:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:39:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:39:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:39:07 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1989
ERROR - 2016-11-03 19:39:07 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1995
ERROR - 2016-11-03 19:39:07 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 2001
ERROR - 2016-11-03 19:39:16 --> Severity: Notice  --> Undefined variable: htm2 C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 3088
ERROR - 2016-11-03 19:39:16 --> Severity: Notice  --> Undefined property: stdClass::$slider_transaction C:\xampp\htdocs\jr_comm\application\views\ems\configuration\edit.php 199
ERROR - 2016-11-03 19:39:16 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-03 19:39:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-03 19:39:16 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1365
ERROR - 2016-11-03 19:39:16 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1371
ERROR - 2016-11-03 19:39:16 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1377
ERROR - 2016-11-03 19:39:16 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1405
ERROR - 2016-11-03 19:39:16 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1687
ERROR - 2016-11-03 19:39:16 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-03 19:39:16 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1769
ERROR - 2016-11-03 19:39:16 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1791
ERROR - 2016-11-03 19:39:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:39:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:39:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:39:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:39:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:39:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:39:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:39:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:39:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:39:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:39:16 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1989
ERROR - 2016-11-03 19:39:16 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1995
ERROR - 2016-11-03 19:39:16 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 2001
ERROR - 2016-11-03 19:41:26 --> Severity: Notice  --> Undefined variable: htm2 C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 3088
ERROR - 2016-11-03 19:41:26 --> Severity: Notice  --> Undefined property: stdClass::$slider_transaction C:\xampp\htdocs\jr_comm\application\views\ems\configuration\edit.php 199
ERROR - 2016-11-03 19:41:26 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-03 19:41:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-03 19:41:26 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1365
ERROR - 2016-11-03 19:41:26 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1371
ERROR - 2016-11-03 19:41:26 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1377
ERROR - 2016-11-03 19:41:26 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1405
ERROR - 2016-11-03 19:41:26 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1687
ERROR - 2016-11-03 19:41:26 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-03 19:41:26 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1769
ERROR - 2016-11-03 19:41:26 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1791
ERROR - 2016-11-03 19:41:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:41:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:41:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:41:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:41:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:41:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:41:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:41:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:41:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:41:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:41:27 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1989
ERROR - 2016-11-03 19:41:27 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1995
ERROR - 2016-11-03 19:41:27 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 2001
ERROR - 2016-11-03 19:42:49 --> Severity: Notice  --> Undefined variable: htm2 C:\xampp\htdocs\jr_comm\application\helpers\custom_helper.php 3088
ERROR - 2016-11-03 19:42:50 --> Severity: Notice  --> Undefined property: stdClass::$slider_transaction C:\xampp\htdocs\jr_comm\application\views\ems\configuration\edit.php 199
ERROR - 2016-11-03 19:42:50 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-03 19:42:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-03 19:42:50 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1365
ERROR - 2016-11-03 19:42:50 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1371
ERROR - 2016-11-03 19:42:50 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1377
ERROR - 2016-11-03 19:42:50 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1405
ERROR - 2016-11-03 19:42:50 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1687
ERROR - 2016-11-03 19:42:50 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-03 19:42:50 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1769
ERROR - 2016-11-03 19:42:50 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1791
ERROR - 2016-11-03 19:42:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:42:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:42:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:42:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:42:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:42:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:42:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:42:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:42:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:42:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:42:50 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1989
ERROR - 2016-11-03 19:42:50 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1995
ERROR - 2016-11-03 19:42:50 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 2001
ERROR - 2016-11-03 19:42:52 --> Severity: Notice  --> Undefined variable: message C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 280
ERROR - 2016-11-03 19:42:52 --> Severity: Notice  --> Undefined variable: clientList C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 287
ERROR - 2016-11-03 19:42:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 287
ERROR - 2016-11-03 19:42:52 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-03 19:42:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-03 19:42:53 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1365
ERROR - 2016-11-03 19:42:53 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1371
ERROR - 2016-11-03 19:42:53 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1377
ERROR - 2016-11-03 19:42:53 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1405
ERROR - 2016-11-03 19:42:53 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1687
ERROR - 2016-11-03 19:42:53 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-03 19:42:53 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1769
ERROR - 2016-11-03 19:42:53 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1791
ERROR - 2016-11-03 19:42:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:42:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:42:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:42:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:42:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:42:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:42:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:42:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:42:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:42:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:42:53 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1989
ERROR - 2016-11-03 19:42:53 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1995
ERROR - 2016-11-03 19:42:53 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 2001
ERROR - 2016-11-03 19:42:58 --> Severity: Notice  --> Undefined index: template C:\xampp\htdocs\jr_comm\application\controllers\ems\content.php 68
ERROR - 2016-11-03 19:42:58 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2113
ERROR - 2016-11-03 19:42:58 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2113
ERROR - 2016-11-03 19:42:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2117
ERROR - 2016-11-03 19:42:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\libraries\google_maps.php 2133
ERROR - 2016-11-03 19:42:58 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1365
ERROR - 2016-11-03 19:42:58 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1371
ERROR - 2016-11-03 19:42:58 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1377
ERROR - 2016-11-03 19:42:58 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1405
ERROR - 2016-11-03 19:42:58 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1687
ERROR - 2016-11-03 19:42:59 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1769
ERROR - 2016-11-03 19:42:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:42:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:42:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:42:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:42:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:42:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:42:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:42:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:42:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:42:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:42:59 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1989
ERROR - 2016-11-03 19:42:59 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1995
ERROR - 2016-11-03 19:42:59 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 2001
ERROR - 2016-11-03 19:43:02 --> Severity: Notice  --> Undefined variable: message C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 280
ERROR - 2016-11-03 19:43:02 --> Severity: Notice  --> Undefined variable: clientList C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 287
ERROR - 2016-11-03 19:43:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\ems\contents\manage.php 287
ERROR - 2016-11-03 19:43:02 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-03 19:43:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 343
ERROR - 2016-11-03 19:43:02 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1365
ERROR - 2016-11-03 19:43:02 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1371
ERROR - 2016-11-03 19:43:02 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1377
ERROR - 2016-11-03 19:43:02 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1405
ERROR - 2016-11-03 19:43:02 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1687
ERROR - 2016-11-03 19:43:02 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1761
ERROR - 2016-11-03 19:43:02 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1769
ERROR - 2016-11-03 19:43:02 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1791
ERROR - 2016-11-03 19:43:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:43:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:43:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:43:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:43:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:43:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:43:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:43:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:43:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:43:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1903
ERROR - 2016-11-03 19:43:02 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1989
ERROR - 2016-11-03 19:43:02 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 1995
ERROR - 2016-11-03 19:43:02 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\jr_comm\application\views\layouts\admin_inner.php 2001
