<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-08-12 09:56:13 --> 404 Page Not Found --> sms_api
ERROR - 2016-08-12 21:09:29 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin.php 68
ERROR - 2016-08-12 21:09:56 --> Severity: Notice  --> Undefined variable: message C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\manage.php 280
ERROR - 2016-08-12 21:09:56 --> Severity: Notice  --> Undefined variable: clientList C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\manage.php 287
ERROR - 2016-08-12 21:09:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\manage.php 287
ERROR - 2016-08-12 21:09:56 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 161
ERROR - 2016-08-12 21:09:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 161
ERROR - 2016-08-12 21:09:56 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 690
ERROR - 2016-08-12 21:09:56 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 693
ERROR - 2016-08-12 21:09:56 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 696
ERROR - 2016-08-12 21:09:56 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 710
ERROR - 2016-08-12 21:09:56 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 851
ERROR - 2016-08-12 21:09:56 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 888
ERROR - 2016-08-12 21:09:56 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 892
ERROR - 2016-08-12 21:09:56 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 903
ERROR - 2016-08-12 21:09:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-12 21:09:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-12 21:09:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-12 21:09:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-12 21:09:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-12 21:09:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-12 21:09:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-12 21:09:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-12 21:09:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-12 21:09:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-12 21:09:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-12 21:09:56 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1002
ERROR - 2016-08-12 21:09:56 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1005
ERROR - 2016-08-12 21:09:56 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1008
ERROR - 2016-08-12 21:09:58 --> 404 Page Not Found --> assets
ERROR - 2016-08-12 21:10:29 --> Severity: Notice  --> Undefined index: template C:\xampp\htdocs\tajeer_finance\application\controllers\ems\content.php 68
ERROR - 2016-08-12 21:10:30 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2113
ERROR - 2016-08-12 21:10:30 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2113
ERROR - 2016-08-12 21:10:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2117
ERROR - 2016-08-12 21:10:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2133
ERROR - 2016-08-12 21:10:30 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 690
ERROR - 2016-08-12 21:10:30 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 693
ERROR - 2016-08-12 21:10:30 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 696
ERROR - 2016-08-12 21:10:30 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 710
ERROR - 2016-08-12 21:10:30 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 851
ERROR - 2016-08-12 21:10:30 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 892
ERROR - 2016-08-12 21:10:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-12 21:10:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-12 21:10:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-12 21:10:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-12 21:10:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-12 21:10:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-12 21:10:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-12 21:10:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-12 21:10:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-12 21:10:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-12 21:10:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-12 21:10:30 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1002
ERROR - 2016-08-12 21:10:30 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1005
ERROR - 2016-08-12 21:10:30 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1008
ERROR - 2016-08-12 21:10:46 --> Severity: Warning  --> Missing argument 1 for top_navigation(), called in C:\xampp\htdocs\tajeer_finance\application\views\ems\list_content\manage.php on line 278 and defined C:\xampp\htdocs\tajeer_finance\application\helpers\custom_helper.php 1547
ERROR - 2016-08-12 21:10:46 --> Severity: Notice  --> Undefined variable: menu C:\xampp\htdocs\tajeer_finance\application\helpers\custom_helper.php 1717
ERROR - 2016-08-12 21:10:46 --> Severity: Notice  --> Undefined variable: menu C:\xampp\htdocs\tajeer_finance\application\helpers\custom_helper.php 1717
ERROR - 2016-08-12 21:10:46 --> Severity: Notice  --> Undefined variable: htm2 C:\xampp\htdocs\tajeer_finance\application\helpers\custom_helper.php 1741
ERROR - 2016-08-12 21:10:46 --> Severity: Notice  --> Undefined variable: menu C:\xampp\htdocs\tajeer_finance\application\helpers\custom_helper.php 1779
ERROR - 2016-08-12 21:10:46 --> Severity: Notice  --> Undefined variable: menu C:\xampp\htdocs\tajeer_finance\application\helpers\custom_helper.php 1811
ERROR - 2016-08-12 21:10:46 --> Severity: Notice  --> Undefined variable: message C:\xampp\htdocs\tajeer_finance\application\views\ems\list_content\manage.php 292
ERROR - 2016-08-12 21:10:46 --> Severity: Notice  --> Undefined variable: sliderList C:\xampp\htdocs\tajeer_finance\application\views\ems\list_content\manage.php 300
ERROR - 2016-08-12 21:10:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\ems\list_content\manage.php 300
ERROR - 2016-08-12 21:10:46 --> Severity: Notice  --> Undefined variable: htm C:\xampp\htdocs\tajeer_finance\application\helpers\custom_helper.php 2841
ERROR - 2016-08-12 21:10:46 --> Severity: Notice  --> Undefined variable: htm C:\xampp\htdocs\tajeer_finance\application\helpers\custom_helper.php 2841
ERROR - 2016-08-12 21:10:46 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 161
ERROR - 2016-08-12 21:10:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 161
ERROR - 2016-08-12 21:10:46 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 690
ERROR - 2016-08-12 21:10:46 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 693
ERROR - 2016-08-12 21:10:46 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 696
ERROR - 2016-08-12 21:10:46 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 710
ERROR - 2016-08-12 21:10:46 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 851
ERROR - 2016-08-12 21:10:46 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 888
ERROR - 2016-08-12 21:10:46 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 892
ERROR - 2016-08-12 21:10:46 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 903
ERROR - 2016-08-12 21:10:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-12 21:10:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-12 21:10:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-12 21:10:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-12 21:10:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-12 21:10:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-12 21:10:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-12 21:10:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-12 21:10:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-12 21:10:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-12 21:10:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-12 21:10:46 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1002
ERROR - 2016-08-12 21:10:46 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1005
ERROR - 2016-08-12 21:10:46 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1008
ERROR - 2016-08-12 21:10:54 --> Severity: Notice  --> Undefined variable: option C:\xampp\htdocs\tajeer_finance\application\views\ems\list_content\edit.php 200
ERROR - 2016-08-12 21:10:54 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 690
ERROR - 2016-08-12 21:10:54 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 693
ERROR - 2016-08-12 21:10:54 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 696
ERROR - 2016-08-12 21:10:54 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 710
ERROR - 2016-08-12 21:10:54 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 892
ERROR - 2016-08-12 21:10:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-12 21:10:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-12 21:10:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-12 21:10:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-12 21:10:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-12 21:10:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-12 21:10:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-12 21:10:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-12 21:10:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-12 21:10:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-12 21:10:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-12 21:10:54 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1002
ERROR - 2016-08-12 21:10:54 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1005
ERROR - 2016-08-12 21:10:54 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1008
ERROR - 2016-08-12 23:49:12 --> Severity: Notice  --> Undefined variable: Lang C:\xampp\htdocs\tajeer_finance\application\views\branches.php 41
ERROR - 2016-08-12 23:49:12 --> Severity: Notice  --> Undefined variable: marker C:\xampp\htdocs\tajeer_finance\application\views\branches.php 59
ERROR - 2016-08-12 23:49:16 --> Severity: Notice  --> Undefined variable: Lang C:\xampp\htdocs\tajeer_finance\application\views\branches.php 41
ERROR - 2016-08-12 23:49:16 --> Severity: Notice  --> Undefined variable: marker C:\xampp\htdocs\tajeer_finance\application\views\branches.php 59
