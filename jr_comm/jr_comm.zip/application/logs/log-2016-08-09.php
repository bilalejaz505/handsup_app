<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-08-09 08:39:01 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin.php 68
ERROR - 2016-08-09 08:39:13 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 161
ERROR - 2016-08-09 08:39:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 161
ERROR - 2016-08-09 08:39:13 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 690
ERROR - 2016-08-09 08:39:13 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 693
ERROR - 2016-08-09 08:39:13 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 696
ERROR - 2016-08-09 08:39:13 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 710
ERROR - 2016-08-09 08:39:13 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 851
ERROR - 2016-08-09 08:39:13 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 888
ERROR - 2016-08-09 08:39:13 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 892
ERROR - 2016-08-09 08:39:13 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 903
ERROR - 2016-08-09 08:39:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 957
ERROR - 2016-08-09 08:39:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 08:39:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 957
ERROR - 2016-08-09 08:39:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 08:39:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 957
ERROR - 2016-08-09 08:39:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 08:39:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 957
ERROR - 2016-08-09 08:39:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 08:39:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 957
ERROR - 2016-08-09 08:39:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 08:39:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 957
ERROR - 2016-08-09 08:39:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 08:39:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 957
ERROR - 2016-08-09 08:39:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 08:39:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 957
ERROR - 2016-08-09 08:39:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 08:39:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 957
ERROR - 2016-08-09 08:39:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 08:39:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 957
ERROR - 2016-08-09 08:39:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 08:39:13 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1002
ERROR - 2016-08-09 08:39:13 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1005
ERROR - 2016-08-09 08:39:13 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1008
ERROR - 2016-08-09 08:39:45 --> Severity: Notice  --> Undefined variable: message C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\manage.php 280
ERROR - 2016-08-09 08:39:45 --> Severity: Notice  --> Undefined variable: clientList C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\manage.php 287
ERROR - 2016-08-09 08:39:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\manage.php 287
ERROR - 2016-08-09 08:39:45 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 161
ERROR - 2016-08-09 08:39:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 161
ERROR - 2016-08-09 08:39:45 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 690
ERROR - 2016-08-09 08:39:45 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 693
ERROR - 2016-08-09 08:39:45 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 696
ERROR - 2016-08-09 08:39:45 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 710
ERROR - 2016-08-09 08:39:45 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 851
ERROR - 2016-08-09 08:39:45 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 888
ERROR - 2016-08-09 08:39:45 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 892
ERROR - 2016-08-09 08:39:45 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 903
ERROR - 2016-08-09 08:39:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 08:39:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 08:39:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 08:39:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 08:39:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 08:39:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 08:39:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 08:39:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 08:39:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 08:39:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 08:39:46 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1002
ERROR - 2016-08-09 08:39:46 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1005
ERROR - 2016-08-09 08:39:46 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1008
ERROR - 2016-08-09 08:39:47 --> 404 Page Not Found --> assets
ERROR - 2016-08-09 08:45:24 --> 404 Page Not Found --> assets
ERROR - 2016-08-09 08:46:57 --> Severity: Notice  --> Undefined index: template C:\xampp\htdocs\tajeer_finance\application\controllers\ems\content.php 68
ERROR - 2016-08-09 08:46:58 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: HTTP request failed! HTTP/1.0 400 Bad Request
 C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2113
ERROR - 2016-08-09 08:46:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2117
ERROR - 2016-08-09 08:46:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2133
ERROR - 2016-08-09 08:46:58 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 690
ERROR - 2016-08-09 08:46:58 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 693
ERROR - 2016-08-09 08:46:58 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 696
ERROR - 2016-08-09 08:46:58 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 710
ERROR - 2016-08-09 08:46:58 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 851
ERROR - 2016-08-09 08:46:58 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 892
ERROR - 2016-08-09 08:46:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 08:46:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 08:46:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 08:46:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 08:46:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 08:46:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 08:46:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 08:46:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 08:46:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 08:46:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 08:46:59 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1002
ERROR - 2016-08-09 08:46:59 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1005
ERROR - 2016-08-09 08:46:59 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1008
ERROR - 2016-08-09 09:04:43 --> 404 Page Not Found --> assets
ERROR - 2016-08-09 09:04:44 --> 404 Page Not Found --> assets
ERROR - 2016-08-09 09:09:56 --> Severity: Notice  --> Undefined index: template C:\xampp\htdocs\tajeer_finance\application\controllers\ems\content.php 68
ERROR - 2016-08-09 09:09:58 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: HTTP request failed! HTTP/1.0 400 Bad Request
 C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2113
ERROR - 2016-08-09 09:09:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2117
ERROR - 2016-08-09 09:09:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2133
ERROR - 2016-08-09 09:09:58 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 690
ERROR - 2016-08-09 09:09:58 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 693
ERROR - 2016-08-09 09:09:58 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 696
ERROR - 2016-08-09 09:09:58 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 710
ERROR - 2016-08-09 09:09:58 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 851
ERROR - 2016-08-09 09:09:58 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 892
ERROR - 2016-08-09 09:09:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 09:09:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 09:09:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 09:09:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 09:09:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 09:09:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 09:09:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 09:09:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 09:09:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 09:09:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 09:09:58 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1002
ERROR - 2016-08-09 09:09:58 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1005
ERROR - 2016-08-09 09:09:58 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1008
ERROR - 2016-08-09 09:11:34 --> Severity: Notice  --> Undefined index: template C:\xampp\htdocs\tajeer_finance\application\controllers\ems\content.php 68
ERROR - 2016-08-09 09:11:34 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: HTTP request failed! HTTP/1.0 400 Bad Request
 C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2113
ERROR - 2016-08-09 09:11:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2117
ERROR - 2016-08-09 09:11:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2133
ERROR - 2016-08-09 09:11:34 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 690
ERROR - 2016-08-09 09:11:34 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 693
ERROR - 2016-08-09 09:11:34 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 696
ERROR - 2016-08-09 09:11:34 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 710
ERROR - 2016-08-09 09:11:34 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 851
ERROR - 2016-08-09 09:11:34 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 892
ERROR - 2016-08-09 09:11:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 09:11:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 09:11:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 09:11:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 09:11:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 09:11:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 09:11:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 09:11:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 09:11:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 09:11:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 09:11:34 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1002
ERROR - 2016-08-09 09:11:34 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1005
ERROR - 2016-08-09 09:11:34 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1008
ERROR - 2016-08-09 09:13:28 --> Severity: Notice  --> Undefined variable: site_id C:\xampp\htdocs\tajeer_finance\application\helpers\custom_helper.php 1889
ERROR - 2016-08-09 09:13:28 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\tajeer_finance\application\helpers\custom_helper.php 1869
ERROR - 2016-08-09 09:13:28 --> Severity: Notice  --> Undefined index: template C:\xampp\htdocs\tajeer_finance\application\controllers\ems\content.php 68
ERROR - 2016-08-09 09:13:29 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: HTTP request failed! HTTP/1.0 400 Bad Request
 C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2113
ERROR - 2016-08-09 09:13:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2117
ERROR - 2016-08-09 09:13:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2133
ERROR - 2016-08-09 09:13:29 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 690
ERROR - 2016-08-09 09:13:29 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 693
ERROR - 2016-08-09 09:13:29 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 696
ERROR - 2016-08-09 09:13:29 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 710
ERROR - 2016-08-09 09:13:29 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 851
ERROR - 2016-08-09 09:13:29 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 892
ERROR - 2016-08-09 09:13:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 09:13:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 09:13:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 09:13:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 09:13:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 09:13:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 09:13:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 09:13:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 09:13:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 09:13:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 09:13:29 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1002
ERROR - 2016-08-09 09:13:29 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1005
ERROR - 2016-08-09 09:13:29 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1008
ERROR - 2016-08-09 09:14:24 --> Severity: Notice  --> Undefined variable: site_id C:\xampp\htdocs\tajeer_finance\application\helpers\custom_helper.php 1889
ERROR - 2016-08-09 09:14:24 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\tajeer_finance\application\helpers\custom_helper.php 1869
ERROR - 2016-08-09 09:14:24 --> Severity: Notice  --> Undefined index: template C:\xampp\htdocs\tajeer_finance\application\controllers\ems\content.php 68
ERROR - 2016-08-09 09:14:24 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: HTTP request failed! HTTP/1.0 400 Bad Request
 C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2113
ERROR - 2016-08-09 09:14:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2117
ERROR - 2016-08-09 09:14:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2133
ERROR - 2016-08-09 09:14:24 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 690
ERROR - 2016-08-09 09:14:24 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 693
ERROR - 2016-08-09 09:14:24 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 696
ERROR - 2016-08-09 09:14:24 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 710
ERROR - 2016-08-09 09:14:24 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 851
ERROR - 2016-08-09 09:14:24 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 892
ERROR - 2016-08-09 09:14:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 09:14:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 09:14:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 09:14:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 09:14:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 09:14:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 09:14:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 09:14:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 09:14:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 09:14:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 09:14:25 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1002
ERROR - 2016-08-09 09:14:25 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1005
ERROR - 2016-08-09 09:14:25 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1008
ERROR - 2016-08-09 09:16:20 --> Severity: Notice  --> Undefined variable: site_id C:\xampp\htdocs\tajeer_finance\application\helpers\custom_helper.php 1889
ERROR - 2016-08-09 09:16:20 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\tajeer_finance\application\helpers\custom_helper.php 1869
ERROR - 2016-08-09 09:16:20 --> Severity: Notice  --> Undefined index: template C:\xampp\htdocs\tajeer_finance\application\controllers\ems\content.php 68
ERROR - 2016-08-09 09:16:21 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: HTTP request failed! HTTP/1.0 400 Bad Request
 C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2113
ERROR - 2016-08-09 09:16:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2117
ERROR - 2016-08-09 09:16:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2133
ERROR - 2016-08-09 09:16:21 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 690
ERROR - 2016-08-09 09:16:21 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 693
ERROR - 2016-08-09 09:16:21 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 696
ERROR - 2016-08-09 09:16:21 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 710
ERROR - 2016-08-09 09:16:21 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 851
ERROR - 2016-08-09 09:16:21 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 892
ERROR - 2016-08-09 09:16:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 09:16:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 09:16:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 09:16:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 09:16:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 09:16:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 09:16:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 09:16:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 09:16:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 09:16:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 09:16:21 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1002
ERROR - 2016-08-09 09:16:21 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1005
ERROR - 2016-08-09 09:16:21 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1008
ERROR - 2016-08-09 09:16:31 --> Severity: Notice  --> Undefined variable: site_id C:\xampp\htdocs\tajeer_finance\application\helpers\custom_helper.php 1889
ERROR - 2016-08-09 09:16:31 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\tajeer_finance\application\helpers\custom_helper.php 1869
ERROR - 2016-08-09 09:16:31 --> Severity: Notice  --> Undefined index: template C:\xampp\htdocs\tajeer_finance\application\controllers\ems\content.php 68
ERROR - 2016-08-09 09:16:32 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: HTTP request failed! HTTP/1.0 400 Bad Request
 C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2113
ERROR - 2016-08-09 09:16:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2117
ERROR - 2016-08-09 09:16:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2133
ERROR - 2016-08-09 09:16:32 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 690
ERROR - 2016-08-09 09:16:32 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 693
ERROR - 2016-08-09 09:16:32 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 696
ERROR - 2016-08-09 09:16:32 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 710
ERROR - 2016-08-09 09:16:32 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 851
ERROR - 2016-08-09 09:16:32 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 892
ERROR - 2016-08-09 09:16:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 09:16:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 09:16:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 09:16:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 09:16:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 09:16:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 09:16:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 09:16:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 09:16:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 09:16:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 09:16:32 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1002
ERROR - 2016-08-09 09:16:32 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1005
ERROR - 2016-08-09 09:16:32 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1008
ERROR - 2016-08-09 09:16:59 --> 404 Page Not Found --> assets
ERROR - 2016-08-09 09:17:37 --> 404 Page Not Found --> assets
ERROR - 2016-08-09 09:19:29 --> 404 Page Not Found --> assets
ERROR - 2016-08-09 09:19:52 --> 404 Page Not Found --> assets
ERROR - 2016-08-09 09:20:02 --> 404 Page Not Found --> assets
ERROR - 2016-08-09 09:33:44 --> 404 Page Not Found --> assets
ERROR - 2016-08-09 09:55:43 --> 404 Page Not Found --> assets
ERROR - 2016-08-09 09:56:16 --> 404 Page Not Found --> assets
ERROR - 2016-08-09 09:56:38 --> 404 Page Not Found --> assets
ERROR - 2016-08-09 09:58:46 --> 404 Page Not Found --> assets
ERROR - 2016-08-09 09:59:41 --> 404 Page Not Found --> assets
ERROR - 2016-08-09 12:15:50 --> Severity: Notice  --> Undefined index: template C:\xampp\htdocs\tajeer_finance\application\controllers\ems\content.php 68
ERROR - 2016-08-09 12:15:50 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: HTTP request failed! HTTP/1.0 400 Bad Request
 C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2113
ERROR - 2016-08-09 12:15:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2117
ERROR - 2016-08-09 12:15:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2133
ERROR - 2016-08-09 12:15:51 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 690
ERROR - 2016-08-09 12:15:51 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 693
ERROR - 2016-08-09 12:15:51 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 696
ERROR - 2016-08-09 12:15:51 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 710
ERROR - 2016-08-09 12:15:51 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 851
ERROR - 2016-08-09 12:15:51 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 892
ERROR - 2016-08-09 12:15:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 12:15:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 12:15:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 12:15:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 12:15:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 12:15:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 12:15:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 12:15:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 12:15:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 12:15:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 12:15:51 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1002
ERROR - 2016-08-09 12:15:51 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1005
ERROR - 2016-08-09 12:15:51 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1008
ERROR - 2016-08-09 13:25:56 --> Severity: Notice  --> Undefined index: template C:\xampp\htdocs\tajeer_finance\application\controllers\ems\content.php 68
ERROR - 2016-08-09 13:25:57 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: HTTP request failed! HTTP/1.0 400 Bad Request
 C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2113
ERROR - 2016-08-09 13:25:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2117
ERROR - 2016-08-09 13:25:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2133
ERROR - 2016-08-09 13:25:57 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 690
ERROR - 2016-08-09 13:25:57 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 693
ERROR - 2016-08-09 13:25:57 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 696
ERROR - 2016-08-09 13:25:57 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 710
ERROR - 2016-08-09 13:25:57 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 851
ERROR - 2016-08-09 13:25:57 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 892
ERROR - 2016-08-09 13:25:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:25:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:25:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:25:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:25:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:25:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:25:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:25:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:25:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:25:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:25:57 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1002
ERROR - 2016-08-09 13:25:57 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1005
ERROR - 2016-08-09 13:25:57 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1008
ERROR - 2016-08-09 13:26:25 --> Severity: Notice  --> Undefined variable: site_id C:\xampp\htdocs\tajeer_finance\application\helpers\custom_helper.php 1889
ERROR - 2016-08-09 13:26:25 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\tajeer_finance\application\helpers\custom_helper.php 1869
ERROR - 2016-08-09 13:26:25 --> Severity: Notice  --> Undefined index: template C:\xampp\htdocs\tajeer_finance\application\controllers\ems\content.php 68
ERROR - 2016-08-09 13:26:26 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: HTTP request failed! HTTP/1.0 400 Bad Request
 C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2113
ERROR - 2016-08-09 13:26:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2117
ERROR - 2016-08-09 13:26:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2133
ERROR - 2016-08-09 13:26:26 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 690
ERROR - 2016-08-09 13:26:26 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 693
ERROR - 2016-08-09 13:26:26 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 696
ERROR - 2016-08-09 13:26:26 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 710
ERROR - 2016-08-09 13:26:26 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 851
ERROR - 2016-08-09 13:26:26 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 892
ERROR - 2016-08-09 13:26:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:26:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:26:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:26:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:26:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:26:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:26:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:26:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:26:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:26:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:26:26 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1002
ERROR - 2016-08-09 13:26:26 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1005
ERROR - 2016-08-09 13:26:26 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1008
ERROR - 2016-08-09 13:34:08 --> Severity: Notice  --> Undefined index: template C:\xampp\htdocs\tajeer_finance\application\controllers\ems\content.php 68
ERROR - 2016-08-09 13:34:10 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: HTTP request failed! HTTP/1.0 400 Bad Request
 C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2113
ERROR - 2016-08-09 13:34:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2117
ERROR - 2016-08-09 13:34:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2133
ERROR - 2016-08-09 13:34:10 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 690
ERROR - 2016-08-09 13:34:10 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 693
ERROR - 2016-08-09 13:34:10 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 696
ERROR - 2016-08-09 13:34:10 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 710
ERROR - 2016-08-09 13:34:10 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 851
ERROR - 2016-08-09 13:34:10 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 892
ERROR - 2016-08-09 13:34:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:34:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:34:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:34:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:34:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:34:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:34:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:34:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:34:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:34:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:34:10 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1002
ERROR - 2016-08-09 13:34:10 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1005
ERROR - 2016-08-09 13:34:10 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1008
ERROR - 2016-08-09 13:34:17 --> Severity: Notice  --> Undefined variable: site_id C:\xampp\htdocs\tajeer_finance\application\helpers\custom_helper.php 1889
ERROR - 2016-08-09 13:34:17 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\tajeer_finance\application\helpers\custom_helper.php 1869
ERROR - 2016-08-09 13:34:18 --> Severity: Notice  --> Undefined index: template C:\xampp\htdocs\tajeer_finance\application\controllers\ems\content.php 68
ERROR - 2016-08-09 13:34:18 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: HTTP request failed! HTTP/1.0 400 Bad Request
 C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2113
ERROR - 2016-08-09 13:34:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2117
ERROR - 2016-08-09 13:34:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2133
ERROR - 2016-08-09 13:34:19 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 690
ERROR - 2016-08-09 13:34:19 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 693
ERROR - 2016-08-09 13:34:19 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 696
ERROR - 2016-08-09 13:34:19 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 710
ERROR - 2016-08-09 13:34:19 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 851
ERROR - 2016-08-09 13:34:19 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 892
ERROR - 2016-08-09 13:34:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:34:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:34:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:34:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:34:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:34:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:34:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:34:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:34:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:34:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:34:19 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1002
ERROR - 2016-08-09 13:34:19 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1005
ERROR - 2016-08-09 13:34:19 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1008
ERROR - 2016-08-09 13:34:44 --> Severity: Notice  --> Undefined index: template C:\xampp\htdocs\tajeer_finance\application\controllers\ems\content.php 68
ERROR - 2016-08-09 13:34:48 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: HTTP request failed! HTTP/1.0 400 Bad Request
 C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2113
ERROR - 2016-08-09 13:34:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2117
ERROR - 2016-08-09 13:34:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2133
ERROR - 2016-08-09 13:34:48 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 690
ERROR - 2016-08-09 13:34:48 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 693
ERROR - 2016-08-09 13:34:48 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 696
ERROR - 2016-08-09 13:34:48 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 710
ERROR - 2016-08-09 13:34:48 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 851
ERROR - 2016-08-09 13:34:48 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 892
ERROR - 2016-08-09 13:34:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:34:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:34:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:34:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:34:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:34:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:34:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:34:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:34:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:34:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:34:49 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1002
ERROR - 2016-08-09 13:34:49 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1005
ERROR - 2016-08-09 13:34:49 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1008
ERROR - 2016-08-09 13:44:55 --> Severity: Notice  --> Undefined index: template C:\xampp\htdocs\tajeer_finance\application\controllers\ems\content.php 68
ERROR - 2016-08-09 13:44:58 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: HTTP request failed! HTTP/1.0 400 Bad Request
 C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2113
ERROR - 2016-08-09 13:44:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2117
ERROR - 2016-08-09 13:44:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2133
ERROR - 2016-08-09 13:44:58 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 690
ERROR - 2016-08-09 13:44:58 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 693
ERROR - 2016-08-09 13:44:58 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 696
ERROR - 2016-08-09 13:44:58 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 710
ERROR - 2016-08-09 13:44:58 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 851
ERROR - 2016-08-09 13:44:58 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 892
ERROR - 2016-08-09 13:44:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:44:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:44:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:44:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:44:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:44:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:44:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:44:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:44:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:44:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:44:58 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1002
ERROR - 2016-08-09 13:44:58 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1005
ERROR - 2016-08-09 13:44:58 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1008
ERROR - 2016-08-09 13:46:55 --> Severity: Notice  --> Undefined variable: site_id C:\xampp\htdocs\tajeer_finance\application\helpers\custom_helper.php 1889
ERROR - 2016-08-09 13:46:55 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\tajeer_finance\application\helpers\custom_helper.php 1869
ERROR - 2016-08-09 13:46:56 --> Severity: Notice  --> Undefined index: template C:\xampp\htdocs\tajeer_finance\application\controllers\ems\content.php 68
ERROR - 2016-08-09 13:47:00 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: HTTP request failed! HTTP/1.0 400 Bad Request
 C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2113
ERROR - 2016-08-09 13:47:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2117
ERROR - 2016-08-09 13:47:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2133
ERROR - 2016-08-09 13:47:00 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 690
ERROR - 2016-08-09 13:47:00 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 693
ERROR - 2016-08-09 13:47:00 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 696
ERROR - 2016-08-09 13:47:00 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 710
ERROR - 2016-08-09 13:47:00 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 851
ERROR - 2016-08-09 13:47:00 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 892
ERROR - 2016-08-09 13:47:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:47:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:47:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:47:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:47:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:47:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:47:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:47:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:47:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:47:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:47:01 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1002
ERROR - 2016-08-09 13:47:01 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1005
ERROR - 2016-08-09 13:47:01 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1008
ERROR - 2016-08-09 13:47:47 --> Severity: Notice  --> Undefined index: template C:\xampp\htdocs\tajeer_finance\application\controllers\ems\content.php 68
ERROR - 2016-08-09 13:47:47 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: HTTP request failed! HTTP/1.0 400 Bad Request
 C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2113
ERROR - 2016-08-09 13:47:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2117
ERROR - 2016-08-09 13:47:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2133
ERROR - 2016-08-09 13:47:47 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 690
ERROR - 2016-08-09 13:47:47 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 693
ERROR - 2016-08-09 13:47:47 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 696
ERROR - 2016-08-09 13:47:47 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 710
ERROR - 2016-08-09 13:47:47 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 851
ERROR - 2016-08-09 13:47:47 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 892
ERROR - 2016-08-09 13:47:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:47:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:47:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:47:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:47:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:47:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:47:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:47:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:47:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:47:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:47:48 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1002
ERROR - 2016-08-09 13:47:48 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1005
ERROR - 2016-08-09 13:47:48 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1008
ERROR - 2016-08-09 13:47:56 --> Severity: Notice  --> Undefined variable: site_id C:\xampp\htdocs\tajeer_finance\application\helpers\custom_helper.php 1889
ERROR - 2016-08-09 13:47:57 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\tajeer_finance\application\helpers\custom_helper.php 1869
ERROR - 2016-08-09 13:47:57 --> Severity: Notice  --> Undefined index: template C:\xampp\htdocs\tajeer_finance\application\controllers\ems\content.php 68
ERROR - 2016-08-09 13:47:57 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: HTTP request failed! HTTP/1.0 400 Bad Request
 C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2113
ERROR - 2016-08-09 13:47:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2117
ERROR - 2016-08-09 13:47:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2133
ERROR - 2016-08-09 13:47:57 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 690
ERROR - 2016-08-09 13:47:57 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 693
ERROR - 2016-08-09 13:47:57 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 696
ERROR - 2016-08-09 13:47:57 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 710
ERROR - 2016-08-09 13:47:57 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 851
ERROR - 2016-08-09 13:47:57 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 892
ERROR - 2016-08-09 13:47:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:47:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:47:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:47:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:47:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:47:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:47:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:47:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:47:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:47:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:47:58 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1002
ERROR - 2016-08-09 13:47:58 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1005
ERROR - 2016-08-09 13:47:58 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1008
ERROR - 2016-08-09 13:48:53 --> Severity: Notice  --> Undefined variable: site_id C:\xampp\htdocs\tajeer_finance\application\helpers\custom_helper.php 1889
ERROR - 2016-08-09 13:48:53 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\tajeer_finance\application\helpers\custom_helper.php 1869
ERROR - 2016-08-09 13:48:53 --> Severity: Notice  --> Undefined index: template C:\xampp\htdocs\tajeer_finance\application\controllers\ems\content.php 68
ERROR - 2016-08-09 13:48:54 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: HTTP request failed! HTTP/1.0 400 Bad Request
 C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2113
ERROR - 2016-08-09 13:48:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2117
ERROR - 2016-08-09 13:48:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2133
ERROR - 2016-08-09 13:48:54 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 690
ERROR - 2016-08-09 13:48:54 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 693
ERROR - 2016-08-09 13:48:54 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 696
ERROR - 2016-08-09 13:48:54 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 710
ERROR - 2016-08-09 13:48:54 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 851
ERROR - 2016-08-09 13:48:54 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 892
ERROR - 2016-08-09 13:48:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:48:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:48:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:48:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:48:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:48:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:48:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:48:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:48:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:48:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:48:54 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1002
ERROR - 2016-08-09 13:48:54 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1005
ERROR - 2016-08-09 13:48:54 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1008
ERROR - 2016-08-09 13:49:02 --> Severity: Notice  --> Undefined variable: site_id C:\xampp\htdocs\tajeer_finance\application\helpers\custom_helper.php 1889
ERROR - 2016-08-09 13:49:02 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\tajeer_finance\application\helpers\custom_helper.php 1869
ERROR - 2016-08-09 13:49:03 --> Severity: Notice  --> Undefined index: template C:\xampp\htdocs\tajeer_finance\application\controllers\ems\content.php 68
ERROR - 2016-08-09 13:49:03 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: HTTP request failed! HTTP/1.0 400 Bad Request
 C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2113
ERROR - 2016-08-09 13:49:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2117
ERROR - 2016-08-09 13:49:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2133
ERROR - 2016-08-09 13:49:03 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 690
ERROR - 2016-08-09 13:49:03 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 693
ERROR - 2016-08-09 13:49:03 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 696
ERROR - 2016-08-09 13:49:03 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 710
ERROR - 2016-08-09 13:49:03 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 851
ERROR - 2016-08-09 13:49:03 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 892
ERROR - 2016-08-09 13:49:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:49:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:49:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:49:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:49:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:49:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:49:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:49:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:49:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:49:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:49:03 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1002
ERROR - 2016-08-09 13:49:03 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1005
ERROR - 2016-08-09 13:49:03 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1008
ERROR - 2016-08-09 13:52:51 --> Severity: Notice  --> Undefined variable: site_id C:\xampp\htdocs\tajeer_finance\application\helpers\custom_helper.php 1889
ERROR - 2016-08-09 13:52:51 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\tajeer_finance\application\helpers\custom_helper.php 1869
ERROR - 2016-08-09 13:52:51 --> Severity: Notice  --> Undefined index: template C:\xampp\htdocs\tajeer_finance\application\controllers\ems\content.php 68
ERROR - 2016-08-09 13:52:55 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: HTTP request failed! HTTP/1.0 400 Bad Request
 C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2113
ERROR - 2016-08-09 13:52:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2117
ERROR - 2016-08-09 13:52:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2133
ERROR - 2016-08-09 13:52:55 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 690
ERROR - 2016-08-09 13:52:55 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 693
ERROR - 2016-08-09 13:52:55 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 696
ERROR - 2016-08-09 13:52:55 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 710
ERROR - 2016-08-09 13:52:55 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 851
ERROR - 2016-08-09 13:52:55 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 892
ERROR - 2016-08-09 13:52:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:52:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:52:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:52:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:52:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:52:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:52:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:52:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:52:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:52:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 13:52:55 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1002
ERROR - 2016-08-09 13:52:55 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1005
ERROR - 2016-08-09 13:52:55 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1008
ERROR - 2016-08-09 14:44:22 --> Severity: Notice  --> Undefined index: template C:\xampp\htdocs\tajeer_finance\application\controllers\ems\content.php 68
ERROR - 2016-08-09 14:44:22 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: HTTP request failed! HTTP/1.0 400 Bad Request
 C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2113
ERROR - 2016-08-09 14:44:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2117
ERROR - 2016-08-09 14:44:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2133
ERROR - 2016-08-09 14:44:22 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 690
ERROR - 2016-08-09 14:44:22 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 693
ERROR - 2016-08-09 14:44:22 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 696
ERROR - 2016-08-09 14:44:22 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 710
ERROR - 2016-08-09 14:44:22 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 851
ERROR - 2016-08-09 14:44:22 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 892
ERROR - 2016-08-09 14:44:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 14:44:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 14:44:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 14:44:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 14:44:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 14:44:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 14:44:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 14:44:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 14:44:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 14:44:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 14:44:23 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1002
ERROR - 2016-08-09 14:44:23 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1005
ERROR - 2016-08-09 14:44:23 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1008
ERROR - 2016-08-09 14:44:28 --> Severity: Notice  --> Undefined index: template C:\xampp\htdocs\tajeer_finance\application\controllers\ems\content.php 68
ERROR - 2016-08-09 14:44:28 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: HTTP request failed! HTTP/1.0 400 Bad Request
 C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2113
ERROR - 2016-08-09 14:44:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2117
ERROR - 2016-08-09 14:44:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2133
ERROR - 2016-08-09 14:44:28 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 690
ERROR - 2016-08-09 14:44:28 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 693
ERROR - 2016-08-09 14:44:28 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 696
ERROR - 2016-08-09 14:44:28 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 710
ERROR - 2016-08-09 14:44:28 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 851
ERROR - 2016-08-09 14:44:28 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 892
ERROR - 2016-08-09 14:44:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 14:44:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 14:44:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 14:44:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 14:44:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 14:44:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 14:44:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 14:44:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 14:44:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 14:44:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 14:44:28 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1002
ERROR - 2016-08-09 14:44:28 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1005
ERROR - 2016-08-09 14:44:28 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1008
ERROR - 2016-08-09 14:44:36 --> Severity: Notice  --> Undefined index: template C:\xampp\htdocs\tajeer_finance\application\controllers\ems\content.php 68
ERROR - 2016-08-09 14:44:37 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: HTTP request failed! HTTP/1.0 400 Bad Request
 C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2113
ERROR - 2016-08-09 14:44:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2117
ERROR - 2016-08-09 14:44:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2133
ERROR - 2016-08-09 14:44:37 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 690
ERROR - 2016-08-09 14:44:37 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 693
ERROR - 2016-08-09 14:44:37 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 696
ERROR - 2016-08-09 14:44:37 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 710
ERROR - 2016-08-09 14:44:37 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 851
ERROR - 2016-08-09 14:44:37 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 892
ERROR - 2016-08-09 14:44:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 14:44:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 14:44:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 14:44:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 14:44:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 14:44:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 14:44:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 14:44:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 14:44:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 14:44:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 14:44:37 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1002
ERROR - 2016-08-09 14:44:37 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1005
ERROR - 2016-08-09 14:44:37 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1008
ERROR - 2016-08-09 14:44:48 --> Severity: Notice  --> Undefined variable: site_id C:\xampp\htdocs\tajeer_finance\application\helpers\custom_helper.php 1889
ERROR - 2016-08-09 14:44:48 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\tajeer_finance\application\helpers\custom_helper.php 1869
ERROR - 2016-08-09 14:44:48 --> Severity: Notice  --> Undefined index: template C:\xampp\htdocs\tajeer_finance\application\controllers\ems\content.php 68
ERROR - 2016-08-09 14:44:49 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: HTTP request failed! HTTP/1.0 400 Bad Request
 C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2113
ERROR - 2016-08-09 14:44:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2117
ERROR - 2016-08-09 14:44:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2133
ERROR - 2016-08-09 14:44:49 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 690
ERROR - 2016-08-09 14:44:49 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 693
ERROR - 2016-08-09 14:44:49 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 696
ERROR - 2016-08-09 14:44:49 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 710
ERROR - 2016-08-09 14:44:49 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 851
ERROR - 2016-08-09 14:44:49 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 892
ERROR - 2016-08-09 14:44:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 14:44:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 14:44:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 14:44:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 14:44:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 14:44:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 14:44:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 14:44:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 14:44:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 14:44:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 14:44:49 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1002
ERROR - 2016-08-09 14:44:50 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1005
ERROR - 2016-08-09 14:44:50 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1008
ERROR - 2016-08-09 14:45:58 --> Severity: Notice  --> Undefined index: template C:\xampp\htdocs\tajeer_finance\application\controllers\ems\content.php 68
ERROR - 2016-08-09 14:45:59 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: HTTP request failed! HTTP/1.0 400 Bad Request
 C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2113
ERROR - 2016-08-09 14:45:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2117
ERROR - 2016-08-09 14:45:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2133
ERROR - 2016-08-09 14:45:59 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 690
ERROR - 2016-08-09 14:45:59 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 693
ERROR - 2016-08-09 14:45:59 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 696
ERROR - 2016-08-09 14:45:59 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 710
ERROR - 2016-08-09 14:45:59 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 851
ERROR - 2016-08-09 14:45:59 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 892
ERROR - 2016-08-09 14:45:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 14:45:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 14:45:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 14:45:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 14:45:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 14:45:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 14:45:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 14:45:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 14:45:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 14:45:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-09 14:45:59 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1002
ERROR - 2016-08-09 14:45:59 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1005
ERROR - 2016-08-09 14:45:59 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1008
