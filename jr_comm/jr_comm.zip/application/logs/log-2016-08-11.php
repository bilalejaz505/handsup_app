<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-08-11 09:05:07 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin.php 68
ERROR - 2016-08-11 09:05:13 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 161
ERROR - 2016-08-11 09:05:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 161
ERROR - 2016-08-11 09:05:13 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 690
ERROR - 2016-08-11 09:05:13 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 693
ERROR - 2016-08-11 09:05:13 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 696
ERROR - 2016-08-11 09:05:13 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 710
ERROR - 2016-08-11 09:05:13 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 851
ERROR - 2016-08-11 09:05:13 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 888
ERROR - 2016-08-11 09:05:13 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 892
ERROR - 2016-08-11 09:05:13 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 903
ERROR - 2016-08-11 09:05:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 957
ERROR - 2016-08-11 09:05:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 09:05:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 957
ERROR - 2016-08-11 09:05:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 09:05:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 957
ERROR - 2016-08-11 09:05:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 09:05:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 957
ERROR - 2016-08-11 09:05:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 09:05:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 957
ERROR - 2016-08-11 09:05:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 09:05:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 957
ERROR - 2016-08-11 09:05:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 09:05:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 957
ERROR - 2016-08-11 09:05:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 09:05:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 957
ERROR - 2016-08-11 09:05:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 09:05:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 957
ERROR - 2016-08-11 09:05:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 09:05:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 957
ERROR - 2016-08-11 09:05:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 09:05:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 957
ERROR - 2016-08-11 09:05:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 09:05:14 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1002
ERROR - 2016-08-11 09:05:14 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1005
ERROR - 2016-08-11 09:05:14 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1008
ERROR - 2016-08-11 09:05:18 --> Severity: Notice  --> Undefined variable: message C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\manage.php 280
ERROR - 2016-08-11 09:05:18 --> Severity: Notice  --> Undefined variable: clientList C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\manage.php 287
ERROR - 2016-08-11 09:05:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\manage.php 287
ERROR - 2016-08-11 09:05:18 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 161
ERROR - 2016-08-11 09:05:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 161
ERROR - 2016-08-11 09:05:18 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 690
ERROR - 2016-08-11 09:05:18 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 693
ERROR - 2016-08-11 09:05:18 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 696
ERROR - 2016-08-11 09:05:18 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 710
ERROR - 2016-08-11 09:05:18 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 851
ERROR - 2016-08-11 09:05:18 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 888
ERROR - 2016-08-11 09:05:18 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 892
ERROR - 2016-08-11 09:05:18 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 903
ERROR - 2016-08-11 09:05:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 09:05:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 09:05:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 09:05:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 09:05:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 09:05:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 09:05:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 09:05:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 09:05:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 09:05:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 09:05:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 09:05:18 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1002
ERROR - 2016-08-11 09:05:18 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1005
ERROR - 2016-08-11 09:05:18 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1008
ERROR - 2016-08-11 09:05:19 --> 404 Page Not Found --> assets
ERROR - 2016-08-11 09:06:08 --> Severity: Notice  --> Undefined variable: message C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\manage.php 280
ERROR - 2016-08-11 09:06:08 --> Severity: Notice  --> Undefined variable: clientList C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\manage.php 287
ERROR - 2016-08-11 09:06:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\manage.php 287
ERROR - 2016-08-11 09:06:08 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 161
ERROR - 2016-08-11 09:06:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 161
ERROR - 2016-08-11 09:06:08 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 690
ERROR - 2016-08-11 09:06:08 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 693
ERROR - 2016-08-11 09:06:08 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 696
ERROR - 2016-08-11 09:06:08 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 710
ERROR - 2016-08-11 09:06:08 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 851
ERROR - 2016-08-11 09:06:08 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 888
ERROR - 2016-08-11 09:06:08 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 892
ERROR - 2016-08-11 09:06:08 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 903
ERROR - 2016-08-11 09:06:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 09:06:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 09:06:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 09:06:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 09:06:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 09:06:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 09:06:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 09:06:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 09:06:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 09:06:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 09:06:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 09:06:08 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1002
ERROR - 2016-08-11 09:06:08 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1005
ERROR - 2016-08-11 09:06:08 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1008
ERROR - 2016-08-11 09:07:09 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\tajeer_finance\application\controllers\ems\content.php 93
ERROR - 2016-08-11 09:07:09 --> Severity: Notice  --> Undefined variable: res C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\add.php 39
ERROR - 2016-08-11 09:07:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\add.php 39
ERROR - 2016-08-11 09:07:09 --> Severity: Warning  --> Missing argument 6 for create_image(), called in C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\add.php on line 126 and defined C:\xampp\htdocs\tajeer_finance\application\helpers\cms_helper.php 96
ERROR - 2016-08-11 09:07:09 --> Severity: Warning  --> Missing argument 6 for create_image(), called in C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\add.php on line 131 and defined C:\xampp\htdocs\tajeer_finance\application\helpers\cms_helper.php 96
ERROR - 2016-08-11 09:07:09 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\add.php on line 137 and defined C:\xampp\htdocs\tajeer_finance\application\helpers\cms_helper.php 7
ERROR - 2016-08-11 09:07:09 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\add.php on line 141 and defined C:\xampp\htdocs\tajeer_finance\application\helpers\cms_helper.php 7
ERROR - 2016-08-11 09:07:09 --> Severity: Warning  --> Missing argument 6 for create_image(), called in C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\add.php on line 147 and defined C:\xampp\htdocs\tajeer_finance\application\helpers\cms_helper.php 96
ERROR - 2016-08-11 09:07:09 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\add.php on line 152 and defined C:\xampp\htdocs\tajeer_finance\application\helpers\cms_helper.php 37
ERROR - 2016-08-11 09:07:09 --> Severity: Warning  --> Missing argument 5 for create_textfield_not_required(), called in C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\add.php on line 157 and defined C:\xampp\htdocs\tajeer_finance\application\helpers\cms_helper.php 51
ERROR - 2016-08-11 09:07:09 --> Severity: Warning  --> Missing argument 5 for create_textfield_not_required(), called in C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\add.php on line 158 and defined C:\xampp\htdocs\tajeer_finance\application\helpers\cms_helper.php 51
ERROR - 2016-08-11 09:07:09 --> Severity: Warning  --> Missing argument 5 for create_textfield_not_required(), called in C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\add.php on line 159 and defined C:\xampp\htdocs\tajeer_finance\application\helpers\cms_helper.php 51
ERROR - 2016-08-11 09:07:09 --> Severity: Warning  --> Missing argument 5 for create_textfield_not_required(), called in C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\add.php on line 160 and defined C:\xampp\htdocs\tajeer_finance\application\helpers\cms_helper.php 51
ERROR - 2016-08-11 09:07:09 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\add.php on line 161 and defined C:\xampp\htdocs\tajeer_finance\application\helpers\cms_helper.php 37
ERROR - 2016-08-11 09:07:09 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\add.php on line 162 and defined C:\xampp\htdocs\tajeer_finance\application\helpers\cms_helper.php 37
ERROR - 2016-08-11 09:07:09 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\add.php on line 163 and defined C:\xampp\htdocs\tajeer_finance\application\helpers\cms_helper.php 37
ERROR - 2016-08-11 09:07:09 --> Severity: Warning  --> Missing argument 5 for create_textfield_not_required(), called in C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\add.php on line 164 and defined C:\xampp\htdocs\tajeer_finance\application\helpers\cms_helper.php 51
ERROR - 2016-08-11 09:07:09 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\add.php on line 173 and defined C:\xampp\htdocs\tajeer_finance\application\helpers\cms_helper.php 37
ERROR - 2016-08-11 09:07:09 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\add.php on line 178 and defined C:\xampp\htdocs\tajeer_finance\application\helpers\cms_helper.php 37
ERROR - 2016-08-11 09:07:09 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\add.php on line 182 and defined C:\xampp\htdocs\tajeer_finance\application\helpers\cms_helper.php 37
ERROR - 2016-08-11 09:07:09 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\add.php on line 188 and defined C:\xampp\htdocs\tajeer_finance\application\helpers\cms_helper.php 37
ERROR - 2016-08-11 09:07:09 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\add.php on line 194 and defined C:\xampp\htdocs\tajeer_finance\application\helpers\cms_helper.php 37
ERROR - 2016-08-11 09:07:09 --> Severity: Warning  --> Missing argument 5 for create_externallink(), called in C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\add.php on line 199 and defined C:\xampp\htdocs\tajeer_finance\application\helpers\cms_helper.php 81
ERROR - 2016-08-11 09:07:09 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\add.php on line 250 and defined C:\xampp\htdocs\tajeer_finance\application\helpers\cms_helper.php 37
ERROR - 2016-08-11 09:07:09 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\add.php on line 253 and defined C:\xampp\htdocs\tajeer_finance\application\helpers\cms_helper.php 37
ERROR - 2016-08-11 09:07:09 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\add.php on line 256 and defined C:\xampp\htdocs\tajeer_finance\application\helpers\cms_helper.php 7
ERROR - 2016-08-11 09:07:09 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\add.php on line 260 and defined C:\xampp\htdocs\tajeer_finance\application\helpers\cms_helper.php 7
ERROR - 2016-08-11 09:07:09 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 161
ERROR - 2016-08-11 09:07:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 161
ERROR - 2016-08-11 09:07:09 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 690
ERROR - 2016-08-11 09:07:09 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 693
ERROR - 2016-08-11 09:07:09 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 696
ERROR - 2016-08-11 09:07:09 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 710
ERROR - 2016-08-11 09:07:09 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 851
ERROR - 2016-08-11 09:07:09 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 892
ERROR - 2016-08-11 09:07:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 09:07:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 09:07:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 09:07:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 09:07:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 09:07:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 09:07:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 09:07:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 09:07:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 09:07:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 09:07:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 09:07:09 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1002
ERROR - 2016-08-11 09:07:09 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1005
ERROR - 2016-08-11 09:07:09 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1008
ERROR - 2016-08-11 09:09:01 --> Severity: Notice  --> Undefined variable: site_id C:\xampp\htdocs\tajeer_finance\application\helpers\custom_helper.php 1899
ERROR - 2016-08-11 09:09:01 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\tajeer_finance\application\helpers\custom_helper.php 1879
ERROR - 2016-08-11 09:09:01 --> Severity: Notice  --> Undefined index: template C:\xampp\htdocs\tajeer_finance\application\controllers\ems\content.php 68
ERROR - 2016-08-11 09:09:03 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: HTTP request failed! HTTP/1.0 400 Bad Request
 C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2113
ERROR - 2016-08-11 09:09:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2117
ERROR - 2016-08-11 09:09:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2133
ERROR - 2016-08-11 09:09:04 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 690
ERROR - 2016-08-11 09:09:04 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 693
ERROR - 2016-08-11 09:09:04 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 696
ERROR - 2016-08-11 09:09:04 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 710
ERROR - 2016-08-11 09:09:04 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 851
ERROR - 2016-08-11 09:09:04 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 892
ERROR - 2016-08-11 09:09:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 09:09:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 09:09:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 09:09:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 09:09:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 09:09:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 09:09:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 09:09:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 09:09:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 09:09:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 09:09:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 09:09:04 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1002
ERROR - 2016-08-11 09:09:04 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1005
ERROR - 2016-08-11 09:09:04 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1008
ERROR - 2016-08-11 12:28:17 --> Severity: Notice  --> Undefined variable: site_id C:\xampp\htdocs\tajeer_finance\application\helpers\custom_helper.php 1899
ERROR - 2016-08-11 12:28:17 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\tajeer_finance\application\helpers\custom_helper.php 1879
ERROR - 2016-08-11 12:28:17 --> Severity: Notice  --> Undefined index: template C:\xampp\htdocs\tajeer_finance\application\controllers\ems\content.php 68
ERROR - 2016-08-11 12:28:18 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: HTTP request failed! HTTP/1.0 400 Bad Request
 C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2113
ERROR - 2016-08-11 12:28:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2117
ERROR - 2016-08-11 12:28:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2133
ERROR - 2016-08-11 12:28:18 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 690
ERROR - 2016-08-11 12:28:18 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 693
ERROR - 2016-08-11 12:28:18 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 696
ERROR - 2016-08-11 12:28:18 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 710
ERROR - 2016-08-11 12:28:18 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 851
ERROR - 2016-08-11 12:28:18 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 892
ERROR - 2016-08-11 12:28:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 12:28:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 12:28:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 12:28:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 12:28:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 12:28:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 12:28:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 12:28:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 12:28:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 12:28:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 12:28:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 12:28:18 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1002
ERROR - 2016-08-11 12:28:18 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1005
ERROR - 2016-08-11 12:28:18 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1008
ERROR - 2016-08-11 13:10:12 --> Severity: Notice  --> Undefined variable: message C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\manage.php 280
ERROR - 2016-08-11 13:10:12 --> Severity: Notice  --> Undefined variable: clientList C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\manage.php 287
ERROR - 2016-08-11 13:10:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\manage.php 287
ERROR - 2016-08-11 13:10:12 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 161
ERROR - 2016-08-11 13:10:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 161
ERROR - 2016-08-11 13:10:12 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 690
ERROR - 2016-08-11 13:10:12 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 693
ERROR - 2016-08-11 13:10:12 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 696
ERROR - 2016-08-11 13:10:12 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 710
ERROR - 2016-08-11 13:10:12 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 851
ERROR - 2016-08-11 13:10:12 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 888
ERROR - 2016-08-11 13:10:12 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 892
ERROR - 2016-08-11 13:10:12 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 903
ERROR - 2016-08-11 13:10:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 13:10:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 13:10:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 13:10:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 13:10:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 13:10:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 13:10:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 13:10:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 13:10:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 13:10:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 13:10:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 13:10:12 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1002
ERROR - 2016-08-11 13:10:12 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1005
ERROR - 2016-08-11 13:10:12 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1008
ERROR - 2016-08-11 13:10:14 --> 404 Page Not Found --> assets
ERROR - 2016-08-11 13:10:15 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\tajeer_finance\application\controllers\ems\content.php 93
ERROR - 2016-08-11 13:10:15 --> Severity: Notice  --> Undefined variable: res C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\add.php 39
ERROR - 2016-08-11 13:10:15 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\add.php 39
ERROR - 2016-08-11 13:10:15 --> Severity: Warning  --> Missing argument 6 for create_image(), called in C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\add.php on line 126 and defined C:\xampp\htdocs\tajeer_finance\application\helpers\cms_helper.php 96
ERROR - 2016-08-11 13:10:15 --> Severity: Warning  --> Missing argument 6 for create_image(), called in C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\add.php on line 131 and defined C:\xampp\htdocs\tajeer_finance\application\helpers\cms_helper.php 96
ERROR - 2016-08-11 13:10:15 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\add.php on line 137 and defined C:\xampp\htdocs\tajeer_finance\application\helpers\cms_helper.php 7
ERROR - 2016-08-11 13:10:15 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\add.php on line 141 and defined C:\xampp\htdocs\tajeer_finance\application\helpers\cms_helper.php 7
ERROR - 2016-08-11 13:10:15 --> Severity: Warning  --> Missing argument 6 for create_image(), called in C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\add.php on line 147 and defined C:\xampp\htdocs\tajeer_finance\application\helpers\cms_helper.php 96
ERROR - 2016-08-11 13:10:15 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\add.php on line 152 and defined C:\xampp\htdocs\tajeer_finance\application\helpers\cms_helper.php 37
ERROR - 2016-08-11 13:10:15 --> Severity: Warning  --> Missing argument 5 for create_textfield_not_required(), called in C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\add.php on line 157 and defined C:\xampp\htdocs\tajeer_finance\application\helpers\cms_helper.php 51
ERROR - 2016-08-11 13:10:15 --> Severity: Warning  --> Missing argument 5 for create_textfield_not_required(), called in C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\add.php on line 158 and defined C:\xampp\htdocs\tajeer_finance\application\helpers\cms_helper.php 51
ERROR - 2016-08-11 13:10:15 --> Severity: Warning  --> Missing argument 5 for create_textfield_not_required(), called in C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\add.php on line 159 and defined C:\xampp\htdocs\tajeer_finance\application\helpers\cms_helper.php 51
ERROR - 2016-08-11 13:10:15 --> Severity: Warning  --> Missing argument 5 for create_textfield_not_required(), called in C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\add.php on line 160 and defined C:\xampp\htdocs\tajeer_finance\application\helpers\cms_helper.php 51
ERROR - 2016-08-11 13:10:15 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\add.php on line 161 and defined C:\xampp\htdocs\tajeer_finance\application\helpers\cms_helper.php 37
ERROR - 2016-08-11 13:10:15 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\add.php on line 162 and defined C:\xampp\htdocs\tajeer_finance\application\helpers\cms_helper.php 37
ERROR - 2016-08-11 13:10:15 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\add.php on line 163 and defined C:\xampp\htdocs\tajeer_finance\application\helpers\cms_helper.php 37
ERROR - 2016-08-11 13:10:15 --> Severity: Warning  --> Missing argument 5 for create_textfield_not_required(), called in C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\add.php on line 164 and defined C:\xampp\htdocs\tajeer_finance\application\helpers\cms_helper.php 51
ERROR - 2016-08-11 13:10:15 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\add.php on line 173 and defined C:\xampp\htdocs\tajeer_finance\application\helpers\cms_helper.php 37
ERROR - 2016-08-11 13:10:15 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\add.php on line 178 and defined C:\xampp\htdocs\tajeer_finance\application\helpers\cms_helper.php 37
ERROR - 2016-08-11 13:10:15 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\add.php on line 182 and defined C:\xampp\htdocs\tajeer_finance\application\helpers\cms_helper.php 37
ERROR - 2016-08-11 13:10:15 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\add.php on line 188 and defined C:\xampp\htdocs\tajeer_finance\application\helpers\cms_helper.php 37
ERROR - 2016-08-11 13:10:15 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\add.php on line 194 and defined C:\xampp\htdocs\tajeer_finance\application\helpers\cms_helper.php 37
ERROR - 2016-08-11 13:10:15 --> Severity: Warning  --> Missing argument 5 for create_externallink(), called in C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\add.php on line 199 and defined C:\xampp\htdocs\tajeer_finance\application\helpers\cms_helper.php 81
ERROR - 2016-08-11 13:10:15 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\add.php on line 250 and defined C:\xampp\htdocs\tajeer_finance\application\helpers\cms_helper.php 37
ERROR - 2016-08-11 13:10:15 --> Severity: Warning  --> Missing argument 5 for create_textfield(), called in C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\add.php on line 253 and defined C:\xampp\htdocs\tajeer_finance\application\helpers\cms_helper.php 37
ERROR - 2016-08-11 13:10:15 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\add.php on line 256 and defined C:\xampp\htdocs\tajeer_finance\application\helpers\cms_helper.php 7
ERROR - 2016-08-11 13:10:15 --> Severity: Warning  --> Missing argument 5 for create_textarea(), called in C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\add.php on line 260 and defined C:\xampp\htdocs\tajeer_finance\application\helpers\cms_helper.php 7
ERROR - 2016-08-11 13:10:15 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 161
ERROR - 2016-08-11 13:10:15 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 161
ERROR - 2016-08-11 13:10:15 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 690
ERROR - 2016-08-11 13:10:15 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 693
ERROR - 2016-08-11 13:10:15 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 696
ERROR - 2016-08-11 13:10:15 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 710
ERROR - 2016-08-11 13:10:15 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 851
ERROR - 2016-08-11 13:10:15 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 892
ERROR - 2016-08-11 13:10:15 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 13:10:15 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 13:10:15 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 13:10:15 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 13:10:15 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 13:10:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 13:10:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 13:10:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 13:10:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 13:10:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 13:10:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 13:10:16 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1002
ERROR - 2016-08-11 13:10:16 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1005
ERROR - 2016-08-11 13:10:16 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1008
ERROR - 2016-08-11 13:12:50 --> Severity: Notice  --> Undefined property: stdClass::$eng_page_title C:\xampp\htdocs\tajeer_finance\application\views\home.php 195
ERROR - 2016-08-11 13:13:24 --> Severity: Notice  --> Undefined property: stdClass::$eng_page_title C:\xampp\htdocs\tajeer_finance\application\views\home.php 195
ERROR - 2016-08-11 13:13:27 --> Severity: Notice  --> Undefined property: stdClass::$eng_page_title C:\xampp\htdocs\tajeer_finance\application\views\home.php 195
ERROR - 2016-08-11 13:13:59 --> Severity: Notice  --> Undefined property: stdClass::$eng_page_title C:\xampp\htdocs\tajeer_finance\application\views\home.php 195
ERROR - 2016-08-11 13:14:02 --> Severity: Notice  --> Undefined property: stdClass::$eng_page_title C:\xampp\htdocs\tajeer_finance\application\views\home.php 195
ERROR - 2016-08-11 13:14:33 --> Severity: Notice  --> Undefined property: stdClass::$eng_page_title C:\xampp\htdocs\tajeer_finance\application\views\home.php 195
ERROR - 2016-08-11 13:35:32 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 7
ERROR - 2016-08-11 13:35:32 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 12
ERROR - 2016-08-11 13:35:32 --> Severity: Notice  --> Undefined variable: meta_title C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 21
ERROR - 2016-08-11 13:35:32 --> Severity: Notice  --> Undefined variable: meta_key C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 22
ERROR - 2016-08-11 13:35:32 --> Severity: Notice  --> Undefined variable: meta_desc C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 23
ERROR - 2016-08-11 13:35:32 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 31
ERROR - 2016-08-11 13:35:32 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 41
ERROR - 2016-08-11 13:35:32 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 42
ERROR - 2016-08-11 13:35:32 --> Severity: Notice  --> Undefined variable: parent_id C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 45
ERROR - 2016-08-11 13:35:32 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 69
ERROR - 2016-08-11 13:35:32 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 70
ERROR - 2016-08-11 13:35:32 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 13
ERROR - 2016-08-11 13:35:32 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 24
ERROR - 2016-08-11 13:35:32 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 28
ERROR - 2016-08-11 13:35:32 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 32
ERROR - 2016-08-11 13:35:32 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 36
ERROR - 2016-08-11 13:35:32 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 40
ERROR - 2016-08-11 13:35:32 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 44
ERROR - 2016-08-11 13:35:32 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 48
ERROR - 2016-08-11 13:35:32 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 52
ERROR - 2016-08-11 13:35:32 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 56
ERROR - 2016-08-11 13:35:32 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 61
ERROR - 2016-08-11 13:35:32 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 65
ERROR - 2016-08-11 13:35:32 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 73
ERROR - 2016-08-11 13:35:32 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 78
ERROR - 2016-08-11 13:35:33 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 78
ERROR - 2016-08-11 13:35:33 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 79
ERROR - 2016-08-11 13:35:33 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 79
ERROR - 2016-08-11 13:35:33 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 82
ERROR - 2016-08-11 13:35:33 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 82
ERROR - 2016-08-11 13:35:33 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 83
ERROR - 2016-08-11 13:35:33 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 83
ERROR - 2016-08-11 13:35:33 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 89
ERROR - 2016-08-11 13:35:33 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 92
ERROR - 2016-08-11 13:35:33 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 92
ERROR - 2016-08-11 13:35:33 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 93
ERROR - 2016-08-11 13:35:33 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 93
ERROR - 2016-08-11 13:35:33 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 96
ERROR - 2016-08-11 13:35:33 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 102
ERROR - 2016-08-11 13:35:33 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 107
ERROR - 2016-08-11 13:35:33 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 108
ERROR - 2016-08-11 13:35:33 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 111
ERROR - 2016-08-11 13:35:33 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 112
ERROR - 2016-08-11 13:35:33 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 115
ERROR - 2016-08-11 13:35:33 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 116
ERROR - 2016-08-11 13:35:33 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 119
ERROR - 2016-08-11 13:35:33 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 120
ERROR - 2016-08-11 13:35:33 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 123
ERROR - 2016-08-11 13:35:33 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 124
ERROR - 2016-08-11 13:35:33 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 134
ERROR - 2016-08-11 13:35:33 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 137
ERROR - 2016-08-11 13:35:33 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 146
ERROR - 2016-08-11 13:35:33 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 146
ERROR - 2016-08-11 13:35:33 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 146
ERROR - 2016-08-11 13:35:33 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 146
ERROR - 2016-08-11 13:35:33 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 151
ERROR - 2016-08-11 13:35:33 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 154
ERROR - 2016-08-11 13:35:33 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 158
ERROR - 2016-08-11 13:35:33 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 162
ERROR - 2016-08-11 13:35:33 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 168
ERROR - 2016-08-11 13:35:33 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 172
ERROR - 2016-08-11 13:35:33 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 176
ERROR - 2016-08-11 13:35:33 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 182
ERROR - 2016-08-11 13:35:33 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 186
ERROR - 2016-08-11 13:35:33 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 190
ERROR - 2016-08-11 13:35:33 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 195
ERROR - 2016-08-11 13:35:33 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 196
ERROR - 2016-08-11 13:35:33 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 219
ERROR - 2016-08-11 13:35:33 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 220
ERROR - 2016-08-11 13:35:33 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 221
ERROR - 2016-08-11 13:35:33 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 225
ERROR - 2016-08-11 13:35:33 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\layouts\footer.php 38
ERROR - 2016-08-11 13:35:33 --> Severity: Notice  --> Undefined variable: parent_id C:\xampp\htdocs\tajeer_finance\application\views\layouts\footer.php 39
ERROR - 2016-08-11 13:35:33 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\layouts\footer.php 49
ERROR - 2016-08-11 13:35:33 --> Severity: Notice  --> Undefined variable: contents C:\xampp\htdocs\tajeer_finance\application\views\layouts\footer.php 55
ERROR - 2016-08-11 13:35:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\footer.php 55
ERROR - 2016-08-11 13:50:28 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 7
ERROR - 2016-08-11 13:50:28 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 12
ERROR - 2016-08-11 13:50:28 --> Severity: Notice  --> Undefined variable: meta_title C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 21
ERROR - 2016-08-11 13:50:28 --> Severity: Notice  --> Undefined variable: meta_key C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 22
ERROR - 2016-08-11 13:50:28 --> Severity: Notice  --> Undefined variable: meta_desc C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 23
ERROR - 2016-08-11 13:50:28 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 31
ERROR - 2016-08-11 13:50:28 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 41
ERROR - 2016-08-11 13:50:28 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 42
ERROR - 2016-08-11 13:50:28 --> Severity: Notice  --> Undefined variable: parent_id C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 45
ERROR - 2016-08-11 13:50:28 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 69
ERROR - 2016-08-11 13:50:28 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 70
ERROR - 2016-08-11 13:50:28 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 13
ERROR - 2016-08-11 13:50:28 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 24
ERROR - 2016-08-11 13:50:28 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 28
ERROR - 2016-08-11 13:50:28 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 32
ERROR - 2016-08-11 13:50:28 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 36
ERROR - 2016-08-11 13:50:28 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 40
ERROR - 2016-08-11 13:50:28 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 44
ERROR - 2016-08-11 13:50:28 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 48
ERROR - 2016-08-11 13:50:28 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 52
ERROR - 2016-08-11 13:50:28 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 56
ERROR - 2016-08-11 13:50:28 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 61
ERROR - 2016-08-11 13:50:28 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 65
ERROR - 2016-08-11 13:50:28 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 73
ERROR - 2016-08-11 13:50:28 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 78
ERROR - 2016-08-11 13:50:28 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 78
ERROR - 2016-08-11 13:50:28 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 79
ERROR - 2016-08-11 13:50:28 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 79
ERROR - 2016-08-11 13:50:29 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 82
ERROR - 2016-08-11 13:50:29 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 82
ERROR - 2016-08-11 13:50:29 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 83
ERROR - 2016-08-11 13:50:29 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 83
ERROR - 2016-08-11 13:50:29 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 89
ERROR - 2016-08-11 13:50:29 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 92
ERROR - 2016-08-11 13:50:29 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 92
ERROR - 2016-08-11 13:50:29 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 93
ERROR - 2016-08-11 13:50:29 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 93
ERROR - 2016-08-11 13:50:29 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 96
ERROR - 2016-08-11 13:50:29 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 102
ERROR - 2016-08-11 13:50:29 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 107
ERROR - 2016-08-11 13:50:29 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 108
ERROR - 2016-08-11 13:50:29 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 111
ERROR - 2016-08-11 13:50:29 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 112
ERROR - 2016-08-11 13:50:29 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 115
ERROR - 2016-08-11 13:50:29 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 116
ERROR - 2016-08-11 13:50:29 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 119
ERROR - 2016-08-11 13:50:29 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 120
ERROR - 2016-08-11 13:50:29 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 123
ERROR - 2016-08-11 13:50:29 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 124
ERROR - 2016-08-11 13:50:29 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 134
ERROR - 2016-08-11 13:50:29 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 137
ERROR - 2016-08-11 13:50:29 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 146
ERROR - 2016-08-11 13:50:29 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 146
ERROR - 2016-08-11 13:50:29 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 146
ERROR - 2016-08-11 13:50:29 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 146
ERROR - 2016-08-11 13:50:29 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 151
ERROR - 2016-08-11 13:50:29 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 154
ERROR - 2016-08-11 13:50:29 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 158
ERROR - 2016-08-11 13:50:29 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 162
ERROR - 2016-08-11 13:50:29 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 168
ERROR - 2016-08-11 13:50:29 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 172
ERROR - 2016-08-11 13:50:29 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 176
ERROR - 2016-08-11 13:50:29 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 182
ERROR - 2016-08-11 13:50:29 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 186
ERROR - 2016-08-11 13:50:29 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 190
ERROR - 2016-08-11 13:50:29 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 195
ERROR - 2016-08-11 13:50:29 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 196
ERROR - 2016-08-11 13:50:29 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 219
ERROR - 2016-08-11 13:50:29 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 220
ERROR - 2016-08-11 13:50:29 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 221
ERROR - 2016-08-11 13:50:29 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 225
ERROR - 2016-08-11 13:50:29 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\layouts\footer.php 38
ERROR - 2016-08-11 13:50:29 --> Severity: Notice  --> Undefined variable: parent_id C:\xampp\htdocs\tajeer_finance\application\views\layouts\footer.php 39
ERROR - 2016-08-11 13:50:29 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\layouts\footer.php 49
ERROR - 2016-08-11 13:50:29 --> Severity: Notice  --> Undefined variable: contents C:\xampp\htdocs\tajeer_finance\application\views\layouts\footer.php 55
ERROR - 2016-08-11 13:50:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\footer.php 55
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 7
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 12
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: meta_title C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 21
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: meta_key C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 22
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: meta_desc C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 23
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 31
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 41
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 42
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: parent_id C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 45
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 69
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 70
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 13
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 24
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 28
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 32
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 36
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 40
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 44
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 48
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 52
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 56
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 61
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 65
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 73
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 78
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 78
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 79
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 79
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 82
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 82
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 83
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 83
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 89
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 92
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 92
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 93
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 93
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 96
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 102
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 107
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 108
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 111
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 112
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 115
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 116
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 119
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 120
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 123
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 124
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 134
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 137
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 146
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 146
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 146
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 146
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 151
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 154
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 158
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 162
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 168
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 172
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 176
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 182
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 186
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 190
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 195
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 196
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 219
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 220
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 221
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 225
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\layouts\footer.php 38
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: parent_id C:\xampp\htdocs\tajeer_finance\application\views\layouts\footer.php 39
ERROR - 2016-08-11 13:51:07 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\layouts\footer.php 49
ERROR - 2016-08-11 13:51:08 --> Severity: Notice  --> Undefined variable: contents C:\xampp\htdocs\tajeer_finance\application\views\layouts\footer.php 55
ERROR - 2016-08-11 13:51:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\footer.php 55
ERROR - 2016-08-11 13:52:38 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 7
ERROR - 2016-08-11 13:52:38 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 12
ERROR - 2016-08-11 13:52:38 --> Severity: Notice  --> Undefined variable: meta_title C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 21
ERROR - 2016-08-11 13:52:38 --> Severity: Notice  --> Undefined variable: meta_key C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 22
ERROR - 2016-08-11 13:52:38 --> Severity: Notice  --> Undefined variable: meta_desc C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 23
ERROR - 2016-08-11 13:52:38 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 31
ERROR - 2016-08-11 13:52:38 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 41
ERROR - 2016-08-11 13:52:38 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 42
ERROR - 2016-08-11 13:52:38 --> Severity: Notice  --> Undefined variable: parent_id C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 45
ERROR - 2016-08-11 13:52:38 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 69
ERROR - 2016-08-11 13:52:38 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 70
ERROR - 2016-08-11 13:52:38 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 13
ERROR - 2016-08-11 13:52:38 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 24
ERROR - 2016-08-11 13:52:38 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 28
ERROR - 2016-08-11 13:52:38 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 32
ERROR - 2016-08-11 13:52:38 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 36
ERROR - 2016-08-11 13:52:38 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 40
ERROR - 2016-08-11 13:52:38 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 44
ERROR - 2016-08-11 13:52:38 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 48
ERROR - 2016-08-11 13:52:38 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 52
ERROR - 2016-08-11 13:52:38 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 56
ERROR - 2016-08-11 13:52:38 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 61
ERROR - 2016-08-11 13:52:38 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 65
ERROR - 2016-08-11 13:52:38 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 73
ERROR - 2016-08-11 13:52:38 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 78
ERROR - 2016-08-11 13:52:38 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 78
ERROR - 2016-08-11 13:52:38 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 79
ERROR - 2016-08-11 13:52:38 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 79
ERROR - 2016-08-11 13:52:38 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 82
ERROR - 2016-08-11 13:52:38 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 82
ERROR - 2016-08-11 13:52:38 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 83
ERROR - 2016-08-11 13:52:38 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 83
ERROR - 2016-08-11 13:52:38 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 89
ERROR - 2016-08-11 13:52:38 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 92
ERROR - 2016-08-11 13:52:38 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 92
ERROR - 2016-08-11 13:52:38 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 93
ERROR - 2016-08-11 13:52:38 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 93
ERROR - 2016-08-11 13:52:38 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 96
ERROR - 2016-08-11 13:52:38 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 102
ERROR - 2016-08-11 13:52:38 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 107
ERROR - 2016-08-11 13:52:38 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 108
ERROR - 2016-08-11 13:52:38 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 111
ERROR - 2016-08-11 13:52:38 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 112
ERROR - 2016-08-11 13:52:38 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 115
ERROR - 2016-08-11 13:52:38 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 116
ERROR - 2016-08-11 13:52:38 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 119
ERROR - 2016-08-11 13:52:38 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 120
ERROR - 2016-08-11 13:52:38 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 123
ERROR - 2016-08-11 13:52:38 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 124
ERROR - 2016-08-11 13:52:38 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 134
ERROR - 2016-08-11 13:52:38 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 137
ERROR - 2016-08-11 13:52:38 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 146
ERROR - 2016-08-11 13:52:38 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 146
ERROR - 2016-08-11 13:52:38 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 146
ERROR - 2016-08-11 13:52:38 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 146
ERROR - 2016-08-11 13:52:38 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 151
ERROR - 2016-08-11 13:52:38 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 154
ERROR - 2016-08-11 13:52:38 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 158
ERROR - 2016-08-11 13:52:38 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 162
ERROR - 2016-08-11 13:52:38 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 168
ERROR - 2016-08-11 13:52:39 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 172
ERROR - 2016-08-11 13:52:39 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 176
ERROR - 2016-08-11 13:52:39 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 182
ERROR - 2016-08-11 13:52:39 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 186
ERROR - 2016-08-11 13:52:39 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 190
ERROR - 2016-08-11 13:52:39 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 195
ERROR - 2016-08-11 13:52:39 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 196
ERROR - 2016-08-11 13:52:39 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 219
ERROR - 2016-08-11 13:52:39 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 220
ERROR - 2016-08-11 13:52:39 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 221
ERROR - 2016-08-11 13:52:39 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 225
ERROR - 2016-08-11 13:52:39 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\layouts\footer.php 38
ERROR - 2016-08-11 13:52:39 --> Severity: Notice  --> Undefined variable: parent_id C:\xampp\htdocs\tajeer_finance\application\views\layouts\footer.php 39
ERROR - 2016-08-11 13:52:39 --> Severity: Notice  --> Undefined variable: lang C:\xampp\htdocs\tajeer_finance\application\views\layouts\footer.php 49
ERROR - 2016-08-11 13:52:39 --> Severity: Notice  --> Undefined variable: contents C:\xampp\htdocs\tajeer_finance\application\views\layouts\footer.php 55
ERROR - 2016-08-11 13:52:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\footer.php 55
ERROR - 2016-08-11 13:55:38 --> Severity: Notice  --> Undefined variable: contents C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 8
ERROR - 2016-08-11 13:55:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 8
ERROR - 2016-08-11 13:55:38 --> Severity: Notice  --> Undefined variable: contents C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 9
ERROR - 2016-08-11 13:55:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 9
ERROR - 2016-08-11 13:55:38 --> Severity: Notice  --> Undefined variable: contents C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 10
ERROR - 2016-08-11 13:55:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 10
ERROR - 2016-08-11 13:55:38 --> Severity: Notice  --> Undefined variable: parent_id C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 45
ERROR - 2016-08-11 13:55:38 --> Severity: Notice  --> Undefined variable: parent_id C:\xampp\htdocs\tajeer_finance\application\views\layouts\footer.php 39
ERROR - 2016-08-11 13:55:38 --> Severity: Notice  --> Undefined variable: contents C:\xampp\htdocs\tajeer_finance\application\views\layouts\footer.php 55
ERROR - 2016-08-11 13:55:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\footer.php 55
ERROR - 2016-08-11 14:01:34 --> Severity: Notice  --> Undefined variable: contents C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 8
ERROR - 2016-08-11 14:01:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 8
ERROR - 2016-08-11 14:01:34 --> Severity: Notice  --> Undefined variable: contents C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 9
ERROR - 2016-08-11 14:01:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 9
ERROR - 2016-08-11 14:01:34 --> Severity: Notice  --> Undefined variable: contents C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 10
ERROR - 2016-08-11 14:01:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 10
ERROR - 2016-08-11 14:01:34 --> Severity: Notice  --> Undefined variable: parent_id C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 45
ERROR - 2016-08-11 14:01:34 --> Severity: Notice  --> Undefined variable: parent_id C:\xampp\htdocs\tajeer_finance\application\views\layouts\footer.php 39
ERROR - 2016-08-11 14:01:34 --> Severity: Notice  --> Undefined variable: contents C:\xampp\htdocs\tajeer_finance\application\views\layouts\footer.php 55
ERROR - 2016-08-11 14:01:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\footer.php 55
ERROR - 2016-08-11 14:15:52 --> Severity: Notice  --> Undefined variable: contents C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 8
ERROR - 2016-08-11 14:15:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 8
ERROR - 2016-08-11 14:15:52 --> Severity: Notice  --> Undefined variable: contents C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 9
ERROR - 2016-08-11 14:15:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 9
ERROR - 2016-08-11 14:15:52 --> Severity: Notice  --> Undefined variable: contents C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 10
ERROR - 2016-08-11 14:15:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 10
ERROR - 2016-08-11 14:15:52 --> Severity: Notice  --> Undefined variable: parent_id C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 45
ERROR - 2016-08-11 14:15:52 --> Severity: Notice  --> Undefined variable: isset C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 78
ERROR - 2016-08-11 14:17:22 --> Severity: Notice  --> Undefined variable: contents C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 8
ERROR - 2016-08-11 14:17:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 8
ERROR - 2016-08-11 14:17:22 --> Severity: Notice  --> Undefined variable: contents C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 9
ERROR - 2016-08-11 14:17:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 9
ERROR - 2016-08-11 14:17:22 --> Severity: Notice  --> Undefined variable: contents C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 10
ERROR - 2016-08-11 14:17:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 10
ERROR - 2016-08-11 14:17:22 --> Severity: Notice  --> Undefined variable: parent_id C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 45
ERROR - 2016-08-11 14:17:22 --> Severity: Notice  --> Undefined variable: isset C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 78
ERROR - 2016-08-11 14:18:03 --> Severity: Notice  --> Undefined variable: contents C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 8
ERROR - 2016-08-11 14:18:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 8
ERROR - 2016-08-11 14:18:03 --> Severity: Notice  --> Undefined variable: contents C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 9
ERROR - 2016-08-11 14:18:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 9
ERROR - 2016-08-11 14:18:04 --> Severity: Notice  --> Undefined variable: contents C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 10
ERROR - 2016-08-11 14:18:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 10
ERROR - 2016-08-11 14:18:04 --> Severity: Notice  --> Undefined variable: parent_id C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 45
ERROR - 2016-08-11 14:18:04 --> Severity: Notice  --> Undefined variable: isset C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 79
ERROR - 2016-08-11 14:18:38 --> Severity: Notice  --> Undefined variable: contents C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 8
ERROR - 2016-08-11 14:18:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 8
ERROR - 2016-08-11 14:18:38 --> Severity: Notice  --> Undefined variable: contents C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 9
ERROR - 2016-08-11 14:18:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 9
ERROR - 2016-08-11 14:18:38 --> Severity: Notice  --> Undefined variable: contents C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 10
ERROR - 2016-08-11 14:18:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 10
ERROR - 2016-08-11 14:18:38 --> Severity: Notice  --> Undefined variable: parent_id C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 45
ERROR - 2016-08-11 14:18:38 --> Severity: Notice  --> Undefined variable: isset C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 78
ERROR - 2016-08-11 14:22:46 --> Severity: Notice  --> Undefined variable: contents C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 8
ERROR - 2016-08-11 14:22:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 8
ERROR - 2016-08-11 14:22:46 --> Severity: Notice  --> Undefined variable: contents C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 9
ERROR - 2016-08-11 14:22:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 9
ERROR - 2016-08-11 14:22:46 --> Severity: Notice  --> Undefined variable: contents C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 10
ERROR - 2016-08-11 14:22:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 10
ERROR - 2016-08-11 14:22:46 --> Severity: Notice  --> Undefined variable: parent_id C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 45
ERROR - 2016-08-11 14:22:46 --> Severity: Notice  --> Undefined variable: isset C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 79
ERROR - 2016-08-11 14:29:06 --> Severity: Notice  --> Undefined variable: contents C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 8
ERROR - 2016-08-11 14:29:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 8
ERROR - 2016-08-11 14:29:06 --> Severity: Notice  --> Undefined variable: contents C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 9
ERROR - 2016-08-11 14:29:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 9
ERROR - 2016-08-11 14:29:06 --> Severity: Notice  --> Undefined variable: contents C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 10
ERROR - 2016-08-11 14:29:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 10
ERROR - 2016-08-11 14:29:06 --> Severity: Notice  --> Undefined variable: parent_id C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 45
ERROR - 2016-08-11 14:29:07 --> Severity: Notice  --> Undefined variable: isset C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 79
ERROR - 2016-08-11 14:29:41 --> Severity: Notice  --> Undefined variable: contents C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 8
ERROR - 2016-08-11 14:29:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 8
ERROR - 2016-08-11 14:29:41 --> Severity: Notice  --> Undefined variable: contents C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 9
ERROR - 2016-08-11 14:29:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 9
ERROR - 2016-08-11 14:29:41 --> Severity: Notice  --> Undefined variable: contents C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 10
ERROR - 2016-08-11 14:29:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 10
ERROR - 2016-08-11 14:29:41 --> Severity: Notice  --> Undefined variable: parent_id C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 45
ERROR - 2016-08-11 14:29:41 --> Severity: Notice  --> Undefined variable: isset C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 79
ERROR - 2016-08-11 14:30:19 --> Severity: Notice  --> Undefined variable: contents C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 8
ERROR - 2016-08-11 14:30:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 8
ERROR - 2016-08-11 14:30:19 --> Severity: Notice  --> Undefined variable: contents C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 9
ERROR - 2016-08-11 14:30:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 9
ERROR - 2016-08-11 14:30:19 --> Severity: Notice  --> Undefined variable: contents C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 10
ERROR - 2016-08-11 14:30:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 10
ERROR - 2016-08-11 14:30:19 --> Severity: Notice  --> Undefined variable: parent_id C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 45
ERROR - 2016-08-11 14:30:19 --> Severity: Notice  --> Undefined variable: isset C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 79
ERROR - 2016-08-11 14:30:27 --> Severity: Notice  --> Undefined variable: contents C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 8
ERROR - 2016-08-11 14:30:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 8
ERROR - 2016-08-11 14:30:27 --> Severity: Notice  --> Undefined variable: contents C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 9
ERROR - 2016-08-11 14:30:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 9
ERROR - 2016-08-11 14:30:27 --> Severity: Notice  --> Undefined variable: contents C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 10
ERROR - 2016-08-11 14:30:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 10
ERROR - 2016-08-11 14:30:27 --> Severity: Notice  --> Undefined variable: parent_id C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 45
ERROR - 2016-08-11 14:30:27 --> Severity: Notice  --> Undefined variable: isset C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 79
ERROR - 2016-08-11 14:30:48 --> Severity: Notice  --> Undefined variable: contents C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 8
ERROR - 2016-08-11 14:30:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 8
ERROR - 2016-08-11 14:30:48 --> Severity: Notice  --> Undefined variable: contents C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 9
ERROR - 2016-08-11 14:30:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 9
ERROR - 2016-08-11 14:30:48 --> Severity: Notice  --> Undefined variable: contents C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 10
ERROR - 2016-08-11 14:30:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 10
ERROR - 2016-08-11 14:30:48 --> Severity: Notice  --> Undefined variable: parent_id C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 45
ERROR - 2016-08-11 14:30:48 --> Severity: Notice  --> Undefined variable: checked_used C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 102
ERROR - 2016-08-11 14:30:48 --> Severity: Notice  --> Undefined variable: checked_commercial C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 105
ERROR - 2016-08-11 14:30:48 --> Severity: Notice  --> Undefined variable: checked_finance C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 116
ERROR - 2016-08-11 14:30:48 --> Severity: Notice  --> Undefined variable: parent_id C:\xampp\htdocs\tajeer_finance\application\views\layouts\footer.php 39
ERROR - 2016-08-11 14:30:48 --> Severity: Notice  --> Undefined variable: contents C:\xampp\htdocs\tajeer_finance\application\views\layouts\footer.php 55
ERROR - 2016-08-11 14:30:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\footer.php 55
ERROR - 2016-08-11 14:31:03 --> Severity: Notice  --> Undefined variable: contents C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 8
ERROR - 2016-08-11 14:31:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 8
ERROR - 2016-08-11 14:31:03 --> Severity: Notice  --> Undefined variable: contents C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 9
ERROR - 2016-08-11 14:31:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 9
ERROR - 2016-08-11 14:31:03 --> Severity: Notice  --> Undefined variable: contents C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 10
ERROR - 2016-08-11 14:31:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 10
ERROR - 2016-08-11 14:31:03 --> Severity: Notice  --> Undefined variable: parent_id C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 45
ERROR - 2016-08-11 14:31:03 --> Severity: Notice  --> Undefined variable: checked_new C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 101
ERROR - 2016-08-11 14:31:03 --> Severity: Notice  --> Undefined variable: checked_private C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 106
ERROR - 2016-08-11 14:31:03 --> Severity: Notice  --> Undefined variable: checked_installment C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 115
ERROR - 2016-08-11 14:31:03 --> Severity: Notice  --> Undefined variable: parent_id C:\xampp\htdocs\tajeer_finance\application\views\layouts\footer.php 39
ERROR - 2016-08-11 14:31:03 --> Severity: Notice  --> Undefined variable: contents C:\xampp\htdocs\tajeer_finance\application\views\layouts\footer.php 55
ERROR - 2016-08-11 14:31:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\footer.php 55
ERROR - 2016-08-11 14:31:29 --> Severity: Notice  --> Undefined variable: contents C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 8
ERROR - 2016-08-11 14:31:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 8
ERROR - 2016-08-11 14:31:29 --> Severity: Notice  --> Undefined variable: contents C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 9
ERROR - 2016-08-11 14:31:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 9
ERROR - 2016-08-11 14:31:29 --> Severity: Notice  --> Undefined variable: contents C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 10
ERROR - 2016-08-11 14:31:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 10
ERROR - 2016-08-11 14:31:29 --> Severity: Notice  --> Undefined variable: parent_id C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 45
ERROR - 2016-08-11 14:31:29 --> Severity: Notice  --> Undefined variable: checked_used C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 102
ERROR - 2016-08-11 14:31:29 --> Severity: Notice  --> Undefined variable: checked_commercial C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 105
ERROR - 2016-08-11 14:31:29 --> Severity: Notice  --> Undefined variable: checked_finance C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 116
ERROR - 2016-08-11 14:31:29 --> Severity: Notice  --> Undefined variable: parent_id C:\xampp\htdocs\tajeer_finance\application\views\layouts\footer.php 39
ERROR - 2016-08-11 14:31:29 --> Severity: Notice  --> Undefined variable: contents C:\xampp\htdocs\tajeer_finance\application\views\layouts\footer.php 55
ERROR - 2016-08-11 14:31:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\footer.php 55
ERROR - 2016-08-11 14:31:42 --> Severity: Notice  --> Undefined variable: checked_new C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 101
ERROR - 2016-08-11 14:31:42 --> Severity: Notice  --> Undefined variable: checked_commercial C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 105
ERROR - 2016-08-11 14:31:42 --> Severity: Notice  --> Undefined variable: checked_installment C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 115
ERROR - 2016-08-11 14:34:28 --> Severity: Notice  --> Undefined variable: contents C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 8
ERROR - 2016-08-11 14:34:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 8
ERROR - 2016-08-11 14:34:28 --> Severity: Notice  --> Undefined variable: contents C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 9
ERROR - 2016-08-11 14:34:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 9
ERROR - 2016-08-11 14:34:28 --> Severity: Notice  --> Undefined variable: contents C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 10
ERROR - 2016-08-11 14:34:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 10
ERROR - 2016-08-11 14:34:28 --> Severity: Notice  --> Undefined variable: parent_id C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 45
ERROR - 2016-08-11 14:34:28 --> Severity: Notice  --> Undefined variable: checked_used C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 102
ERROR - 2016-08-11 14:34:28 --> Severity: Notice  --> Undefined variable: checked_commercial C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 105
ERROR - 2016-08-11 14:34:28 --> Severity: Notice  --> Undefined variable: checked_finance C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 116
ERROR - 2016-08-11 14:34:28 --> Severity: Notice  --> Undefined variable: parent_id C:\xampp\htdocs\tajeer_finance\application\views\layouts\footer.php 39
ERROR - 2016-08-11 14:34:28 --> Severity: Notice  --> Undefined variable: contents C:\xampp\htdocs\tajeer_finance\application\views\layouts\footer.php 55
ERROR - 2016-08-11 14:34:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\footer.php 55
ERROR - 2016-08-11 14:35:00 --> Severity: Notice  --> Undefined variable: contents C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 8
ERROR - 2016-08-11 14:35:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 8
ERROR - 2016-08-11 14:35:00 --> Severity: Notice  --> Undefined variable: contents C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 9
ERROR - 2016-08-11 14:35:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 9
ERROR - 2016-08-11 14:35:00 --> Severity: Notice  --> Undefined variable: contents C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 10
ERROR - 2016-08-11 14:35:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 10
ERROR - 2016-08-11 14:35:00 --> Severity: Notice  --> Undefined variable: parent_id C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 45
ERROR - 2016-08-11 14:35:00 --> Severity: Notice  --> Undefined variable: checked_used C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 102
ERROR - 2016-08-11 14:35:00 --> Severity: Notice  --> Undefined variable: checked_commercial C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 105
ERROR - 2016-08-11 14:35:00 --> Severity: Notice  --> Undefined variable: checked_finance C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 116
ERROR - 2016-08-11 14:35:00 --> Severity: Notice  --> Undefined variable: parent_id C:\xampp\htdocs\tajeer_finance\application\views\layouts\footer.php 39
ERROR - 2016-08-11 14:35:00 --> Severity: Notice  --> Undefined variable: contents C:\xampp\htdocs\tajeer_finance\application\views\layouts\footer.php 55
ERROR - 2016-08-11 14:35:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\footer.php 55
ERROR - 2016-08-11 14:35:23 --> Severity: Notice  --> Undefined variable: contents C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 8
ERROR - 2016-08-11 14:35:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 8
ERROR - 2016-08-11 14:35:23 --> Severity: Notice  --> Undefined variable: contents C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 9
ERROR - 2016-08-11 14:35:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 9
ERROR - 2016-08-11 14:35:23 --> Severity: Notice  --> Undefined variable: contents C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 10
ERROR - 2016-08-11 14:35:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 10
ERROR - 2016-08-11 14:35:23 --> Severity: Notice  --> Undefined variable: parent_id C:\xampp\htdocs\tajeer_finance\application\views\layouts\header.php 45
ERROR - 2016-08-11 14:35:23 --> Severity: Notice  --> Undefined variable: checked_new C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 101
ERROR - 2016-08-11 14:35:23 --> Severity: Notice  --> Undefined variable: checked_private C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 106
ERROR - 2016-08-11 14:35:23 --> Severity: Notice  --> Undefined variable: checked_finance C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 116
ERROR - 2016-08-11 14:35:23 --> Severity: Notice  --> Undefined variable: parent_id C:\xampp\htdocs\tajeer_finance\application\views\layouts\footer.php 39
ERROR - 2016-08-11 14:35:23 --> Severity: Notice  --> Undefined variable: contents C:\xampp\htdocs\tajeer_finance\application\views\layouts\footer.php 55
ERROR - 2016-08-11 14:35:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\footer.php 55
ERROR - 2016-08-11 14:38:38 --> Severity: Notice  --> Undefined variable: checked_new C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 101
ERROR - 2016-08-11 14:38:38 --> Severity: Notice  --> Undefined variable: checked_commercial C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 105
ERROR - 2016-08-11 14:38:38 --> Severity: Notice  --> Undefined variable: checked_installment C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 115
ERROR - 2016-08-11 14:39:14 --> Severity: Notice  --> Undefined variable: checked_new C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 101
ERROR - 2016-08-11 14:39:14 --> Severity: Notice  --> Undefined variable: checked_commercial C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 105
ERROR - 2016-08-11 14:39:14 --> Severity: Notice  --> Undefined variable: checked_installment C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 115
ERROR - 2016-08-11 14:39:58 --> Severity: Notice  --> Undefined variable: checked_new C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 101
ERROR - 2016-08-11 14:39:58 --> Severity: Notice  --> Undefined variable: checked_commercial C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 105
ERROR - 2016-08-11 14:39:58 --> Severity: Notice  --> Undefined variable: checked_installment C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 115
ERROR - 2016-08-11 14:42:41 --> Severity: Notice  --> Undefined variable: checked_new C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 101
ERROR - 2016-08-11 14:42:41 --> Severity: Notice  --> Undefined variable: checked_commercial C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 105
ERROR - 2016-08-11 14:42:41 --> Severity: Notice  --> Undefined variable: checked_installment C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 115
ERROR - 2016-08-11 14:51:43 --> Severity: Notice  --> Undefined variable: message C:\xampp\htdocs\tajeer_finance\application\views\ems\menu\manage.php 271
ERROR - 2016-08-11 14:51:43 --> Severity: Notice  --> Undefined variable: clientList C:\xampp\htdocs\tajeer_finance\application\views\ems\menu\manage.php 278
ERROR - 2016-08-11 14:51:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\ems\menu\manage.php 278
ERROR - 2016-08-11 14:51:43 --> Severity: Notice  --> Undefined variable: htm C:\xampp\htdocs\tajeer_finance\application\helpers\custom_helper.php 2831
ERROR - 2016-08-11 14:51:43 --> Severity: Notice  --> Undefined variable: htm C:\xampp\htdocs\tajeer_finance\application\helpers\custom_helper.php 2831
ERROR - 2016-08-11 14:51:43 --> Severity: Notice  --> Undefined variable: htm C:\xampp\htdocs\tajeer_finance\application\helpers\custom_helper.php 2831
ERROR - 2016-08-11 14:51:43 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 161
ERROR - 2016-08-11 14:51:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 161
ERROR - 2016-08-11 14:51:43 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 690
ERROR - 2016-08-11 14:51:43 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 693
ERROR - 2016-08-11 14:51:43 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 696
ERROR - 2016-08-11 14:51:43 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 710
ERROR - 2016-08-11 14:51:43 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 851
ERROR - 2016-08-11 14:51:43 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 888
ERROR - 2016-08-11 14:51:43 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 892
ERROR - 2016-08-11 14:51:43 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 903
ERROR - 2016-08-11 14:51:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:51:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:51:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:51:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:51:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:51:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:51:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:51:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:51:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:51:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:51:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:51:43 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1002
ERROR - 2016-08-11 14:51:43 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1005
ERROR - 2016-08-11 14:51:43 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1008
ERROR - 2016-08-11 14:51:45 --> 404 Page Not Found --> assets
ERROR - 2016-08-11 14:51:48 --> Severity: Notice  --> Undefined variable: res C:\xampp\htdocs\tajeer_finance\application\views\ems\menu\addMenuPages.php 54
ERROR - 2016-08-11 14:51:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\ems\menu\addMenuPages.php 54
ERROR - 2016-08-11 14:51:48 --> Severity: Notice  --> Undefined offset: 18 C:\xampp\htdocs\tajeer_finance\application\views\ems\menu\addMenuPages.php 127
ERROR - 2016-08-11 14:51:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\ems\menu\addMenuPages.php 127
ERROR - 2016-08-11 14:51:48 --> Severity: Notice  --> Undefined offset: 18 C:\xampp\htdocs\tajeer_finance\application\views\ems\menu\addMenuPages.php 128
ERROR - 2016-08-11 14:51:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\ems\menu\addMenuPages.php 128
ERROR - 2016-08-11 14:51:48 --> Severity: Notice  --> Undefined offset: 19 C:\xampp\htdocs\tajeer_finance\application\views\ems\menu\addMenuPages.php 127
ERROR - 2016-08-11 14:51:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\ems\menu\addMenuPages.php 127
ERROR - 2016-08-11 14:51:48 --> Severity: Notice  --> Undefined offset: 19 C:\xampp\htdocs\tajeer_finance\application\views\ems\menu\addMenuPages.php 128
ERROR - 2016-08-11 14:51:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\ems\menu\addMenuPages.php 128
ERROR - 2016-08-11 14:51:48 --> Severity: Notice  --> Undefined offset: 20 C:\xampp\htdocs\tajeer_finance\application\views\ems\menu\addMenuPages.php 127
ERROR - 2016-08-11 14:51:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\ems\menu\addMenuPages.php 127
ERROR - 2016-08-11 14:51:48 --> Severity: Notice  --> Undefined offset: 20 C:\xampp\htdocs\tajeer_finance\application\views\ems\menu\addMenuPages.php 128
ERROR - 2016-08-11 14:51:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\ems\menu\addMenuPages.php 128
ERROR - 2016-08-11 14:51:48 --> Severity: Notice  --> Undefined offset: 21 C:\xampp\htdocs\tajeer_finance\application\views\ems\menu\addMenuPages.php 127
ERROR - 2016-08-11 14:51:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\ems\menu\addMenuPages.php 127
ERROR - 2016-08-11 14:51:48 --> Severity: Notice  --> Undefined offset: 21 C:\xampp\htdocs\tajeer_finance\application\views\ems\menu\addMenuPages.php 128
ERROR - 2016-08-11 14:51:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\ems\menu\addMenuPages.php 128
ERROR - 2016-08-11 14:51:48 --> Severity: Notice  --> Undefined property: stdClass::$tpl C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 161
ERROR - 2016-08-11 14:51:48 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 690
ERROR - 2016-08-11 14:51:49 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 693
ERROR - 2016-08-11 14:51:49 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 696
ERROR - 2016-08-11 14:51:49 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 710
ERROR - 2016-08-11 14:51:49 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 851
ERROR - 2016-08-11 14:51:49 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 888
ERROR - 2016-08-11 14:51:49 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 892
ERROR - 2016-08-11 14:51:49 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 903
ERROR - 2016-08-11 14:51:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:51:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:51:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:51:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:51:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:51:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:51:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:51:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:51:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:51:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:51:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:51:49 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1002
ERROR - 2016-08-11 14:51:49 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1005
ERROR - 2016-08-11 14:51:49 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1008
ERROR - 2016-08-11 14:51:55 --> Severity: Notice  --> Undefined variable: message C:\xampp\htdocs\tajeer_finance\application\views\ems\menu\manage.php 271
ERROR - 2016-08-11 14:51:55 --> Severity: Notice  --> Undefined variable: clientList C:\xampp\htdocs\tajeer_finance\application\views\ems\menu\manage.php 278
ERROR - 2016-08-11 14:51:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\ems\menu\manage.php 278
ERROR - 2016-08-11 14:51:55 --> Severity: Notice  --> Undefined variable: htm C:\xampp\htdocs\tajeer_finance\application\helpers\custom_helper.php 2831
ERROR - 2016-08-11 14:51:55 --> Severity: Notice  --> Undefined variable: htm C:\xampp\htdocs\tajeer_finance\application\helpers\custom_helper.php 2831
ERROR - 2016-08-11 14:51:55 --> Severity: Notice  --> Undefined variable: htm C:\xampp\htdocs\tajeer_finance\application\helpers\custom_helper.php 2831
ERROR - 2016-08-11 14:51:55 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 161
ERROR - 2016-08-11 14:51:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 161
ERROR - 2016-08-11 14:51:55 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 690
ERROR - 2016-08-11 14:51:55 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 693
ERROR - 2016-08-11 14:51:55 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 696
ERROR - 2016-08-11 14:51:55 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 710
ERROR - 2016-08-11 14:51:55 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 851
ERROR - 2016-08-11 14:51:55 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 888
ERROR - 2016-08-11 14:51:55 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 892
ERROR - 2016-08-11 14:51:55 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 903
ERROR - 2016-08-11 14:51:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:51:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:51:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:51:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:51:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:51:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:51:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:51:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:51:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:51:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:51:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:51:55 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1002
ERROR - 2016-08-11 14:51:55 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1005
ERROR - 2016-08-11 14:51:55 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1008
ERROR - 2016-08-11 14:51:58 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 161
ERROR - 2016-08-11 14:51:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 161
ERROR - 2016-08-11 14:51:58 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 690
ERROR - 2016-08-11 14:51:58 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 693
ERROR - 2016-08-11 14:51:58 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 696
ERROR - 2016-08-11 14:51:58 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 710
ERROR - 2016-08-11 14:51:58 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 851
ERROR - 2016-08-11 14:51:58 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 888
ERROR - 2016-08-11 14:51:58 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 892
ERROR - 2016-08-11 14:51:58 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 903
ERROR - 2016-08-11 14:51:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:51:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:51:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:51:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:51:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:51:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:51:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:51:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:51:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:51:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:51:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:51:58 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1002
ERROR - 2016-08-11 14:51:58 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1005
ERROR - 2016-08-11 14:51:58 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1008
ERROR - 2016-08-11 14:52:14 --> Severity: Notice  --> Undefined variable: site_id C:\xampp\htdocs\tajeer_finance\application\helpers\custom_helper.php 1899
ERROR - 2016-08-11 14:52:14 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\tajeer_finance\application\helpers\custom_helper.php 1879
ERROR - 2016-08-11 14:52:14 --> Severity: Notice  --> Undefined variable: res C:\xampp\htdocs\tajeer_finance\application\controllers\ems\menu.php 174
ERROR - 2016-08-11 14:52:14 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 161
ERROR - 2016-08-11 14:52:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 161
ERROR - 2016-08-11 14:52:14 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 690
ERROR - 2016-08-11 14:52:14 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 693
ERROR - 2016-08-11 14:52:14 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 696
ERROR - 2016-08-11 14:52:14 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 710
ERROR - 2016-08-11 14:52:14 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 851
ERROR - 2016-08-11 14:52:14 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 888
ERROR - 2016-08-11 14:52:14 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 892
ERROR - 2016-08-11 14:52:14 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 903
ERROR - 2016-08-11 14:52:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:52:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:52:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:52:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:52:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:52:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:52:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:52:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:52:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:52:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:52:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:52:14 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1002
ERROR - 2016-08-11 14:52:14 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1005
ERROR - 2016-08-11 14:52:14 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1008
ERROR - 2016-08-11 14:52:14 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 161
ERROR - 2016-08-11 14:52:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 161
ERROR - 2016-08-11 14:52:14 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 690
ERROR - 2016-08-11 14:52:14 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 693
ERROR - 2016-08-11 14:52:14 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 696
ERROR - 2016-08-11 14:52:14 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 710
ERROR - 2016-08-11 14:52:14 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 851
ERROR - 2016-08-11 14:52:14 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 888
ERROR - 2016-08-11 14:52:14 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 892
ERROR - 2016-08-11 14:52:14 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 903
ERROR - 2016-08-11 14:52:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:52:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:52:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:52:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:52:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:52:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:52:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:52:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:52:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:52:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:52:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:52:14 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1002
ERROR - 2016-08-11 14:52:15 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1005
ERROR - 2016-08-11 14:52:15 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1008
ERROR - 2016-08-11 14:52:30 --> Severity: Notice  --> Undefined variable: site_id C:\xampp\htdocs\tajeer_finance\application\helpers\custom_helper.php 1899
ERROR - 2016-08-11 14:52:30 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\tajeer_finance\application\helpers\custom_helper.php 1879
ERROR - 2016-08-11 14:52:30 --> Severity: Notice  --> Undefined variable: res C:\xampp\htdocs\tajeer_finance\application\controllers\ems\menu.php 174
ERROR - 2016-08-11 14:52:30 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 161
ERROR - 2016-08-11 14:52:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 161
ERROR - 2016-08-11 14:52:30 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 690
ERROR - 2016-08-11 14:52:30 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 693
ERROR - 2016-08-11 14:52:30 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 696
ERROR - 2016-08-11 14:52:30 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 710
ERROR - 2016-08-11 14:52:30 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 851
ERROR - 2016-08-11 14:52:30 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 888
ERROR - 2016-08-11 14:52:30 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 892
ERROR - 2016-08-11 14:52:30 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 903
ERROR - 2016-08-11 14:52:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:52:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:52:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:52:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:52:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:52:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:52:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:52:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:52:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:52:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:52:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:52:30 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1002
ERROR - 2016-08-11 14:52:30 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1005
ERROR - 2016-08-11 14:52:31 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1008
ERROR - 2016-08-11 14:52:31 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 161
ERROR - 2016-08-11 14:52:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 161
ERROR - 2016-08-11 14:52:31 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 690
ERROR - 2016-08-11 14:52:31 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 693
ERROR - 2016-08-11 14:52:31 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 696
ERROR - 2016-08-11 14:52:31 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 710
ERROR - 2016-08-11 14:52:31 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 851
ERROR - 2016-08-11 14:52:31 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 888
ERROR - 2016-08-11 14:52:31 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 892
ERROR - 2016-08-11 14:52:31 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 903
ERROR - 2016-08-11 14:52:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:52:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:52:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:52:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:52:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:52:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:52:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:52:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:52:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:52:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:52:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:52:31 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1002
ERROR - 2016-08-11 14:52:31 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1005
ERROR - 2016-08-11 14:52:31 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1008
ERROR - 2016-08-11 14:55:25 --> Severity: Notice  --> Undefined variable: message C:\xampp\htdocs\tajeer_finance\application\views\ems\menu\manage.php 271
ERROR - 2016-08-11 14:55:25 --> Severity: Notice  --> Undefined variable: clientList C:\xampp\htdocs\tajeer_finance\application\views\ems\menu\manage.php 278
ERROR - 2016-08-11 14:55:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\ems\menu\manage.php 278
ERROR - 2016-08-11 14:55:25 --> Severity: Notice  --> Undefined variable: htm C:\xampp\htdocs\tajeer_finance\application\helpers\custom_helper.php 2831
ERROR - 2016-08-11 14:55:25 --> Severity: Notice  --> Undefined variable: htm C:\xampp\htdocs\tajeer_finance\application\helpers\custom_helper.php 2831
ERROR - 2016-08-11 14:55:25 --> Severity: Notice  --> Undefined variable: htm C:\xampp\htdocs\tajeer_finance\application\helpers\custom_helper.php 2831
ERROR - 2016-08-11 14:55:25 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 161
ERROR - 2016-08-11 14:55:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 161
ERROR - 2016-08-11 14:55:25 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 690
ERROR - 2016-08-11 14:55:25 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 693
ERROR - 2016-08-11 14:55:25 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 696
ERROR - 2016-08-11 14:55:25 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 710
ERROR - 2016-08-11 14:55:25 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 851
ERROR - 2016-08-11 14:55:25 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 888
ERROR - 2016-08-11 14:55:25 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 892
ERROR - 2016-08-11 14:55:25 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 903
ERROR - 2016-08-11 14:55:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:55:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:55:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:55:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:55:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:55:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:55:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:55:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:55:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:55:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:55:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:55:25 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1002
ERROR - 2016-08-11 14:55:25 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1005
ERROR - 2016-08-11 14:55:25 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1008
ERROR - 2016-08-11 14:55:29 --> Severity: Notice  --> Undefined variable: res C:\xampp\htdocs\tajeer_finance\application\views\ems\menu\addMenuPages.php 54
ERROR - 2016-08-11 14:55:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\ems\menu\addMenuPages.php 54
ERROR - 2016-08-11 14:55:29 --> Severity: Notice  --> Undefined offset: 19 C:\xampp\htdocs\tajeer_finance\application\views\ems\menu\addMenuPages.php 127
ERROR - 2016-08-11 14:55:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\ems\menu\addMenuPages.php 127
ERROR - 2016-08-11 14:55:29 --> Severity: Notice  --> Undefined offset: 19 C:\xampp\htdocs\tajeer_finance\application\views\ems\menu\addMenuPages.php 128
ERROR - 2016-08-11 14:55:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\ems\menu\addMenuPages.php 128
ERROR - 2016-08-11 14:55:29 --> Severity: Notice  --> Undefined offset: 20 C:\xampp\htdocs\tajeer_finance\application\views\ems\menu\addMenuPages.php 127
ERROR - 2016-08-11 14:55:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\ems\menu\addMenuPages.php 127
ERROR - 2016-08-11 14:55:29 --> Severity: Notice  --> Undefined offset: 20 C:\xampp\htdocs\tajeer_finance\application\views\ems\menu\addMenuPages.php 128
ERROR - 2016-08-11 14:55:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\ems\menu\addMenuPages.php 128
ERROR - 2016-08-11 14:55:29 --> Severity: Notice  --> Undefined offset: 21 C:\xampp\htdocs\tajeer_finance\application\views\ems\menu\addMenuPages.php 127
ERROR - 2016-08-11 14:55:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\ems\menu\addMenuPages.php 127
ERROR - 2016-08-11 14:55:29 --> Severity: Notice  --> Undefined offset: 21 C:\xampp\htdocs\tajeer_finance\application\views\ems\menu\addMenuPages.php 128
ERROR - 2016-08-11 14:55:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\ems\menu\addMenuPages.php 128
ERROR - 2016-08-11 14:55:29 --> Severity: Notice  --> Undefined property: stdClass::$tpl C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 161
ERROR - 2016-08-11 14:55:29 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 690
ERROR - 2016-08-11 14:55:29 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 693
ERROR - 2016-08-11 14:55:29 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 696
ERROR - 2016-08-11 14:55:29 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 710
ERROR - 2016-08-11 14:55:29 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 851
ERROR - 2016-08-11 14:55:29 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 888
ERROR - 2016-08-11 14:55:29 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 892
ERROR - 2016-08-11 14:55:29 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 903
ERROR - 2016-08-11 14:55:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:55:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:55:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:55:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:55:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:55:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:55:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:55:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:55:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:55:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:55:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:55:29 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1002
ERROR - 2016-08-11 14:55:29 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1005
ERROR - 2016-08-11 14:55:29 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1008
ERROR - 2016-08-11 14:55:36 --> Severity: Notice  --> Undefined variable: message C:\xampp\htdocs\tajeer_finance\application\views\ems\menu\manage.php 271
ERROR - 2016-08-11 14:55:36 --> Severity: Notice  --> Undefined variable: clientList C:\xampp\htdocs\tajeer_finance\application\views\ems\menu\manage.php 278
ERROR - 2016-08-11 14:55:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\ems\menu\manage.php 278
ERROR - 2016-08-11 14:55:37 --> Severity: Notice  --> Undefined variable: htm C:\xampp\htdocs\tajeer_finance\application\helpers\custom_helper.php 2831
ERROR - 2016-08-11 14:55:37 --> Severity: Notice  --> Undefined variable: htm C:\xampp\htdocs\tajeer_finance\application\helpers\custom_helper.php 2831
ERROR - 2016-08-11 14:55:37 --> Severity: Notice  --> Undefined variable: htm C:\xampp\htdocs\tajeer_finance\application\helpers\custom_helper.php 2831
ERROR - 2016-08-11 14:55:37 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 161
ERROR - 2016-08-11 14:55:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 161
ERROR - 2016-08-11 14:55:37 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 690
ERROR - 2016-08-11 14:55:37 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 693
ERROR - 2016-08-11 14:55:37 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 696
ERROR - 2016-08-11 14:55:37 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 710
ERROR - 2016-08-11 14:55:37 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 851
ERROR - 2016-08-11 14:55:37 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 888
ERROR - 2016-08-11 14:55:37 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 892
ERROR - 2016-08-11 14:55:37 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 903
ERROR - 2016-08-11 14:55:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:55:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:55:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:55:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:55:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:55:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:55:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:55:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:55:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:55:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:55:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-11 14:55:37 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1002
ERROR - 2016-08-11 14:55:37 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1005
ERROR - 2016-08-11 14:55:37 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1008
ERROR - 2016-08-11 14:56:03 --> Severity: Notice  --> Undefined variable: checked_new C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 101
ERROR - 2016-08-11 14:56:03 --> Severity: Notice  --> Undefined variable: checked_commercial C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 105
ERROR - 2016-08-11 14:56:03 --> Severity: Notice  --> Undefined variable: checked_installment C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 115
ERROR - 2016-08-11 15:06:00 --> Severity: Notice  --> Undefined variable: checked_new C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 101
ERROR - 2016-08-11 15:06:00 --> Severity: Notice  --> Undefined variable: checked_commercial C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 105
ERROR - 2016-08-11 15:06:00 --> Severity: Notice  --> Undefined variable: checked_installment C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 115
ERROR - 2016-08-11 15:06:05 --> Severity: Notice  --> Undefined variable: checked_new C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 101
ERROR - 2016-08-11 15:06:05 --> Severity: Notice  --> Undefined variable: checked_commercial C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 105
ERROR - 2016-08-11 15:06:05 --> Severity: Notice  --> Undefined variable: checked_installment C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 115
ERROR - 2016-08-11 15:06:41 --> Severity: Notice  --> Undefined variable: checked_new C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 101
ERROR - 2016-08-11 15:06:41 --> Severity: Notice  --> Undefined variable: checked_commercial C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 105
ERROR - 2016-08-11 15:06:41 --> Severity: Notice  --> Undefined variable: checked_installment C:\xampp\htdocs\tajeer_finance\application\views\finance_cal.php 115
