<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-08-05 16:07:31 --> Severity: Notice  --> Undefined variable: Lang C:\xampp\htdocs\tajeer_finance\application\views\branches.php 41
ERROR - 2016-08-05 16:07:31 --> Severity: Notice  --> Undefined variable: marker C:\xampp\htdocs\tajeer_finance\application\views\branches.php 59
ERROR - 2016-08-05 16:07:38 --> Severity: Notice  --> Undefined variable: message C:\xampp\htdocs\tajeer_finance\application\views\ems\menu\manage.php 271
ERROR - 2016-08-05 16:07:38 --> Severity: Notice  --> Undefined variable: clientList C:\xampp\htdocs\tajeer_finance\application\views\ems\menu\manage.php 278
ERROR - 2016-08-05 16:07:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\ems\menu\manage.php 278
ERROR - 2016-08-05 16:07:38 --> Severity: Notice  --> Undefined variable: htm C:\xampp\htdocs\tajeer_finance\application\helpers\custom_helper.php 2821
ERROR - 2016-08-05 16:07:38 --> Severity: Notice  --> Undefined variable: htm C:\xampp\htdocs\tajeer_finance\application\helpers\custom_helper.php 2821
ERROR - 2016-08-05 16:07:38 --> Severity: Notice  --> Undefined variable: htm C:\xampp\htdocs\tajeer_finance\application\helpers\custom_helper.php 2821
ERROR - 2016-08-05 16:07:38 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 161
ERROR - 2016-08-05 16:07:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 161
ERROR - 2016-08-05 16:07:38 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 690
ERROR - 2016-08-05 16:07:39 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 693
ERROR - 2016-08-05 16:07:39 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 696
ERROR - 2016-08-05 16:07:39 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 710
ERROR - 2016-08-05 16:07:39 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 851
ERROR - 2016-08-05 16:07:39 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 888
ERROR - 2016-08-05 16:07:39 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 892
ERROR - 2016-08-05 16:07:39 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 903
ERROR - 2016-08-05 16:07:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:07:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:07:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:07:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:07:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:07:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:07:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:07:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:07:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:07:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:07:39 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1002
ERROR - 2016-08-05 16:07:39 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1005
ERROR - 2016-08-05 16:07:39 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1008
ERROR - 2016-08-05 16:08:20 --> 404 Page Not Found --> assets
ERROR - 2016-08-05 16:08:22 --> Severity: Notice  --> Undefined variable: message C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\manage.php 280
ERROR - 2016-08-05 16:08:22 --> Severity: Notice  --> Undefined variable: clientList C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\manage.php 287
ERROR - 2016-08-05 16:08:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\manage.php 287
ERROR - 2016-08-05 16:08:22 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 161
ERROR - 2016-08-05 16:08:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 161
ERROR - 2016-08-05 16:08:22 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 690
ERROR - 2016-08-05 16:08:22 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 693
ERROR - 2016-08-05 16:08:22 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 696
ERROR - 2016-08-05 16:08:22 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 710
ERROR - 2016-08-05 16:08:22 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 851
ERROR - 2016-08-05 16:08:22 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 888
ERROR - 2016-08-05 16:08:22 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 892
ERROR - 2016-08-05 16:08:22 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 903
ERROR - 2016-08-05 16:08:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:08:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:08:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:08:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:08:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:08:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:08:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:08:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:08:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:08:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:08:23 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1002
ERROR - 2016-08-05 16:08:23 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1005
ERROR - 2016-08-05 16:08:23 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1008
ERROR - 2016-08-05 16:08:28 --> Severity: Notice  --> Undefined index: template C:\xampp\htdocs\tajeer_finance\application\controllers\ems\content.php 68
ERROR - 2016-08-05 16:08:29 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: HTTP request failed! HTTP/1.0 400 Bad Request
 C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2113
ERROR - 2016-08-05 16:08:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2117
ERROR - 2016-08-05 16:08:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2133
ERROR - 2016-08-05 16:08:29 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 690
ERROR - 2016-08-05 16:08:29 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 693
ERROR - 2016-08-05 16:08:29 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 696
ERROR - 2016-08-05 16:08:29 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 710
ERROR - 2016-08-05 16:08:29 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 851
ERROR - 2016-08-05 16:08:29 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 892
ERROR - 2016-08-05 16:08:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:08:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:08:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:08:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:08:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:08:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:08:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:08:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:08:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:08:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:08:29 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1002
ERROR - 2016-08-05 16:08:29 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1005
ERROR - 2016-08-05 16:08:29 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1008
ERROR - 2016-08-05 16:08:33 --> Severity: Notice  --> Undefined variable: message C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\manage.php 280
ERROR - 2016-08-05 16:08:33 --> Severity: Notice  --> Undefined variable: clientList C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\manage.php 287
ERROR - 2016-08-05 16:08:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\ems\contents\manage.php 287
ERROR - 2016-08-05 16:08:33 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 161
ERROR - 2016-08-05 16:08:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 161
ERROR - 2016-08-05 16:08:33 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 690
ERROR - 2016-08-05 16:08:33 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 693
ERROR - 2016-08-05 16:08:33 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 696
ERROR - 2016-08-05 16:08:33 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 710
ERROR - 2016-08-05 16:08:33 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 851
ERROR - 2016-08-05 16:08:33 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 888
ERROR - 2016-08-05 16:08:33 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 892
ERROR - 2016-08-05 16:08:33 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 903
ERROR - 2016-08-05 16:08:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:08:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:08:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:08:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:08:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:08:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:08:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:08:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:08:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:08:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:08:33 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1002
ERROR - 2016-08-05 16:08:33 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1005
ERROR - 2016-08-05 16:08:33 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1008
ERROR - 2016-08-05 16:08:36 --> Severity: Notice  --> Undefined index: template C:\xampp\htdocs\tajeer_finance\application\controllers\ems\content.php 68
ERROR - 2016-08-05 16:08:37 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: HTTP request failed! HTTP/1.0 400 Bad Request
 C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2113
ERROR - 2016-08-05 16:08:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2117
ERROR - 2016-08-05 16:08:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2133
ERROR - 2016-08-05 16:08:37 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 690
ERROR - 2016-08-05 16:08:37 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 693
ERROR - 2016-08-05 16:08:37 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 696
ERROR - 2016-08-05 16:08:37 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 710
ERROR - 2016-08-05 16:08:37 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 851
ERROR - 2016-08-05 16:08:37 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 892
ERROR - 2016-08-05 16:08:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:08:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:08:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:08:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:08:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:08:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:08:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:08:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:08:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:08:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:08:37 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1002
ERROR - 2016-08-05 16:08:37 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1005
ERROR - 2016-08-05 16:08:37 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1008
ERROR - 2016-08-05 16:09:57 --> Severity: Notice  --> Undefined index: template C:\xampp\htdocs\tajeer_finance\application\controllers\ems\content.php 68
ERROR - 2016-08-05 16:09:58 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: HTTP request failed! HTTP/1.0 400 Bad Request
 C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2113
ERROR - 2016-08-05 16:09:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2117
ERROR - 2016-08-05 16:09:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2133
ERROR - 2016-08-05 16:09:58 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 690
ERROR - 2016-08-05 16:09:58 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 693
ERROR - 2016-08-05 16:09:58 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 696
ERROR - 2016-08-05 16:09:58 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 710
ERROR - 2016-08-05 16:09:58 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 851
ERROR - 2016-08-05 16:09:58 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 892
ERROR - 2016-08-05 16:09:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:09:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:09:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:09:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:09:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:09:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:09:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:09:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:09:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:09:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:09:58 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1002
ERROR - 2016-08-05 16:09:58 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1005
ERROR - 2016-08-05 16:09:58 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1008
ERROR - 2016-08-05 16:11:35 --> Severity: Notice  --> Undefined index: template C:\xampp\htdocs\tajeer_finance\application\controllers\ems\content.php 68
ERROR - 2016-08-05 16:11:35 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: HTTP request failed! HTTP/1.0 400 Bad Request
 C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2113
ERROR - 2016-08-05 16:11:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2117
ERROR - 2016-08-05 16:11:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2133
ERROR - 2016-08-05 16:11:35 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 690
ERROR - 2016-08-05 16:11:35 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 693
ERROR - 2016-08-05 16:11:35 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 696
ERROR - 2016-08-05 16:11:35 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 710
ERROR - 2016-08-05 16:11:35 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 851
ERROR - 2016-08-05 16:11:35 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 892
ERROR - 2016-08-05 16:11:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:11:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:11:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:11:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:11:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:11:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:11:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:11:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:11:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:11:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:11:35 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1002
ERROR - 2016-08-05 16:11:35 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1005
ERROR - 2016-08-05 16:11:35 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1008
ERROR - 2016-08-05 16:21:52 --> Severity: Notice  --> Undefined index: template C:\xampp\htdocs\tajeer_finance\application\controllers\ems\content.php 68
ERROR - 2016-08-05 16:21:53 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: HTTP request failed! HTTP/1.0 400 Bad Request
 C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2113
ERROR - 2016-08-05 16:21:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2117
ERROR - 2016-08-05 16:21:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2133
ERROR - 2016-08-05 16:21:53 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 690
ERROR - 2016-08-05 16:21:53 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 693
ERROR - 2016-08-05 16:21:53 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 696
ERROR - 2016-08-05 16:21:53 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 710
ERROR - 2016-08-05 16:21:53 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 851
ERROR - 2016-08-05 16:21:53 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 892
ERROR - 2016-08-05 16:21:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:21:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:21:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:21:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:21:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:21:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:21:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:21:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:21:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:21:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:21:53 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1002
ERROR - 2016-08-05 16:21:53 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1005
ERROR - 2016-08-05 16:21:53 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1008
ERROR - 2016-08-05 16:22:09 --> Severity: Notice  --> Undefined index: template C:\xampp\htdocs\tajeer_finance\application\controllers\ems\content.php 68
ERROR - 2016-08-05 16:22:09 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: HTTP request failed! HTTP/1.0 400 Bad Request
 C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2113
ERROR - 2016-08-05 16:22:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2117
ERROR - 2016-08-05 16:22:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2133
ERROR - 2016-08-05 16:22:09 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 690
ERROR - 2016-08-05 16:22:09 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 693
ERROR - 2016-08-05 16:22:09 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 696
ERROR - 2016-08-05 16:22:09 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 710
ERROR - 2016-08-05 16:22:09 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 851
ERROR - 2016-08-05 16:22:09 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 892
ERROR - 2016-08-05 16:22:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:22:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:22:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:22:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:22:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:22:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:22:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:22:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:22:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:22:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:22:09 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1002
ERROR - 2016-08-05 16:22:09 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1005
ERROR - 2016-08-05 16:22:10 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1008
ERROR - 2016-08-05 16:23:19 --> Severity: Notice  --> Undefined index: template C:\xampp\htdocs\tajeer_finance\application\controllers\ems\content.php 68
ERROR - 2016-08-05 16:23:20 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: HTTP request failed! HTTP/1.0 400 Bad Request
 C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2113
ERROR - 2016-08-05 16:23:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2117
ERROR - 2016-08-05 16:23:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2133
ERROR - 2016-08-05 16:23:20 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 690
ERROR - 2016-08-05 16:23:20 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 693
ERROR - 2016-08-05 16:23:20 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 696
ERROR - 2016-08-05 16:23:20 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 710
ERROR - 2016-08-05 16:23:20 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 851
ERROR - 2016-08-05 16:23:20 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 892
ERROR - 2016-08-05 16:23:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:23:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:23:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:23:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:23:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:23:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:23:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:23:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:23:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:23:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:23:20 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1002
ERROR - 2016-08-05 16:23:20 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1005
ERROR - 2016-08-05 16:23:20 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1008
ERROR - 2016-08-05 16:24:04 --> Severity: Notice  --> Undefined index: template C:\xampp\htdocs\tajeer_finance\application\controllers\ems\content.php 68
ERROR - 2016-08-05 16:24:05 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: HTTP request failed! HTTP/1.0 400 Bad Request
 C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2113
ERROR - 2016-08-05 16:24:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2117
ERROR - 2016-08-05 16:24:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2133
ERROR - 2016-08-05 16:24:05 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 690
ERROR - 2016-08-05 16:24:05 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 693
ERROR - 2016-08-05 16:24:05 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 696
ERROR - 2016-08-05 16:24:05 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 710
ERROR - 2016-08-05 16:24:05 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 851
ERROR - 2016-08-05 16:24:05 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 892
ERROR - 2016-08-05 16:24:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:24:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:24:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:24:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:24:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:24:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:24:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:24:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:24:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:24:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:24:05 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1002
ERROR - 2016-08-05 16:24:05 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1005
ERROR - 2016-08-05 16:24:05 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1008
ERROR - 2016-08-05 16:24:43 --> Severity: Notice  --> Undefined index: template C:\xampp\htdocs\tajeer_finance\application\controllers\ems\content.php 68
ERROR - 2016-08-05 16:24:44 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: HTTP request failed! HTTP/1.0 400 Bad Request
 C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2113
ERROR - 2016-08-05 16:24:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2117
ERROR - 2016-08-05 16:24:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2133
ERROR - 2016-08-05 16:24:44 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 690
ERROR - 2016-08-05 16:24:44 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 693
ERROR - 2016-08-05 16:24:44 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 696
ERROR - 2016-08-05 16:24:44 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 710
ERROR - 2016-08-05 16:24:44 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 851
ERROR - 2016-08-05 16:24:44 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 892
ERROR - 2016-08-05 16:24:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:24:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:24:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:24:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:24:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:24:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:24:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:24:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:24:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:24:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:24:44 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1002
ERROR - 2016-08-05 16:24:44 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1005
ERROR - 2016-08-05 16:24:44 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1008
ERROR - 2016-08-05 16:26:19 --> Severity: Notice  --> Undefined index: template C:\xampp\htdocs\tajeer_finance\application\controllers\ems\content.php 68
ERROR - 2016-08-05 16:26:19 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: HTTP request failed! HTTP/1.0 400 Bad Request
 C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2113
ERROR - 2016-08-05 16:26:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2117
ERROR - 2016-08-05 16:26:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2133
ERROR - 2016-08-05 16:26:19 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 690
ERROR - 2016-08-05 16:26:19 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 693
ERROR - 2016-08-05 16:26:19 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 696
ERROR - 2016-08-05 16:26:19 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 710
ERROR - 2016-08-05 16:26:19 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 851
ERROR - 2016-08-05 16:26:19 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 892
ERROR - 2016-08-05 16:26:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:26:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:26:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:26:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:26:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:26:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:26:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:26:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:26:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:26:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:26:19 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1002
ERROR - 2016-08-05 16:26:19 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1005
ERROR - 2016-08-05 16:26:19 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1008
ERROR - 2016-08-05 16:26:48 --> Severity: Notice  --> Undefined index: template C:\xampp\htdocs\tajeer_finance\application\controllers\ems\content.php 68
ERROR - 2016-08-05 16:26:48 --> Severity: Warning  --> file_get_contents(http://maps.google.com/maps/api/geocode/json?address=&amp;sensor=false): failed to open stream: HTTP request failed! HTTP/1.0 400 Bad Request
 C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2113
ERROR - 2016-08-05 16:26:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2117
ERROR - 2016-08-05 16:26:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\libraries\google_maps.php 2133
ERROR - 2016-08-05 16:26:48 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 690
ERROR - 2016-08-05 16:26:48 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 693
ERROR - 2016-08-05 16:26:48 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 696
ERROR - 2016-08-05 16:26:48 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 710
ERROR - 2016-08-05 16:26:48 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 851
ERROR - 2016-08-05 16:26:48 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 892
ERROR - 2016-08-05 16:26:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:26:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:26:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:26:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:26:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:26:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:26:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:26:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:26:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:26:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-05 16:26:48 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1002
ERROR - 2016-08-05 16:26:48 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1005
ERROR - 2016-08-05 16:26:48 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1008
