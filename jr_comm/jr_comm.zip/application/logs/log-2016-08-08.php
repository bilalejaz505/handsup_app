<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-08-08 07:48:44 --> Severity: Notice  --> Undefined variable: Lang C:\xampp\htdocs\tajeer_finance\application\views\contactus.php 62
ERROR - 2016-08-08 08:02:53 --> 404 Page Not Found --> assets
ERROR - 2016-08-08 08:33:40 --> 404 Page Not Found --> assets
ERROR - 2016-08-08 09:30:07 --> Severity: Notice  --> Undefined variable: Lang C:\xampp\htdocs\tajeer_finance\application\views\contactus.php 62
ERROR - 2016-08-08 11:04:32 --> Severity: Notice  --> Undefined variable: Lang C:\xampp\htdocs\tajeer_finance\application\views\contactus.php 62
ERROR - 2016-08-08 11:27:32 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin.php 68
ERROR - 2016-08-08 11:27:40 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 161
ERROR - 2016-08-08 11:27:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 161
ERROR - 2016-08-08 11:27:40 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 690
ERROR - 2016-08-08 11:27:40 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 693
ERROR - 2016-08-08 11:27:40 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 696
ERROR - 2016-08-08 11:27:40 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 710
ERROR - 2016-08-08 11:27:40 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 851
ERROR - 2016-08-08 11:27:40 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 888
ERROR - 2016-08-08 11:27:40 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 892
ERROR - 2016-08-08 11:27:40 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 903
ERROR - 2016-08-08 11:27:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 957
ERROR - 2016-08-08 11:27:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-08 11:27:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 957
ERROR - 2016-08-08 11:27:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-08 11:27:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 957
ERROR - 2016-08-08 11:27:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-08 11:27:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 957
ERROR - 2016-08-08 11:27:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-08 11:27:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 957
ERROR - 2016-08-08 11:27:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-08 11:27:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 957
ERROR - 2016-08-08 11:27:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-08 11:27:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 957
ERROR - 2016-08-08 11:27:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-08 11:27:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 957
ERROR - 2016-08-08 11:27:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-08 11:27:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 957
ERROR - 2016-08-08 11:27:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-08 11:27:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 957
ERROR - 2016-08-08 11:27:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-08 11:27:40 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1002
ERROR - 2016-08-08 11:27:40 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1005
ERROR - 2016-08-08 11:27:40 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1008
ERROR - 2016-08-08 11:28:44 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\tajeer_finance\application\views\ems\inquries\manage.php 321
ERROR - 2016-08-08 11:28:44 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 161
ERROR - 2016-08-08 11:28:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 161
ERROR - 2016-08-08 11:28:44 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 690
ERROR - 2016-08-08 11:28:44 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 693
ERROR - 2016-08-08 11:28:44 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 696
ERROR - 2016-08-08 11:28:44 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 710
ERROR - 2016-08-08 11:28:44 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 851
ERROR - 2016-08-08 11:28:44 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 888
ERROR - 2016-08-08 11:28:44 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 892
ERROR - 2016-08-08 11:28:44 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 903
ERROR - 2016-08-08 11:28:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-08 11:28:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-08 11:28:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-08 11:28:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-08 11:28:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-08 11:28:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-08 11:28:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-08 11:28:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-08 11:28:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-08 11:28:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-08 11:28:44 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1002
ERROR - 2016-08-08 11:28:44 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1005
ERROR - 2016-08-08 11:28:44 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1008
ERROR - 2016-08-08 11:28:45 --> 404 Page Not Found --> assets
ERROR - 2016-08-08 13:03:31 --> 404 Page Not Found --> assets
ERROR - 2016-08-08 13:43:55 --> 404 Page Not Found --> assets
ERROR - 2016-08-08 13:44:07 --> Severity: Notice  --> Undefined variable: Lang C:\xampp\htdocs\tajeer_finance\application\views\branches.php 41
ERROR - 2016-08-08 13:44:07 --> Severity: Notice  --> Undefined variable: marker C:\xampp\htdocs\tajeer_finance\application\views\branches.php 59
ERROR - 2016-08-08 14:27:00 --> Severity: Notice  --> Undefined variable: htm2 C:\xampp\htdocs\tajeer_finance\application\helpers\custom_helper.php 3069
ERROR - 2016-08-08 14:27:00 --> Severity: Notice  --> Undefined property: stdClass::$smtp_host C:\xampp\htdocs\tajeer_finance\application\views\ems\social\edit.php 177
ERROR - 2016-08-08 14:27:00 --> Severity: Notice  --> Undefined property: stdClass::$smtp_email C:\xampp\htdocs\tajeer_finance\application\views\ems\social\edit.php 185
ERROR - 2016-08-08 14:27:00 --> Severity: Notice  --> Undefined property: stdClass::$smtp_password C:\xampp\htdocs\tajeer_finance\application\views\ems\social\edit.php 194
ERROR - 2016-08-08 14:27:00 --> Severity: Notice  --> Undefined property: stdClass::$smtp_port C:\xampp\htdocs\tajeer_finance\application\views\ems\social\edit.php 203
ERROR - 2016-08-08 14:27:00 --> Severity: Notice  --> Undefined variable: result C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 161
ERROR - 2016-08-08 14:27:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 161
ERROR - 2016-08-08 14:27:00 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 690
ERROR - 2016-08-08 14:27:00 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 693
ERROR - 2016-08-08 14:27:00 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 696
ERROR - 2016-08-08 14:27:00 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 710
ERROR - 2016-08-08 14:27:00 --> Severity: Notice  --> Undefined variable: template C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 851
ERROR - 2016-08-08 14:27:00 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 888
ERROR - 2016-08-08 14:27:00 --> Severity: Notice  --> Undefined variable: msg C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 892
ERROR - 2016-08-08 14:27:00 --> Severity: Notice  --> Undefined variable: map C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 903
ERROR - 2016-08-08 14:27:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-08 14:27:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-08 14:27:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-08 14:27:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-08 14:27:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-08 14:27:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-08 14:27:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-08 14:27:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-08 14:27:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-08 14:27:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 959
ERROR - 2016-08-08 14:27:00 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1002
ERROR - 2016-08-08 14:27:00 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1005
ERROR - 2016-08-08 14:27:00 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tajeer_finance\application\views\layouts\admin_inner.php 1008
ERROR - 2016-08-08 14:44:54 --> Severity: Notice  --> Undefined variable: Lang C:\xampp\htdocs\tajeer_finance\application\views\branches.php 41
ERROR - 2016-08-08 14:44:54 --> Severity: Notice  --> Undefined variable: marker C:\xampp\htdocs\tajeer_finance\application\views\branches.php 59
